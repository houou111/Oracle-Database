set termout off
column timecol new_value timestamp 
column spool_extension new_value suffix 
select to_char(sysdate,'DD_MON_YYYY_HH24_MI_SS') timecol,'.xls' spool_extension from sys.dual; 
column output new_value dbname 
select value || '_' output from v$parameter where name = 'db_name';

set feed off markup html on spool on 
alter session set nls_date_format='YYYY-MM-DD';
set serveroutput on
set termout off
set verify off
set echo off
set pagesize 50000
spool AWRSegment_BlockChange_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_blockchange_sec_sn_i.sql
spool off
spool AWRSegment_LogicalRead_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_buffer_sec_sn_i.sql
spool off
spool AWRSegment_BufferWait_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_bufferwait_sec_sn_i.sql
spool off
spool AWRSegment_GCCRBlockServed_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccrblockserved_sec_sn_i.sql
spool off
spool AWRSegment_GCCurBlockServed_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccublockserved_sec_sn_i.sql
spool off
spool AWRSegment_GCBusywait_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gcbusy_sec_sn_i.sql
spool off
spool AWRSegment_GCCRBlockRecv_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccrblockrec_sec_sn_i.sql
spool off
spool AWRSegment_GCCurBlockRecv_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccublockrec_sec_sn_i.sql
spool off
spool AWRSegment_ITLWait_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_itlwait_sec_sn_i.sql
spool off
spool AWRSegment_PhyReadDirect_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicaldirect_sec_sn_i.sql
spool off
spool AWRSegment_PhyRead_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicalread_sec_sn_i.sql
spool off
spool AWRSegment_PhyWrite_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicalwrite_sec_sn_i.sql
spool off
spool AWRSegment_Rowlock_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_rowlock_sec_sn_i.sql
spool off
spool AWRSegment_PhyWriteDirect_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_writedirect_sec_sn_i.sql
spool off
spool AWRSegment_WriteRequest_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_writereqs_sec_sn_i.sql
spool off
spool AWRSegment_ChainRow_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_chainrow_sec_sn_i.sql
spool off
spool AWRSegment_PhyReqs_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_phyreqs_sec_sn_i.sql
spool off
spool AWRSegment_OptimziedPhy_Per_Second_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_optphy_sec_sn_i.sql
spool off
set markup html off spool off

