PROMPT ==============================================================================================
PROMPT ==AWR SEGMENT STATISTICS 2.0 ==
PROMPT ==============================================================================================
prompt


break on statistic_name skip 1

column owner           heading 'Owner'           format a10 trunc
column statistic_name  heading 'Statistic'       format a22
column tablespace_name heading 'Tablespace|Name' format a10 trunc
column object_type     heading 'Obj.|Type'       format a5 trunc
column object_name     heading 'Object|Name'     format a20 trunc
column subobject_name  heading 'Subobject|Name'  format a10 trunc
column value           heading 'Value'           format 999,999,999
column ratio           heading '%Capture' format 999,999
column pct             heading '%Total'   format 999,999
column rnk             format 999 noprint
col inst for 999
define top_n_segstat = 10;

select ss.snap_id,ss.instance_number inst, TO_CHAR(ss.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime
  						, TO_CHAR(ss.end_interval_time, 'mm/dd/yyyy HH24:MI')   endtime,
  		ss.stat_name                                            statistic_name
     , n.owner
     , n.tablespace_name
     , n.object_name
     , case when length(n.subobject_name) < 11 
            then n.subobject_name
            else substr(n.subobject_name,length(n.subobject_name)-9)
       end                                                     subobject_name
     , n.object_type
     , value
     , case when stat_name = 'logical reads'         then value/f.tgets*100
            when stat_name = 'db block changes'      then value/f.tdbch*100
            when stat_name = 'physical reads'        then value/f.trds*100
            when stat_name = 'physical reads direct' then value/f.trdds*100
            when stat_name = 'physical writes'       then value/f.twrs*100
            when stat_name = 'physical writes direct' then value/f.twrds*100
            when stat_name = 'table scans'           then value/(f.ttslt + f.tiffs)*100
            when stat_name = 'gc cr blocks received' then value/f.tgccrr*100
            when stat_name = 'gc cu blocks received' then value/f.tgccur*100
            when stat_name = 'gc cr blocks served'   then value/f.tgccrs*100
            when stat_name = 'gc cu blocks served'   then value/f.tgccus*100
            else null
       end                                                                pct
     , (ratio_to_report(value) over (partition by stat_name))*100       ratio
     , rnk
  from ( /* now unpivot the result set for display purposes */
      select instance_number,snap_id,begin_interval_time,end_interval_time,dataobj#
           , obj#
           , dbid
           , stat_name
           , case when stat_name = 'logical reads'          then lr
                  when stat_name = 'buffer busy waits'      then bbw
                  when stat_name = 'db block changes'       then dbc
                  when stat_name = 'physical reads'         then pr
                  when stat_name = 'physical writes'        then pw
                  when stat_name = 'physical reads direct'  then prd
                  when stat_name = 'physical writes direct' then pwd
                  when stat_name = 'ITL waits'              then iw
                  when stat_name = 'row lock waits'         then rlw
                  when stat_name = 'gc cr blocks served'    then gcrs
                  when stat_name = 'gc cu blocks served'    then gcus
                  when stat_name = 'gc buffer busy'         then gbb
                  when stat_name = 'gc cr blocks received'  then gcrr
                  when stat_name = 'gc cu blocks received'  then gcur
                  when stat_name = 'table scans'            then ts
                  else 0
             end  value
           , case when stat_name = 'logical reads'          then rnk_lr
                  when stat_name = 'buffer busy waits'      then rnk_bbw
                  when stat_name = 'db block changes'       then rnk_dbc
                  when stat_name = 'physical reads'         then rnk_pr
                  when stat_name = 'physical writes'        then rnk_pw
                  when stat_name = 'physical reads direct'  then rnk_prd
                  when stat_name = 'physical writes direct' then rnk_pwd
                  when stat_name = 'ITL waits'              then rnk_iw
                  when stat_name = 'row lock waits'         then rnk_rlw
                  when stat_name = 'gc cr blocks served'    then rnk_gcrs
                  when stat_name = 'gc cu blocks served'    then rnk_gcus
                  when stat_name = 'gc buffer busy'         then rnk_gbb
                  when stat_name = 'gc cr blocks received'  then rnk_gcrr
                  when stat_name = 'gc cu blocks received'  then rnk_gcur
                  when stat_name = 'table scans'            then rnk_ts
                  else 0
             end  rnk
        from ( /* select top n for each statistic */
             select * from 
                (/* select objects and rank per statistic*/
                select e.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time,
                			e.dataobj#
                     , e.obj#
                     , e.dbid
                     , sum(logical_reads_delta)          lr
                     , sum(buffer_busy_waits_delta)      bbw
                     , sum(db_block_changes_delta)       dbc
                     , sum(physical_reads_delta)         pr
                     , sum(physical_writes_delta)        pw
                     , sum(physical_reads_direct_delta)  prd
                     , sum(physical_writes_direct_delta) pwd
                     , sum(itl_waits_delta)              iw
                     , sum(row_lock_waits_delta)         rlw
                     , sum(gc_cr_blocks_served_delta)    gcrs
                     , sum(gc_cu_blocks_served_delta)    gcus
                     , sum(gc_buffer_busy_delta)         gbb
                     , sum(gc_cr_blocks_received_delta)  gcrr
                     , sum(gc_cu_blocks_received_delta)  gcur
                     , sum(table_scans_delta)            ts
                     , rank () over (order by 
                          sum(logical_reads_delta)     desc)         rnk_lr
                     , rank () over (order by 
                          sum(buffer_busy_waits_delta) desc)        rnk_bbw
                     , rank () over (order by 
                          sum(db_block_changes_delta)  desc)        rnk_dbc
                     , rank () over (order by 
                          sum(physical_reads_delta)    desc)         rnk_pr
                     , rank () over (order by 
                          sum(physical_writes_delta)   desc)         rnk_pw
                     , rank () over (order by 
                          sum(physical_reads_direct_delta)  desc)   rnk_prd
                     , rank () over (order by 
                          sum(physical_writes_direct_delta) desc)   rnk_pwd
                     , rank () over (order by 
                          sum(itl_waits_delta)         desc)         rnk_iw
                     , rank () over (order by 
                          sum(row_lock_waits_delta)    desc)        rnk_rlw
                     , rank () over (order by 
                          sum(gc_cr_blocks_served_delta) desc)     rnk_gcrs
                     , rank () over (order by 
                          sum(gc_cu_blocks_served_delta) desc)     rnk_gcus
                     , rank () over (order by 
                          sum(gc_buffer_busy_delta)      desc)      rnk_gbb
                     , rank () over (order by 
                          sum(gc_cr_blocks_received_delta) desc)   rnk_gcrr
                     , rank () over (order by 
                          sum(gc_cu_blocks_received_delta) desc)   rnk_gcur
                     , rank () over (order by 
                          sum(table_scans_delta)         desc)       rnk_ts
                 from dba_hist_seg_stat  e,dba_hist_snapshot s
      					 where e.snap_id = s.snap_id
      					 and s.instance_number=e.instance_number
                group by e.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time,e.dataobj#, e.obj#, e.dbid
               )
             where rnk_lr   <= &top_n_segstat 
                or rnk_bbw  <= &top_n_segstat
                or rnk_dbc  <= &top_n_segstat
                or rnk_pr   <= &top_n_segstat
                or rnk_pw   <= &top_n_segstat
                or rnk_prd  <= &top_n_segstat
                or rnk_pwd  <= &top_n_segstat
                or rnk_iw   <= &top_n_segstat
                or rnk_rlw  <= &top_n_segstat
                or rnk_gcrs <= &top_n_segstat
                or rnk_gcus <= &top_n_segstat
                or rnk_gbb  <= &top_n_segstat
                or rnk_gcrr <= &top_n_segstat
                or rnk_gcur <= &top_n_segstat
                or rnk_ts   <= &top_n_segstat
             )  r
           , ( /* used to generate cartesian join for unpivot */
              select 'logical reads'          stat_name from dual union all
              select 'buffer busy waits'      stat_name from dual union all
              select 'db block changes'       stat_name from dual union all
              select 'physical reads'         stat_name from dual union all
              select 'physical writes'        stat_name from dual union all
              select 'physical reads direct'  stat_name from dual union all
              select 'physical writes direct' stat_name from dual union all
              select 'ITL waits'              stat_name from dual union all
              select 'row lock waits'         stat_name from dual union all
              select 'gc cr blocks served'    stat_name from dual union all
              select 'gc cu blocks served'    stat_name from dual union all
              select 'gc buffer busy'         stat_name from dual union all
              select 'gc cr blocks received'  stat_name from dual union all
              select 'gc cu blocks received'  stat_name from dual union all
              select 'table scans'            stat_name from dual
            ) d
      ) ss,
(select instance_number,snap_id,begin_interval_time,end_interval_time,tgets,tdbch,trds,trdds,twrs,twrds,texecs,tiffs,ttslt,tgccrr,tgccur,tgccrs,tgccus,tucm,tur
  from ((select s.instance_number,s.snap_id,e.stat_name, s.begin_interval_time,s.end_interval_time
             , (e.value - nvl(b.value,0))  value
          from dba_hist_sysstat b
             , dba_hist_sysstat e
         ,dba_hist_snapshot       s
         where b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
           and s.instance_number=e.instance_number
           and e.dbid            = b.dbid  
           and e.dbid            = b.dbid            (+)
           and e.instance_number = b.instance_number (+)
           and b.stat_id   (+)   = e.stat_id
           and e.stat_name in ('session logical reads', 'db block changes'
               ,'physical reads', 'physical reads direct'
               ,'physical writes', 'physical writes direct'
               ,'execute count'
               , 'index fast full scans (full)', 'table scans (long tables)'
               , 'gc cr blocks received', 'gc current blocks received'
               , 'gc cr blocks served', 'gc current blocks served'
               , 'user commits', 'user rollbacks'))
        pivot (sum(value) for stat_name in
              ('session logical reads'         tgets
              ,'db block changes'              tdbch
              ,'physical reads'                trds
              ,'physical reads direct'         trdds
              ,'physical writes'               twrs
              ,'physical writes direct'        twrds
              ,'execute count'                 texecs
              ,'index fast full scans (full)'  tiffs
              ,'table scans (long tables)'     ttslt
              ,'gc cr blocks received'         tgccrr
              ,'gc current blocks received'    tgccur
              ,'gc cr blocks served'           tgccrs
              ,'gc current blocks served'      tgccus
              ,'user commits'                  tucm
              ,'user rollbacks'                tur)))) f
   , dba_hist_seg_stat_obj n
 where ss.dataobj# = n.dataobj#
   and ss.obj#     = n.obj#
   and ss.dbid     = n.dbid
   -- and ss.rnk     <= &top_n_segstat
   and value       > 0
   and ss.snap_id=f.snap_id
   and ss.instance_number=f.instance_number
   and ss.snap_id between &bid and &eid and e.instance_number=&inid
order by snap_id,begintime,stat_name, value desc, object_name;

clear breaks
clear columns
clear compute