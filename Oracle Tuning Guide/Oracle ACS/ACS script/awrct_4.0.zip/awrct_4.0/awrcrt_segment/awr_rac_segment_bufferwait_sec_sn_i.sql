PROMPT ==============================================================================================
PROMPT ==AWR TOP SEGMENT BUFFER WAIT PER SECOND 2.0 ==
PROMPT ==============================================================================================
col endtime for a14
col begintime for a14
set linesize 400
set pagesize 10000
col inst for 999 heading 'INST'
col owner for a16
col tablespace_name for a18 heading 'TABLESPACE'
col object_name for a40 heading 'OBJECT';
col object_type for a20 heading 'TYPE'
col subobject_name for a11 heading 'SUBOBJECT'
col busywait for999,999,999,999  heading 'BufferBusyWait'
col ratio for 999.99 

select d.instance_number inst,to_char(d.end_interval_time,'dd/mm/yy hh24:mi') endtime,o.owner,o.object_name,o.object_type,o.tablespace_name
, round(d.ratio * 100, 2) ratio
, d.writereqs/s_et busywait
from
(select e.instance_number,s.begin_interval_time,s.end_interval_time,e.ts#,e.dataobj#, e.obj#,e.buffer_busy_waits_delta - nvl(b.buffer_busy_waits_delta, 0) writereqs,ratio_to_report(e.buffer_busy_waits_delta - nvl(b.buffer_busy_waits_delta, 0)) over (partition by e.snap_id,e.instance_number) ratio,DENSE_RANK() OVER (PARTITION BY e.snap_id,e.instance_number ORDER BY e.buffer_busy_waits_delta - nvl(b.buffer_busy_waits_delta, 0) DESC) DENSE_RANK,
86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_seg_stat  e, dba_hist_seg_stat  b
,dba_hist_snapshot       s
where b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and b.ts#(+) = e.ts#
AND b.obj#(+) = e.obj#
and e.instance_number = s.instance_number
AND b.dataobj#(+) = e.dataobj#
and e.instance_number = b.instance_number (+)
and e.dbid            = b.dbid            (+)
and e.buffer_busy_waits_delta - nvl(b.buffer_busy_waits_delta, 0)  > 0
and s.snap_id between &bid and &eid and e.instance_number=&inid) d,
dba_hist_seg_stat_obj  o
where d.obj# = o.obj#
and d.DATAOBJ# = o.DATAOBJ#
and d.ts# = d.ts#
and DENSE_RANK <= 5
order by instance_number,endtime,DENSE_RANK;