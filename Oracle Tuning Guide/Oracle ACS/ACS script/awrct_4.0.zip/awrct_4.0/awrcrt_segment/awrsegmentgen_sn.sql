set termout off
column timecol new_value timestamp 
column spool_extension new_value suffix 
select to_char(sysdate,'DD_MON_YYYY_HH24_MI_SS') timecol,'.xls' spool_extension from sys.dual; 
column output new_value dbname 
select value || '_' output from v$parameter where name = 'db_name';

set feed off markup html on spool on 
alter session set nls_date_format='YYYY-MM-DD';
set serveroutput on
set termout off
set verify off
set echo off
set pagesize 50000
spool AWRSegment_BlockChange_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_blockchange_sn_i.sql
spool off
spool AWRSegment_LogicalRead_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_buffer_sn_i.sql
spool off
spool AWRSegment_BufferWait_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_bufferwait_sn_i.sql
spool off
spool AWRSegment_GCCRBlockServed_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccrblockserved_sn_i.sql
spool off
spool AWRSegment_GCCurBlockServed_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccublockserved_sn_i.sql
spool off
spool AWRSegment_GCBusywait_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gcbusy_sn_i.sql
spool off
spool AWRSegment_GCCRBlockRecv_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccrblockrec_sn_i.sql
spool off
spool AWRSegment_GCCurBlockRecv_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_gccublockrec_sn_i.sql
spool off
spool AWRSegment_ITLWait_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_itlwait_sn_i.sql
spool off
spool AWRSegment_PhyReadDirect_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicaldirect_sn_i.sql
spool off
spool AWRSegment_PhyRead_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicalread_sn_i.sql
spool off
spool AWRSegment_PhyWrite_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_physicalwrite_sn_i.sql
spool off
spool AWRSegment_Rowlock_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_rowlock_sn_i.sql
spool off
spool AWRSegment_PhyWriteDirect_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_writedirect_sn_i.sql
spool off
spool AWRSegment_WriteRequest_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_writereqs_sn_i.sql
spool off
spool AWRSegment_ChainRow_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_chainrow_sn_i.sql
spool off
spool AWRSegment_PhyReqs_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_phyreqs_sn_i.sql
spool off
spool AWRSegment_OptimziedPhy_&&dbname&&timestamp&&suffix 
@awrcrt_segment/awr_rac_segment_optphy_sn_i.sql
spool off
set markup html off spool off

