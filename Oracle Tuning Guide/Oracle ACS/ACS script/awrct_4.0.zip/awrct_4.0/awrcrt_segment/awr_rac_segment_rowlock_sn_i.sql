PROMPT ==============================================================================================
PROMPT ==AWR SEGMENT STATISTICS ROW LOCK WAIT 2.0 ==
PROMPT ==============================================================================================
prompt
col endtime for a14
col begintime for a14
set linesize 400
set pagesize 10000
col inst for 999 heading 'INST'
col owner for a12
col tablespace_name for a13 heading 'TABLESPACE'
col object_name for a40 heading 'OBJECT';
col object_type for a20 heading 'TYPE'
col subobject_name for a11 heading 'SUBOBJECT'
col rowlockwaits for 999,999,999,999  heading 'RowLock Waits'
col ratio for 999 

select d.instance_number inst,to_char(d.begin_interval_time,'dd/mm/yy hh24:mi') begintime,to_char(d.end_interval_time,'dd/mm/yy hh24:mi') endtime,o.owner,o.tablespace_name,o.object_name,o.object_type
, d.rowlockwaits
, round(d.ratio * 100, 2) ratio from
(select e.instance_number,s.begin_interval_time,s.end_interval_time,e.ts#,e.dataobj#, e.obj#,e.row_lock_waits_delta - nvl(b.row_lock_waits_delta, 0) rowlockwaits,ratio_to_report(e.row_lock_waits_delta - nvl(b.row_lock_waits_delta, 0)) over (partition by e.snap_id,e.instance_number) ratio,DENSE_RANK() OVER (PARTITION BY e.snap_id,e.instance_number ORDER BY e.row_lock_waits_delta - nvl(b.row_lock_waits_delta, 0) DESC) DENSE_RANK
from dba_hist_seg_stat  e, dba_hist_seg_stat  b
,dba_hist_snapshot       s
where b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and b.ts#(+) = e.ts#
AND b.obj#(+) = e.obj#
and e.instance_number = s.instance_number
AND b.dataobj#(+) = e.dataobj#
and e.instance_number = b.instance_number (+)
and e.dbid            = b.dbid            (+)
and e.row_lock_waits_delta - nvl(b.row_lock_waits_delta, 0)  > 0
and s.snap_id between &bid and &eid and e.instance_number=&inid) d,
dba_hist_seg_stat_obj  o
where d.obj# = o.obj#
and d.DATAOBJ# = o.DATAOBJ#
and d.ts# = d.ts#
and DENSE_RANK <= 5
order by instance_number,begintime,DENSE_RANK;

clear breaks
clear columns
clear compute