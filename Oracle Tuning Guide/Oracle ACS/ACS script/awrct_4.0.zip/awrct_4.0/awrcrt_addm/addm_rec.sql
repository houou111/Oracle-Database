column begin_time new_value begintime 
column end_time   new_value endtime 
select min(to_char(END_INTERVAL_TIME,'DD-MON HH24:MI')) begin_time,
max(to_char(END_INTERVAL_TIME,'DD-MON HH24:MI')) end_time 
from dba_hist_snapshot where snap_id between &bid and &eid
;
set termout off
set verify off 
variable btime char(512);
variable etime char(512);
begin
:btime := '&&begintime';
:etime := '&&endtime';
end;
/


clear column
clear breaks
set termout off
column timecol new_value timestamp 
column spool_extension new_value suffix 
select to_char(sysdate,'DD_MON_YYYY_HH24_MI_SS') timecol,'.html' spool_extension from sys.dual; 
column output new_value dbname 
select value || '_' output from v$parameter where name = 'db_name';
set feed off markup html on spool on 
alter session set nls_date_format='YYYY-MM-DD';
set pagesize 10000
spool ADDM_Recommendations_&bid._&eid&&suffix 
select to_char(a.execution_end,'DD-MON HH24:MI') begintime,b.task_name,d.rank, d.type,
c.command,c.message ACTION_MESSAGE
From dba_advisor_tasks a, dba_advisor_findings b,
Dba_advisor_actions c, dba_advisor_recommendations d
Where a.owner=b.owner and a.task_id=b.task_id
And b.task_id=d.task_id and b.finding_id=d.finding_id
And a.task_id=c.task_id and d.rec_id=c.rec_Id
And a.task_name like 'ADDM%' and a.status='COMPLETED'
and to_char(a.execution_end,'DD-MON HH24:MI') between :btime and :etime
order by to_char(a.execution_end,'DD-MON HH24:MI'),d.rank;
spool off
set markup html off spool off