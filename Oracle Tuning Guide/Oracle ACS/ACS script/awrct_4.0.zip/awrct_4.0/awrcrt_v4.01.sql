﻿Rem awrcrt.sql
Rem
Rem Copyright WENJIE WANG from Oracle ACS.  
Rem Support email: valen.wang@oracle.com
Rem    NAME
Rem      awrcrt.sql
Rem
Rem    DESCRIPTION
Rem      This script defaults the dbid and instance number to that of the
Rem      current instance connected-to, then  produce
Rem      the Workload Repository CHART report.
Rem    VERSION
Rem      2.1 
Rem    MODIFIED   (MM/DD/YY)
Rem    Wang Wenjie      2015-06-12 - Created 0.1 version
Rem    Wang Wenjie      2016-03-26 - release 1.0 version
Rem    Wang Wenjie      2016-12-06 - Created 2.0 version
Rem    Ma Xuefeng       2016-01-10 - Modified, replaced sql to plsql 
Rem    Wang Wenjie      2016-01-16 - Modified, replaced sql to plsql 
Rem    Wang Wenjie      2016-01-18 - Fixed major bug
Rem    Wang Wenjie      2017-03-20 - Added IO request, IO wait time
Rem    Wang Wenjie      2017-06-09 - Removed top3 slowest datafile
Rem    Wang Wenjie      2017-06-09 - Added metric stats for logon, io, commit
Rem    Wang Wenjie      2017-07-01 - Added average IO wait time
Rem    Wang Wenjie      2017-08-15 - set arraysize 5000
Rem    Wang Wenjie      2017-09-16 - replace chart js to new version , adjust chart contents,removed a parameter
Rem    Elliot           2017-11-03 - report bug of wrong order of logon and commit data, fixed
set feedback off
set timing off
prompt
prompt Current Instance
prompt ~~~~~~~~~~~~~~~~
select d.dbid            dbid
     , d.name            db_name
     , i.instance_number inst_num
     , i.instance_name   inst_name
  from v$database d,
       v$instance i;
prompt
prompt Specify the number of days of snapshots to choose from
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
define days=&0
set linesize 999
select a.snap_id, to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') snap_time from dba_hist_snapshot a
where a.instance_number=(select b.instance_number from v$instance b) 
and a.begin_interval_time > sysdate-&days
order by 1;
/*****************************************
--parameter1 begin snap id
--parameter2 end snap id
--parameter3 split X ( input 80 for thinkpad X230,X250)
--parameter4 instance number
Author: 
Date  : 2017-01
*****************************************/
set termout       on
set echo          off
set heading       on
prompt Specify the Begin and End Snapshot Ids
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDDhh24miss') spool_time FROM dual;
COLUMN iv NEW_VALUE _iv NOPRINT
select trunc(3600*24*(sysdate+snaP_interval-sysdate)) iv from dba_hist_wr_control;
COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;
COLUMN cpucount NEW_VALUE _cpucount NOPRINT
select value cpucount from v$parameter where name ='cpu_count';
prompt begin snap id is
define bid=&1
prompt end snap id is
define eid=&2
prompt instance number is
define inid=&3
set termout       on
set echo          off
set heading       on
set long 2000000
set pages 0
set linesize 999
set termout       off
set echo          off
set feedback      off
set heading       off
set verify        off
set wrap          on 
set trimspool     on
set serveroutput on size  unlimited
set escape        on
--set arraysize 5000
COLUMN vp NEW_VALUE _vp NOPRINT
SELECT case when &eid-&bid>500 then 6  when &eid-&bid>350 then 4 else 2 end vp FROM dual;
--spool awrcrt_&_dbname._&_spool_time..html
spool awrcrt_&_dbname._&inid._&bid._&eid..html
prompt <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
prompt <html xmlns="http://www.w3.org/1999/xhtml">
prompt <head>
prompt <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
prompt <title>AWR Chart Report 2</title>
prompt <style type="text/css">body.awr {font:bold 10pt Arial,Helvetica,Geneva,sans-serif;color:black; background:White;}
prompt pre.awr  {font:8pt Courier;color:black; background:White;}h1.awr   {font:bold 20pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;border-bottom:1px solid #cccc99;margin-top:0pt; margin-bottom:0pt;padding:0px 0px 0px 0px;}
prompt h2.awr   {font:bold 18pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}
prompt h3.awr {font:bold 16pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}li.awr {font: 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;}
prompt h4.awr   {font:bold 20pt Arial,Helvetica,Geneva,sans-serif;color:#ff0000;}
prompt th.awrnobg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;padding-left:4px; padding-right:4px;padding-bottom:2px}th.awrbg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:White; background:#0066CC;padding-left:4px; padding-right:4px;padding-bottom:2px}
prompt td.awrnc {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:White;vertical-align:top;}
prompt td.awrc    {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:#FFFFCC; vertical-align:top;}
prompt a.awr {font:bold 8pt Arial,Helvetica,sans-serif;color:#663300; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}
prompt a.awrred {font:bold 9pt Arial,Helvetica,sans-serif;color:#ff0000; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}
prompt a1.awr {font:bold 10pt Arial,Helvetica,sans-serif;color:#0000FF; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}
prompt </style>
prompt <script src="crt21.js"></script>
prompt </head>
prompt <body class='awr'>
prompt <H1 class='awr'>
prompt WORKLOAD REPOSITORY CHART report for
prompt </H1>
prompt <p/>
prompt <TABLE BORDER=1 WIDTH=500>
prompt <tr><th class='awrbg'>DB Name</th><th class='awrbg'>DB Id</th><th class='awrbg'>Instance</th><th class='awrbg'>Inst num</th><th class='awrbg'>Release</th><th class='awrbg'>RAC</th><th class='awrbg'>Host</th></tr>
prompt <tr><TD class='awrnc'>
SELECT A.NAME||'</td><TD ALIGN=''right'' class=''awrnc''>'
||A.DBID||'</td><TD class=''awrnc''>'||(SELECT B.INSTANCE_NAME
||'</td><TD ALIGN=''right'' class=''awrnc''>'||&inid
||'</td><TD class=''awrnc''>'||B.VERSION 
|| '</td><TD class=''awrnc''>'
||(SELECT value FROM V$PARAMETER C WHERE C.NAME ='cluster_database')
||'</td><TD class=''awrnc''>'
||b.HOST_NAME FROM GV$INSTANCE B WHERE B.INSTANCE_NUMBER=&inid)
  FROM V$DATABASE A;
prompt </td></tr>
prompt </table>
prompt <p />
prompt <TABLE BORDER=1 WIDTH=500>
prompt <tr><th class='awrnobg'></th><th class='awrbg'>Snap Id</th><th class='awrbg'>Snap Time</th></tr>
prompt <tr><TD class='awrnc'>Begin Snap:</td><TD ALIGN='right' class='awrnc'>&bid</td><TD ALIGN='center' class='awrnc'>
select  
nvl((select to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') from dba_hist_snapshot a where a.instance_number=&inid and a.snap_id=&bid),
'minimum snap time')
from dual;
prompt </td></tr>
prompt <tr><TD class='awrc'>End Snap:</td><TD ALIGN='right' class='awrc'>&eid</td><TD ALIGN='center' class='awrc'>
select  
nvl((select to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') from dba_hist_snapshot a where a.instance_number=&inid and a.snap_id=&eid),
'maximum snap time')
from dual;
prompt </td></tr>
prompt </table>
prompt <p />
prompt <a class="awr" name="top"></a>
prompt <h2 class="awr">
prompt Database Performance and Recommendations Report
prompt </h2>
prompt <hr>
prompt <ul>

prompt <li class="awr"><a class="awr" href="#1">Average Active Session</a></li>
prompt <li class="awr"><a class="awr" href="#1_a">WaitClass By AAS</a></li>
prompt <li class="awr"><a class="awr" href="#3">WaitClass By DBTime</a></li>
prompt <li class="awr"><a class="awr" href="#2">Active Session History</a></li>
prompt <li class="awr"><a class="awr" href="#4">DBTime Ratio</a></li>
prompt <li class="awr"><a class="awr" href="#5">CPU Utilization </a></li>
prompt <li class="awr"><a class="awr" href="#6">OS Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#7">OS Load</a></li>
prompt <li class="awr"><a class="awr" href="#8">OS Free Memory</a></li>
prompt <li class="awr"><a class="awr" href="#9">Memory Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#10">Memory vs Swap</a></li>
prompt <li class="awr"><a class="awr" href="#11">SGA Breakdown</a></li>
prompt <li class="awr"><a class="awr" href="#12">Buffer Cache Waits</a></li>
prompt <li class="awr"><a class="awr" href="#13">Buffer Cache Hit Ratio</a></li>
prompt <li class="awr"><a class="awr" href="#14">PGA Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#14_a">PGA Hit Ratio</a></li>
prompt <li class="awr"><a class="awr" href="#15">PGA Effectiveness</a></li>
prompt <li class="awr"><a class="awr" href="#16">Instance Sufficient</a></li>
prompt <li class="awr"><a class="awr" href="#17">DB Calls</a></li>
prompt <li class="awr"><a class="awr" href="#18">IOPS Request Total</a></li>
prompt <li class="awr"><a class="awr" href="#19">IOPS Request BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#20">IO ThroughtPut Total</a></li>
prompt <li class="awr"><a class="awr" href="#21">IO ThroughtPut BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#22">IO Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#23">Physical Reads Breakdown</a></li>
prompt <li class="awr"><a class="awr" href="#24">Physical Writes Breakdown</a></li>
prompt <li class="awr"><a class="awr" href="#25">IO Single vs Multi</a></li>
prompt <li class="awr"><a class="awr" href="#28">IO User IO wait time</a></li>
prompt <li class="awr"><a class="awr" href="#29">IO Average IO wait time</a></li>
prompt <li class="awr"><a class="awr" href="#30">I/O Function By Throughput</a></li>
prompt <li class="awr"><a class="awr" href="#31">I/O Function By IOPS</a></li>
prompt <li class="awr"><a class="awr" href="#32">I/O FileType By Throughput</a></li>
prompt <li class="awr"><a class="awr" href="#33">I/O FileType by IOPS</a></li>
prompt <li class="awr"><a class="awr" href="#35">Time Model : DB TIME  DB CPU SQL EXEC TIME</a></li>
prompt <li class="awr"><a class="awr" href="#36">Time Model : Parse TIME</a></li>
prompt <li class="awr"><a class="awr" href="#37">SQL Execution Count and Average Execution Time </a></li>
prompt <li class="awr"><a class="awr" href="#38">Session Logic Reads</a></li>
prompt <li class="awr"><a class="awr" href="#39">Redo Wastage</a></li>
prompt <li class="awr"><a class="awr" href="#40">Redo Log Space Activity</a></li>
prompt <li class="awr"><a class="awr" href="#41">Redo Buffer Allocation Retries</a></li>
prompt <li class="awr"><a class="awr" href="#42">Undo Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#42_a">Temporarary Tablespace Activity</a></li>
prompt <li class="awr"><a class="awr" href="#42_b">Temporarary Tablespace I/O Throughput</a></li>
prompt <li class="awr"><a class="awr" href="#44">Parse count</a></li>
prompt <li class="awr"><a class="awr" href="#45">CPU Parse BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#46">Block Changes</a></li>
prompt <li class="awr"><a class="awr" href="#47">Connections</a></li>
prompt <li class="awr"><a class="awr" href="#48">User logon (MAX)</a></li>
prompt <li class="awr"><a class="awr" href="#49">Database Sorts</a></li>
prompt <li class="awr"><a class="awr" href="#50">Database Cursors</a></li>
prompt <li class="awr"><a class="awr" href="#51">SQLNet Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#52">Parallelized Executions</a></li>
prompt <li class="awr"><a class="awr" href="#53">Parallelized Operations</a></li>
prompt <li class="awr"><a class="awr" href="#91">Global Current Block Service Time</a></li>
prompt <li class="awr"><a class="awr" href="#92">Global CR Block Service Time</a></li>
prompt <li class="awr"><a class="awr" href="#93">Global Cache Log Flushes Percentage Time</a></li>
prompt <li class="awr"><a class="awr" href="#94">Global Cache Load Profile</a></li>
prompt <li class="awr"><a class="awr" href="#98">Global Cache Estd Interconnect traffic (KB)</a></li>
prompt <li class="awr"><a class="awr" href="#95">Global Cache Efficiency Percentages</a></li>
prompt <li class="awr"><a class="awr" href="#96">Global Cache and Enqueue Services - Messaging Statistics</a></li>
prompt <li class="awr"><a class="awr" href="#97">Global Cache Messaging Statistics Sent</a></li>
prompt <li class="awr"><a class="awr" href="#101">Global Cache Block Statistic</a></li>
prompt <li class="awr"><a class="awr" href="#99">GCS/GES messages </a></li>
prompt <li class="awr"><a class="awr" href="#100">Global Cache Current and CR Block Time</a></li>
prompt <li class="awr"><a class="awr" href="#102">Global CR Served Stats</a></li>
prompt <li class="awr"><a class="awr" href="#130">Library Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#131">Latch Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#132">Latch:shared pool - Get/Miss Percentage</a></li>
prompt <li class="awr"><a class="awr" href="#132_a">Latch:shared pool per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#133">Latch:row cache objects - Get/Miss Percentage </a></li>
prompt <li class="awr"><a class="awr" href="#133_a">Latch:row cache objects per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#134">Latch:cache buffers chains - Get/Miss Percentage</a></li>
prompt <li class="awr"><a class="awr" href="#134_a">Latch:cache buffers chains per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#135">Latch:cache buffers lru chain - Get/Miss Percentage</a></li>
prompt <li class="awr"><a class="awr" href="#135_a">Latch:cache buffers lru chain per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#136">Latch:gc element - Get/Miss Percentage</a></li>
prompt <li class="awr"><a class="awr" href="#136_a">Latch:gc element per second - BreakDown </a></li>
prompt <li class="awr"><a class="awr" href="#137">Latch:DML lock allocation - Get/Miss Percentage</a></li>
prompt <li class="awr"><a class="awr" href="#137_a">Latch:DML lock allocation per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#137_b">Library Cache: SQL AREA</a></li>
prompt <li class="awr"><a class="awr" href="#137_c">Library Cache: TABLE/PROCEDURE</a></li>
prompt <li class="awr"><a class="awr" href="#137_d">Library Cache: SQL AREA STATS</a></li>
prompt <li class="awr"><a class="awr" href="#137_e">Latch: Library Cache - Get/Miss Percentage </a></li>
prompt <li class="awr"><a class="awr" href="#137_f">Latch: Library Cache per second - BreakDown</a></li>
prompt <li class="awr"><a class="awr" href="#138">Chain Rows</a></li>
prompt <li class="awr"><a class="awr" href="#139">Table Scans</a></li>
prompt <li class="awr"><a class="awr" href="#140">Cell physical IO bytes eligible for predicate offload</a></li>
prompt <li class="awr"><a class="awr" href="#141">Cell physical IO bytes saved by storage index</a></li>
prompt <li class="awr"><a class="awr" href="#142">Cell physical IO interconnect bytes returned by smart scan</a></li>
prompt <li class="awr"><a class="awr" href="#143">Cell IO uncompressed bytes</a></li>
prompt <li class="awr"><a class="awr" href="#144">Cell Chain Rows</a></li>
prompt <li class="awr"><a class="awr" href="#145">Exadata Sufficient Ratio</a></li>
prompt <li class="awr"><a class="awr" href="#160">Top 5 Wait Event</a></li>
prompt <li class="awr"><a class="awr" href="#161">Top 5 Wait Event trends</a></li>



prompt </ul>
-----------------------------------------------------------------------
prompt <a class="awr" name="1"></a>
prompt <p><h3 class='awr'>Average Active Session</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_aas"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="1_a"></a>
prompt <p><h3 class='awr'>WaitClass by AAS</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_wcbyaas"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="3"></a>
prompt <p><h3 class='awr'>WaitClass By DBTime</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_wcaas"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="4"></a>
prompt <p><h3 class='awr'>DBTime Ratio</h3></p>
prompt <a1 class="awr" href="#10">Comments: snap sample interval &_iv seconds, cpu count &_cpucount</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_dbtimeratio"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="35"></a>
prompt <p><h3 class='awr'>Time Model : DB TIME DB CPU SQL EXEC TIME</h3></p>
prompt <a1 class="awr" href="#10">Comments: snap sample interval &_iv seconds, cpu count &_cpucount</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_dbtime"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="36"></a>
prompt <p><h3 class='awr'>Time Model : Parse TIME</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_parsetime"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="2"></a>
prompt <p><h3 class='awr'>Active Session History</h3> </p> 
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:450%">
prompt        <canvas width="3000px" height="200px" id="canvas_ash"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="37"></a>
prompt <p><h3 class='awr'>SQL Execution Count and Average Execution Time</h3></p>
prompt <a1 class="awr" href="#10">Comments: Unit of Time is micro second</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_sql"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="46"></a>
prompt <p><h3 class='awr'>Block Changes</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_bchange"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="38"></a>
prompt <p><h3 class='awr'>Logical Read Per Seconds</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_logic"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="23"></a>
prompt <p><h3 class='awr'>Physical Reads BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_phyreadbreak"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="24"></a>
prompt <p><h3 class='awr'>Physical Writes BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_phywrtbreak"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------
prompt <a class="awr" name="44"></a>
prompt <p><h3 class='awr'>Parse count</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_parse"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------
prompt <a class="awr" name="45"></a>
prompt <p><h3 class='awr'>CPU Parse BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_parsecpu"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="47"></a>
prompt <p><h3 class='awr'>Connections</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_conn"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="48"></a>
prompt <p><h3 class='awr'>User Logon</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_logon"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="17"></a>
prompt <p><h3 class='awr'>DB Calls</h3></p>
prompt <a1 class="awr" href="#10">Comments: snap sample interval &_iv seconds, cpu count &_cpucount</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_dbcalls"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="39"></a>
prompt <p><h3 class='awr'>Redo Wastage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_commit"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="40"></a>
prompt <p><h3 class='awr'>Redo Log Space Activity</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_redo2"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="41"></a>
prompt <p><h3 class='awr'>Redo Buffer Allocation Retries</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_redo3"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="42"></a>
prompt <p><h3 class='awr'>Undo Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_undostat"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="52"></a>
prompt <p><h3 class='awr'>Parallelized Executions</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_parallel"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="53"></a>
prompt <p><h3 class='awr'>Parallelized Operations</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_paralleloper"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="51"></a>
prompt <p><h3 class='awr'>SQLNet Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_sqlnet"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="50"></a>
prompt <p><h3 class='awr'>Cursors</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_cursor"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="138"></a>
prompt <p><h3 class='awr'>Chain Rows</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_fct"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="139"></a>
prompt <p><h3 class='awr'>Table Scans</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_tablescan"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="5"></a>
prompt <p><h3 class='awr'>Cpu Utilization</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_cpu"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="8"></a>
prompt <p><h3 class='awr'>OS Free Memory</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_memfree"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="10"></a>
prompt <p><h3 class='awr'>Memory vs Swap</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_osswap"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="7"></a>
prompt <p><h3 class='awr'>OS Load</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_osload"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="6"></a>
prompt <p><h3 class='awr'>OS Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_osstat"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="9"></a>
prompt <p><h3 class='awr'>Memory Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_memstat"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="11"></a>
prompt <p><h3 class='awr'>SGA Breakdown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_sga"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="13"></a>
prompt <p><h3 class='awr'>Buffer Cache Hit Ratio</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_bchit"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="12"></a>
prompt <p><h3 class='awr'>Buffer Cache Waits</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_buffercachewait"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------
prompt <a class="awr" name="134"></a>
prompt <p><h3 class='awr'>Latch:cache buffers chains - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchcbc"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------
prompt <a class="awr" name="134_a"></a>
prompt <p><h3 class='awr'>Latch:cache buffers chains per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_cbcbrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="135"></a>
prompt <p><h3 class='awr'>Latch:cache buffers lru chain - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchlru"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="135_a"></a>
prompt <p><h3 class='awr'>Latch:cache buffers lru chain per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_cbclrubrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------
prompt <a class="awr" name="132"></a>
prompt <p><h3 class='awr'>Latch Share Pool - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchsp"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------
prompt <a class="awr" name="132_a"></a>
prompt <p><h3 class='awr'>Latch Share Pool per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_spbrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="130"></a>
prompt <p><h3 class='awr'>Library Cache Hit Point</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_lib"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="137_e"></a>
prompt <p><h3 class='awr'>Library Cache Load Lock - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchlc"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="137_f"></a>
prompt <p><h3 class='awr'>Library Cache Load Lock per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_lcbrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="137_b"></a>
prompt <p><h3 class='awr'>Library Cache: SQL AREA</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_libsqlarea"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="137_c"></a>
prompt <p><h3 class='awr'>Library Cache: TABLE/PROCEDURE</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_libtabpro"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="137_d"></a>
prompt <p><h3 class='awr'>Library Cache: SQL AREA STATS</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_libsqlareastat"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="14"></a>
prompt <p><h3 class='awr'>PGA Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_pgastatictis"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="14_a"></a>
prompt <p><h3 class='awr'>PGA Hit Ratio</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_pgahitratio"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="15"></a>
prompt <p><h3 class='awr'>PGA Effectiveness</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_pgaeff"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="49"></a>
prompt <p><h3 class='awr'>Sorts</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_sort"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="131"></a>
prompt <p><h3 class='awr'>Latch Hit Point</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latch"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------
prompt <a class="awr" name="133"></a>
prompt <p><h3 class='awr'>Latch:row cache objects - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchrco"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------
prompt <a class="awr" name="133_a"></a>
prompt <p><h3 class='awr'>Latch:row cache objects per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_rcobrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="136"></a>
prompt <p><h3 class='awr'>Latch:gc element - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchgc"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="136_a"></a>
prompt <p><h3 class='awr'>Latch:gc element per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gcbrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="137"></a>
prompt <p><h3 class='awr'>Latch:DML lock allocation - Get/Miss Percentage</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_latchdml"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
--------------------------------------------------------------------------
prompt <a class="awr" name="137_a"></a>
prompt <p><h3 class='awr'>Latch:DML lock allocation per second - BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_dmlbrk"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-----------------------------------------------------------------------
prompt <a class="awr" name="16"></a>
prompt <p><h3 class='awr'>Instance Sufficient</h3></p>
prompt <a1 class="awr" href="#10">Comments: snap sample interval &_iv seconds, cpu count &_cpucount</a1>
prompt 	<div style="width:100%;">
prompt 		<canvas width="1800" height="600" id="canvas_instancesuff"></canvas>
prompt 	</div>
prompt 	<a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="22"></a>
prompt <p><h3 class='awr'>IO Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iostatistic"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="25"></a>
prompt <p><h3 class='awr'>IO Single vs Multi</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iosm"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="18"></a>
prompt <p><h3 class='awr'>IOPS Request Total</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iopsbreakdown"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="19"></a>
prompt <p><h3 class='awr'>IOPS Request Breakdown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iops"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="36"></a>
prompt <p><h3 class='awr'>IOPS ThroughtPut Total</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_throughputtotal"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="21"></a>
prompt <p><h3 class='awr'>IOPS ThroughtPut BreakDown</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_throughput"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="30"></a>
prompt <p><h3 class='awr'>I/O Function By Throughput</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iofthpt"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="31"></a>
prompt <p><h3 class='awr'>I/O Function By IOPS</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_iofiops"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="32"></a>
prompt <p><h3 class='awr'>I/O FileType By Throughput</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_ioftthpt"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="33"></a>
prompt <p><h3 class='awr'>I/O FileType By IOPS</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_ioftiops"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="42_a"></a>
prompt <p><h3 class='awr'>Temporary Tablespace Activity</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_tempact"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------------
prompt <a class="awr" name="29"></a>
prompt <p><h3 class='awr'>Average IO wait time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_avgio"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------------
prompt <a class="awr" name="28"></a>
prompt <p><h3 class='awr'>User IO wait time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_userio"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------------------------
prompt <a class="awr" name="42_b"></a>
prompt <p><h3 class='awr'>Temporary Tablespace I/O Throughput</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas width="1800" height="600" id="canvas_tempiothpt"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="94"></a>
prompt <p><h3 class='awr'>Global Cache Load Profile</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gllp"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="98"></a>
prompt <p><h3 class='awr'>Global Cache Estd Interconnect traffic (KB)</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glinter"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------------
prompt <a class="awr" name="99"></a>
prompt <p><h3 class='awr'>GCS/GES Messages </h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gcms"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
---------------------------------------------------------------
prompt <a class="awr" name="101"></a>
prompt <p><h3 class='awr'>Global Cache Block Statistic</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gclost"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="91"></a>
prompt <p><h3 class='awr'>Global Current Block Service Time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glcur"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="92"></a>
prompt <p><h3 class='awr'>Global CR Block Service Time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glcr"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="95"></a>
prompt <p><h3 class='awr'>Global Cache Efficiency Percentages</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glep"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="93"></a>
prompt <p><h3 class='awr'>Global Cache Log Flushes Percentage Time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glper"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="96"></a>
prompt <p><h3 class='awr'>Global Cache and Enqueue Services - Messaging Statistics</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gles"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------
prompt <a class="awr" name="97"></a>
prompt <p><h3 class='awr'>Global Cache Messaging Statistics Sent</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glesper"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="102"></a>
prompt <p><h3 class='awr'>Global CR Served Stats</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_glcrss"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
----------------------------------------------------------
prompt <a class="awr" name="100"></a>
prompt <p><h3 class='awr'>Global Cache CR/Current Average Time</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_gcb"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="50"></a>
prompt <p><h3 class='awr'>Cell physical IO MB eligible for predicate offload</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_e1"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="141"></a>
prompt <p><h3 class='awr'>Cell physical IO MB saved by storage index</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_e2"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="142"></a>
prompt <p><h3 class='awr'>Cell physical IO interconnect MB returned by smart scan</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_e3"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="143"></a>
prompt <p><h3 class='awr'>Cell IO uncompressed MB</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_e4"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="145"></a>
prompt <p><h3 class='awr'>Exadata Sufficient Ratio</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_fchit"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="144"></a>
prompt <p><h3 class='awr'>Chain Rows By Cells</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_chainrowcell"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
-------------------------------------------------------------------------
prompt <a class="awr" name="160"></a>
prompt <p><h3 class='awr'>Top5 Wait Event</h3></p>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:100%;">
prompt <canvas  width="1800" height="600" id="canvas_event"></canvas>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
------------------------------------------------
prompt <a class="awr" name="161"></a>
prompt <p><h3 class='awr'>Top 5 Wait Event trends </h3></p>
prompt <div style="width:75%">
prompt <div>


declare
vevent varchar2(100);  
vtime number;
vavgtime number;
vpctwt number;
vwaits number;
vwaitclass varchar2(100);
vbid number ;
veid number ;
vinid number:=&inid;
startid number:=&bid;
endid number:=&eid;
vstarttime varchar2(200);
vendtime varchar2(200);
cursor c1 is
SELECT EVENT,
       WAITS,
       trunc(TIME,2),
       trunc(DECODE(WAITS,
              NULL,
              TO_NUMBER(NULL),
              0,
              TO_NUMBER(NULL),
              TIME / WAITS * 1000),2) AVGWT,
       trunc(PCTWTT,2) ,
       WAIT_CLASS
  FROM (SELECT EVENT, WAITS, TIME, PCTWTT, WAIT_CLASS
          FROM (SELECT E.EVENT_NAME EVENT,
                       E.TOTAL_WAITS_FG - NVL(B.TOTAL_WAITS_FG, 0) WAITS,
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       1000000 TIME,
                       100 *
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       E.WAIT_CLASS WAIT_CLASS
                  FROM DBA_HIST_SYSTEM_EVENT B, DBA_HIST_SYSTEM_EVENT E
                 WHERE B.SNAP_ID(+) = vbid
                   AND E.SNAP_ID = veid
                   AND B.INSTANCE_NUMBER(+) = vinid
                   AND E.INSTANCE_NUMBER = vinid
                   AND B.EVENT_ID(+) = E.EVENT_ID
                   AND E.TOTAL_WAITS > NVL(B.TOTAL_WAITS, 0)
                   AND E.WAIT_CLASS != 'Idle'
                UNION ALL
                SELECT 'CPU time' EVENT,
                       TO_NUMBER(NULL) WAITS,
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB CPU')) / 1000000 TIME,
                       100 * ((SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL e
                                WHERE e.SNAP_ID = veid
                                  AND e.INSTANCE_NUMBER = vinid
                                  AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL b
                                WHERE b.SNAP_ID = vbid
                                  AND b.INSTANCE_NUMBER = vinid
                                  AND b.STAT_NAME = 'DB CPU')) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       NULL WAIT_CLASS
                  from dual
                 WHERE ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB CPU')) > 0)
         ORDER BY TIME DESC, WAITS DESC)
 WHERE ROWNUM <= 5;
begin
  for i in startid..endid-1 loop
    vbid:=i;
    veid:=i+1;
     select to_char(a.end_interval_time,'yyyy-mm-dd hh24:mi') into vstarttime from dba_hist_snapshot a where snap_id=vbid and instance_number=&inid;
     select to_char(a.end_interval_time,'yyyy-mm-dd hh24:mi') into vendtime from dba_hist_snapshot a where snap_id=veid and instance_number=&inid;
     dbms_output.put_line('<table border="1" width="50%" ><tr><th class="awrbg" scope="col" colspan="6">'||vstarttime||' to '||vendtime);
     dbms_output.put_line('</th></tr><tr><th class="awrbg" scope="col">Event</th><th class="awrbg" scope="col">Waits</th>');
     dbms_output.put_line('<th class="awrbg" scope="col">Time(s)</th><th class="awrbg" scope="col">Avg wait (ms)</th><th class="awrbg" scope="col">% DB time</th><th class="awrbg" scope="col">Wait Class</th></tr>');

  open c1;
  loop
  fetch c1 into vevent,vwaits,vtime,vavgtime,vpctwt,vwaitclass;
  exit when c1%notfound;

   dbms_output.put_line( '<tr>' );
  dbms_output.put_line('<td scope="row" class=''awrc''>'||vevent||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vwaits||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vtime||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vavgtime||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vpctwt||'</td>' );
   dbms_output.put_line('<td class=''awrc''>'||vwaitclass||'</td>' );
  dbms_output.put_line('</tr>' );
  end loop;
  close c1;
   dbms_output.put_line('</table><p />');
  end loop;
end;
/

prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 	<script>	
------------------------cpu---------------------------------------
prompt  
prompt  
declare
TYPE ValueList IS TABLE OF varchar2(200);
backdbcpu ValueList;
servercpu ValueList;
dbcpu ValueList;
snaptime ValueList;
cpu_cur SYS_REFCURSOR;
v_backdb_cpu varchar2(200);
v_server_cpu varchar2(200);
v_db_cpu varchar2(200);
v_snap_time varchar2(200);
begin
  dbms_output.put_line('var cpudata = { type: "line", data: { labels: [' );
open cpu_cur for
select  
       sum(case
   when e.metric_name = 'Background CPU Usage Per Sec' then
    e.pct
   else
    0
 end) backdb_cpu,
       sum(case
   when e.metric_name = 'Host CPU Utilization (%)' then
    e.pct
   else
    0
 end) server_cpu,
       sum(case
   when e.metric_name = 'CPU Usage Per Sec' then
    e.pct
   else
    0
 end) db_cpu, 
 (select '"'||to_char(f.end_interval_time, 'mm-dd hh24:mi')||'"'
from dba_hist_snapshot f
         where f.snap_id = e.snap_id
 and f.instance_number = &inid) snap_time
  from (select a.snap_id,
     trunc(decode(a.METRIC_NAME,
        'Host CPU Utilization (%)',
        a.average,
        'CPU Usage Per Sec',
        a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100, 
        a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100,
        a.average),
 2) pct,
     a.METRIC_NAME,
     a.METRIC_UNIT
from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid and a.snap_id <=&eid  
 and a.instance_number = &inid
 and a.METRIC_NAME in
     ('Host CPU Utilization (%)',
      'CPU Usage Per Sec',
      'Background CPU Usage Per Sec')
         order by 1, 3) e
 group by snap_id
 order by snap_id;
  FETCH cpu_cur BULK COLLECT INTO backdbcpu,servercpu,dbcpu,snaptime;
 close cpu_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 backdbcpu.extend;
 backdbcpu(1):='0';
 servercpu.extend;
 servercpu(1):=0;
 dbcpu.extend;
 dbcpu(1):=0;
 end if;
-----------------------------------------
FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],datasets: [{');
DBMS_OUTPUT.PUT_LINE ('label: "Backup CPU",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(255, 255, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(128, 128, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');        
-----------------------------------------
FOR i IN backdbcpu.FIRST .. backdbcpu.LAST
LOOP
  if(i<backdbcpu.count) then
DBMS_OUTPUT.PUT_LINE (backdbcpu(i)||',');
elsif(i=backdbcpu.count) then
DBMS_OUTPUT.PUT_LINE (backdbcpu(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
DBMS_OUTPUT.PUT_LINE ('label: "Database CPU",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(0, 0, 0, 128)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(0, 0, 255, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN dbcpu.FIRST .. dbcpu.LAST
LOOP
  if(i<dbcpu.count) then
DBMS_OUTPUT.PUT_LINE (dbcpu(i)||',');
elsif(i=dbcpu.count) then
DBMS_OUTPUT.PUT_LINE (dbcpu(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
DBMS_OUTPUT.PUT_LINE ('label: "Server CPU",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(0, 128, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(0, 255, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN servercpu.FIRST .. servercpu.LAST
LOOP
  if(i<servercpu.count) then
DBMS_OUTPUT.PUT_LINE (servercpu(i)||',');
elsif(i=servercpu.count) then
DBMS_OUTPUT.PUT_LINE (servercpu(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('],},]},');
DBMS_OUTPUT.PUT_LINE('			options: {');
DBMS_OUTPUT.PUT_LINE('				responsive: true,');
DBMS_OUTPUT.PUT_LINE('				title:{');
DBMS_OUTPUT.PUT_LINE('					display:true,');
DBMS_OUTPUT.PUT_LINE('					text:"&_dbname&inid - CPU Utilization"');
DBMS_OUTPUT.PUT_LINE('				},');
DBMS_OUTPUT.PUT_LINE('				tooltips: {');
DBMS_OUTPUT.PUT_LINE('					mode: "index",');
DBMS_OUTPUT.PUT_LINE('				},');
DBMS_OUTPUT.PUT_LINE('				hover: {');
DBMS_OUTPUT.PUT_LINE('					mode: "index"');
DBMS_OUTPUT.PUT_LINE('				},');
DBMS_OUTPUT.PUT_LINE('				scales: {');
DBMS_OUTPUT.PUT_LINE('					xAxes: [{');
DBMS_OUTPUT.PUT_LINE('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('							display: true,');
DBMS_OUTPUT.PUT_LINE('							labelString: "Snap Time"');
DBMS_OUTPUT.PUT_LINE('						}');
DBMS_OUTPUT.PUT_LINE('					}],');
DBMS_OUTPUT.PUT_LINE('					yAxes: [{');
DBMS_OUTPUT.PUT_LINE('						stacked: false,');
DBMS_OUTPUT.PUT_LINE('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('							display: true,');
DBMS_OUTPUT.PUT_LINE('							labelString: "Percentage"');
DBMS_OUTPUT.PUT_LINE('						}');
DBMS_OUTPUT.PUT_LINE('					}]');
DBMS_OUTPUT.PUT_LINE('				}');
DBMS_OUTPUT.PUT_LINE('			}');
DBMS_OUTPUT.PUT_LINE('		};');
  end;
  /
  
---------------------------------WaitClass By DBTime----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  cpu     ValueList; 
  user    ValueList;
  sys      ValueList;
  adm       ValueList;
  con       ValueList;
  clus       ValueList;
  com       ValueList;
  conf       ValueList;
  app       ValueList;
  que       ValueList;
  net       ValueList;
  sch       ValueList;
  oth       ValueList;
  cpuw       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var wcbyaas = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select sum(dbc)/s.s_et/1000000     cpu
	 , sum(usr_io)/s_et/1000000   userio
     , sum(sys_io)/s.s_et/1000000   systemio
	 , sum(adm)/s.s_et/1000000   adm
     , sum(conc)/s.s_et/1000000     concur
     , sum(clu)/s.s_et/1000000      clus	 
     , sum(comm)/s.s_et/1000000     commit
     , sum(conf)/s.s_et/1000000     config
     , sum(appl)/s.s_et/1000000     app
	 , sum(que)/s.s_et/1000000     queue
     , sum(netw)/s.s_et/1000000     net
     , sum(sch)/s.s_et/1000000     schedule
	 , sum(other)/s.s_et/1000000    other
	 ,sum(dbt-(dbc+usr_io+sys_io+adm+conc+clu-comm+conf+appl+que+netw+sch+other))/s.s_et/1000000 cpuwait
	 ,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,s.snap_id
  from (
select snap_id,instance_number,end_interval_time,s_et,
SUM(CASE wait_class WHEN 'User I/O'           THEN twm ELSE 0 END) usr_io,
SUM(CASE wait_class WHEN 'System I/O'           THEN twm ELSE 0 END) sys_io,
SUM(CASE wait_class WHEN 'Other'           THEN twm ELSE 0 END) other,
SUM(CASE wait_class WHEN 'Application'           THEN twm ELSE 0 END) appl,
SUM(CASE wait_class WHEN 'Commit'           THEN twm ELSE 0 END) comm,
SUM(CASE wait_class WHEN 'Concurrency'           THEN twm ELSE 0 END) conc,
SUM(CASE wait_class WHEN 'Configuration'           THEN twm ELSE 0 END) conf,
SUM(CASE wait_class WHEN 'Network'           THEN twm ELSE 0 END) netw,
SUM(CASE wait_class WHEN 'Cluster'           THEN twm ELSE 0 END) clu,
SUM(CASE wait_class WHEN 'Queueing'           THEN twm ELSE 0 END) que,
SUM(CASE wait_class WHEN 'Scheduler'           THEN twm ELSE 0 END) sch,
SUM(CASE wait_class WHEN 'Administrative'           THEN twm ELSE 0 END) adm
from (select s.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time
           , e.wait_class                                 wait_class
           , sum(case when e.time_waited_micro_fg is not null
                  then e.time_waited_micro_fg - nvl(b.time_waited_micro_fg,0)
                  else (e.time_waited_micro - nvl(b.time_waited_micro,0))
                        - greatest(0,(nvl(ebg.time_waited_micro,0) - nvl(bbg.time_waited_micro,0)))
             end)                                             twm
			 ,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
        from dba_hist_system_event b
           , dba_hist_system_event e
           , dba_hist_bg_event_summary bbg
           , dba_hist_bg_event_summary ebg
           ,dba_hist_snapshot       s
       where b.snap_id = s.snap_id - 1
         and e.snap_id      = s.snap_id
         and bbg.snap_id = s.snap_id - 1 
         and ebg.snap_id = s.snap_id
         and e.instance_number=s.instance_number
         and ebg.instance_number=s.instance_number      
         and e.dbid            = b.dbid (+)
         and e.instance_number = b.instance_number (+)
         and e.event_id        = b.event_id (+)
         and e.dbid            = ebg.dbid (+)
         and e.instance_number = ebg.instance_number (+)
         and e.event_id        = ebg.event_id (+)
         and e.dbid            = bbg.dbid (+)
         and e.instance_number = bbg.instance_number (+)
         and e.event_id        = bbg.event_id (+)
         and e.total_waits     > nvl(b.total_waits,0)
         and e.wait_class     != 'Idle'
       group by s.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time,s.begin_interval_time,e.wait_class)
group by snap_id,instance_number,end_interval_time,s_et) s
  , ((select se.instance_number,se.snap_id,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime
  						, TO_CHAR(s.end_interval_time, 'mm/dd/yyyy HH24:MI')   endtime
             , se.stat_name
             , ((se.value - nvl(sb.value,0)))  value
          from dba_hist_sys_time_model sb
             , dba_hist_sys_time_model se
             ,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           AND se.instance_number = s.instance_number
           and se.stat_name       = sb.stat_name
           and se.stat_name       in ('DB time','DB CPU'))
     pivot (sum(value) for stat_name in (
            'DB time'         dbt
          , 'DB CPU'          dbc))) st
where s.instance_number = st.instance_number
and s.snap_id=st.snap_id
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
 group by s.end_interval_time,s.s_et,s.snap_id
 order by snap_time;
  Fetch se_cur bulk collect
    into cpu,user,sys,adm,con,clus,com,conf,app,que,net,sch,oth,cpuw,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cpu.extend;
 cpu(1):='0';
 user.extend;
 user(1):='0';
 sys.extend;
 sys(1):='0';
 adm.extend;
 adm(1):='0';
 con.extend;
 con(1):='0';
 clus.extend;
 clus(1):='0';
  com.extend;
 com(1):='0';
  conf.extend;
 conf(1):='0';
  app.extend;
 app(1):='0';
  que.extend;
 que(1):='0';
   net.extend;
 net(1):='0';
  sch.extend;
 sch(1):='0';
  oth.extend;
 oth(1):='0';
 cpuw.extend;
 cpuw(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "CPU",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN cpu.FIRST .. cpu.LAST LOOP
    if (i < cpu.count) then
      DBMS_OUTPUT.PUT_LINE(cpu(i) || ',');
    elsif (i = cpu.count) then
      DBMS_OUTPUT.PUT_LINE(cpu(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "CPU Wait",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN cpuw.FIRST .. cpuw.LAST LOOP
    if (i < cpuw.count) then
      DBMS_OUTPUT.PUT_LINE(cpuw(i) || ',');
    elsif (i = cpuw.count) then
      DBMS_OUTPUT.PUT_LINE(cpuw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "User I/O",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN user.FIRST .. user.LAST LOOP
    if (i < user.count) then
      DBMS_OUTPUT.PUT_LINE(user(i) || ',');
    elsif (i = user.count) then
      DBMS_OUTPUT.PUT_LINE(user(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "System I/O",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sys.FIRST .. sys.LAST LOOP
    if (i < sys.count) then
      DBMS_OUTPUT.PUT_LINE(sys(i) || ',');
    elsif (i = sys.count) then
      DBMS_OUTPUT.PUT_LINE(sys(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Administrator",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN adm.FIRST .. adm.LAST LOOP
    if (i < adm.count) then
      DBMS_OUTPUT.PUT_LINE(adm(i) || ',');
    elsif (i = adm.count) then
      DBMS_OUTPUT.PUT_LINE(adm(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Concurrency",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN con.FIRST .. con.LAST LOOP
    if (i < con.count) then
      DBMS_OUTPUT.PUT_LINE(con(i) || ',');
    elsif (i = con.count) then
      DBMS_OUTPUT.PUT_LINE(con(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cluster",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN clus.FIRST .. clus.LAST LOOP
    if (i < clus.count) then
      DBMS_OUTPUT.PUT_LINE(clus(i) || ',');
    elsif (i = clus.count) then
      DBMS_OUTPUT.PUT_LINE(clus(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Commit",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN com.FIRST .. com.LAST LOOP
    if (i < com.count) then
      DBMS_OUTPUT.PUT_LINE(com(i) || ',');
    elsif (i = com.count) then
      DBMS_OUTPUT.PUT_LINE(com(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Configuration",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN conf.FIRST .. conf.LAST LOOP
    if (i < conf.count) then
      DBMS_OUTPUT.PUT_LINE(conf(i) || ',');
    elsif (i = conf.count) then
      DBMS_OUTPUT.PUT_LINE(conf(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Application",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN app.FIRST .. app.LAST LOOP
    if (i < app.count) then
      DBMS_OUTPUT.PUT_LINE(app(i) || ',');
    elsif (i = app.count) then
      DBMS_OUTPUT.PUT_LINE(app(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Queueing",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN que.FIRST .. que.LAST LOOP
    if (i < que.count) then
      DBMS_OUTPUT.PUT_LINE(que(i) || ',');
    elsif (i = que.count) then
      DBMS_OUTPUT.PUT_LINE(que(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Network",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN net.FIRST .. net.LAST LOOP
    if (i < net.count) then
      DBMS_OUTPUT.PUT_LINE(net(i) || ',');
    elsif (i = net.count) then
      DBMS_OUTPUT.PUT_LINE(net(i));
    end if;
  END LOOP; 
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Scheduler",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sch.FIRST .. sch.LAST LOOP
    if (i < sch.count) then
      DBMS_OUTPUT.PUT_LINE(sch(i) || ',');
    elsif (i = sch.count) then
      DBMS_OUTPUT.PUT_LINE(sch(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;   
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - WaitClass By AAS"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "WaitClass By AAS"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "AAS" ');
dbms_output.put_line('} }] } } };           ');
END;
/

declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  cpu     ValueList; 
  user    ValueList;
  sys      ValueList;
  adm       ValueList;
  con       ValueList;
  clus       ValueList;
  com       ValueList;
  conf       ValueList;
  app       ValueList;
  que       ValueList;
  net       ValueList;
  sch       ValueList;
  oth       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var wcaas = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select sum(dbc)   /decode(st.dbt,0,null,st.dbt)*100      cpu
	 , sum(usr_io)/decode(st.dbt,0,null,st.dbt)*100   userio
     , sum(sys_io)/decode(st.dbt,0,null,st.dbt)*100   systemio
	 , sum(adm)/decode(st.dbt,0,null,st.dbt)*100   adm
     , sum(conc)  /decode(st.dbt,0,null,st.dbt)*100     concur
     , sum(clu)   /decode(st.dbt,0,null,st.dbt)*100      clus	 
     , sum(comm)  /decode(st.dbt,0,null,st.dbt)*100     commit
     , sum(conf)  /decode(st.dbt,0,null,st.dbt)*100     config
     , sum(appl)  /decode(st.dbt,0,null,st.dbt)*100     app
	 , sum(que)  /decode(st.dbt,0,null,st.dbt)*100     queue
     , sum(netw)  /decode(st.dbt,0,null,st.dbt)*100     net
     , sum(sch)  /decode(st.dbt,0,null,st.dbt)*100     schedule
	 , sum(other) /decode(st.dbt,0,null,st.dbt)*100    other
     ,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,s.snap_id
  from (
    select * from (select s.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time
           , e.wait_class                                 wait_class
           , sum(case when e.time_waited_micro_fg is not null
                  then e.time_waited_micro_fg - nvl(b.time_waited_micro_fg,0)
                  else (e.time_waited_micro - nvl(b.time_waited_micro,0))
                        - greatest(0,(nvl(ebg.time_waited_micro,0) - nvl(bbg.time_waited_micro,0)))
             end)                                             twm
        from dba_hist_system_event b
           , dba_hist_system_event e
           , dba_hist_bg_event_summary bbg
           , dba_hist_bg_event_summary ebg
           ,dba_hist_snapshot       s
       where b.snap_id = s.snap_id - 1
         and e.snap_id      = s.snap_id
         and bbg.snap_id = s.snap_id - 1 
         and ebg.snap_id = s.snap_id
         and e.instance_number=s.instance_number
         and ebg.instance_number=s.instance_number      
         and e.dbid            = b.dbid (+)
         and e.instance_number = b.instance_number (+)
         and e.event_id        = b.event_id (+)
         and e.dbid            = ebg.dbid (+)
         and e.instance_number = ebg.instance_number (+)
         and e.event_id        = ebg.event_id (+)
         and e.dbid            = bbg.dbid (+)
         and e.instance_number = bbg.instance_number (+)
         and e.event_id        = bbg.event_id (+)
         and e.total_waits     > nvl(b.total_waits,0)
         and e.wait_class     != 'Idle'
       group by s.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time,e.wait_class)
        pivot (sum(twm) for wait_class in (
        'User I/O'             usr_io
      , 'System I/O'           sys_io
      , 'Other'                 other
      , 'Application'            appl
      , 'Commit'                 comm
      , 'Concurrency'            conc
      , 'Configuration'          conf
      , 'Network'                netw
      , 'Cluster'                 clu
	  ,'Queueing' 				que
	  ,'Scheduler'				sch
	  ,'Administrative'			adm)) ) s
  , ((select se.instance_number,se.snap_id,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') endtime
  						, TO_CHAR(s.end_interval_time, 'mm/dd/yyyy HH24:MI')   begintime
             , se.stat_name
             , ((se.value - nvl(sb.value,0)))  value
          from dba_hist_sys_time_model sb
             , dba_hist_sys_time_model se
             ,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           AND se.instance_number = s.instance_number
           and se.stat_name       = sb.stat_name
           and se.stat_name       in ('DB time','DB CPU'))
     pivot (sum(value) for stat_name in (
            'DB time'         dbt
          , 'DB CPU'          dbc))) st
where s.instance_number = st.instance_number
and s.snap_id=st.snap_id
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
 group by s.end_interval_time,st.dbt,s.snap_id
 order by snap_time;
  Fetch se_cur bulk collect
    into cpu,user,sys,adm,con,clus,com,conf,app,que,net,sch,oth,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cpu.extend;
 cpu(1):='0';
 user.extend;
 user(1):='0';
 sys.extend;
 sys(1):='0';
 adm.extend;
 adm(1):='0';
 con.extend;
 con(1):='0';
 clus.extend;
 clus(1):='0';
  com.extend;
 com(1):='0';
  conf.extend;
 conf(1):='0';
  app.extend;
 app(1):='0';
  que.extend;
 que(1):='0';
   net.extend;
 net(1):='0';
  sch.extend;
 sch(1):='0';
  oth.extend;
 oth(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "CPU",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN cpu.FIRST .. cpu.LAST LOOP
    if (i < cpu.count) then
      DBMS_OUTPUT.PUT_LINE(cpu(i) || ',');
    elsif (i = cpu.count) then
      DBMS_OUTPUT.PUT_LINE(cpu(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "User I/O",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN user.FIRST .. user.LAST LOOP
    if (i < user.count) then
      DBMS_OUTPUT.PUT_LINE(user(i) || ',');
    elsif (i = user.count) then
      DBMS_OUTPUT.PUT_LINE(user(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "System I/O",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sys.FIRST .. sys.LAST LOOP
    if (i < sys.count) then
      DBMS_OUTPUT.PUT_LINE(sys(i) || ',');
    elsif (i = sys.count) then
      DBMS_OUTPUT.PUT_LINE(sys(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Administrator",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN adm.FIRST .. adm.LAST LOOP
    if (i < adm.count) then
      DBMS_OUTPUT.PUT_LINE(adm(i) || ',');
    elsif (i = adm.count) then
      DBMS_OUTPUT.PUT_LINE(adm(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Concurrency",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN con.FIRST .. con.LAST LOOP
    if (i < con.count) then
      DBMS_OUTPUT.PUT_LINE(con(i) || ',');
    elsif (i = con.count) then
      DBMS_OUTPUT.PUT_LINE(con(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cluster",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN clus.FIRST .. clus.LAST LOOP
    if (i < clus.count) then
      DBMS_OUTPUT.PUT_LINE(clus(i) || ',');
    elsif (i = clus.count) then
      DBMS_OUTPUT.PUT_LINE(clus(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Commit",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN com.FIRST .. com.LAST LOOP
    if (i < com.count) then
      DBMS_OUTPUT.PUT_LINE(com(i) || ',');
    elsif (i = com.count) then
      DBMS_OUTPUT.PUT_LINE(com(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Configuration",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN conf.FIRST .. conf.LAST LOOP
    if (i < conf.count) then
      DBMS_OUTPUT.PUT_LINE(conf(i) || ',');
    elsif (i = conf.count) then
      DBMS_OUTPUT.PUT_LINE(conf(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Application",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN app.FIRST .. app.LAST LOOP
    if (i < app.count) then
      DBMS_OUTPUT.PUT_LINE(app(i) || ',');
    elsif (i = app.count) then
      DBMS_OUTPUT.PUT_LINE(app(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Queueing",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN que.FIRST .. que.LAST LOOP
    if (i < que.count) then
      DBMS_OUTPUT.PUT_LINE(que(i) || ',');
    elsif (i = que.count) then
      DBMS_OUTPUT.PUT_LINE(que(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Network",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN net.FIRST .. net.LAST LOOP
    if (i < net.count) then
      DBMS_OUTPUT.PUT_LINE(net(i) || ',');
    elsif (i = net.count) then
      DBMS_OUTPUT.PUT_LINE(net(i));
    end if;
  END LOOP; 
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Scheduler",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sch.FIRST .. sch.LAST LOOP
    if (i < sch.count) then
      DBMS_OUTPUT.PUT_LINE(sch(i) || ',');
    elsif (i = sch.count) then
      DBMS_OUTPUT.PUT_LINE(sch(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;   
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - WaitClass By DBTime"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "WaitClass By DBTime"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Percentage" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------WaitClass By DBTime----------------------------------
----------------------------DB Time Ratio-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  waitper ValueList; ---max logon
  cpuper ValueList;
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var waitratio = { type: "line", data: { labels: [');     
  OPEN CR_CUR FOR 
select sum(a1.waitratio),sum(a1.cpuratio),
        (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
             from dba_hist_snapshot f
            where f.snap_id = a1.snap_id
              and f.instance_number = &inid) snap_time
  from (select a.snap_id,
               case
                 when metric_name = 'Database CPU Time Ratio' then
                   trunc(a.average) 
                 else
                  0
               end cpuratio,
               case
                 when metric_name = 'Database Wait Time Ratio' then
                   trunc(a.average) 
                 else
                  0
               end waitratio
          from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid
           and a.snap_id <= &eid
           and a.instance_number = &inid
         and a.metric_name in
               ('Database CPU Time Ratio','Database Wait Time Ratio'
                )) a1
 group by a1.snap_id order by a1.snap_id;
    FETCH CR_CUR     BULK COLLECT    INTO waitper,cpuper,SNAPTIME;
    close CR_CUR;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 waitper.extend;
 waitper(1):='0';
 cpuper.extend;
 cpuper(1):='0';
end if;
-----------------------------------------  
    FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{'); 
dbms_output.put_line('label: "Wait Ratio",'); 
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,'); 
dbms_output.put_line('borderColor: window.awrColors.red2,'); 
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN waitper.FIRST .. waitper.LAST
LOOP
  if(i<waitper.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (waitper(i)||',');
end if;
elsif(i=waitper.count) then
DBMS_OUTPUT.PUT_LINE (waitper(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, }, {'); 
dbms_output.put_line('label: "CPU Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: true,');
dbms_output.put_line('backgroundColor: window.awrColors.blue1,');
dbms_output.put_line('borderColor: window.awrColors.blue2,');
dbms_output.put_line('data: [');
 FOR i IN cpuper.FIRST .. cpuper.LAST
LOOP
  if(i<cpuper.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (cpuper(i)||',');
end if;
elsif(i=cpuper.count) then
DBMS_OUTPUT.PUT_LINE (cpuper(i));
end if;
END LOOP;
dbms_output.put_line('], }] },                    ');
dbms_output.put_line('options: {                  ');
dbms_output.put_line('responsive: true,           ');
dbms_output.put_line('title:{                     ');
dbms_output.put_line('display:true,               ');
dbms_output.put_line('text:"&_dbname&inid - DBTime Ratio"');
dbms_output.put_line('},                          ');
dbms_output.put_line('tooltips: {                 ');
dbms_output.put_line('mode: "index",              ');
dbms_output.put_line('intersect: false,           ');
dbms_output.put_line('},                          ');
dbms_output.put_line('hover: {                    ');
dbms_output.put_line('mode: "nearest",            ');
dbms_output.put_line('intersect: true             ');
dbms_output.put_line('},                          ');
dbms_output.put_line('scales: {                   ');
dbms_output.put_line('xAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString: "DBTime Ratio"         ');
dbms_output.put_line('}                           ');
dbms_output.put_line('}],                         ');
dbms_output.put_line('yAxes: [{                   ');
dbms_output.put_line('display: true,              ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString:  "Percentage"       ');
dbms_output.put_line('} }] } } };                 ');
end;
/

----------------------------DB Time Ratio End-----------------------------
---------------dbtime---------------------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
dbtime ValueList;
cputime ValueList;
sqltime ValueList;
dbcpu ValueList;
snaptime ValueList;
my_cur SYS_REFCURSOR;
v_backdb_cpu varchar2(200);
v_server_cpu varchar2(200);
v_db_cpu varchar2(200);
v_snap_time varchar2(200);
begin
dbms_output.put_line('var dbtimedata = { type: "line", data: { labels: [' );
open my_cur for
select 
  snap_time, db_time, db_cpu,sql_exec_time
 from (
select  a1.snap_id,
trunc((a1.dbtime - lag(a1.dbtime, 1, a1.dbtime) over(order by a1.snap_id))/1000000) db_time,
trunc((a1.dbcpu - lag(a1.dbcpu, 1, a1.dbcpu) over(order by a1.snap_id))/1000000) db_cpu,
trunc((a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/1000000) sql_exec_time ,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a.snap_id,instance_number,
sum(case when a.stat_name='DB CPU' then  a.value else 0 end  )  dbcpu,
sum(case when a.stat_name='DB time' then  a.value else 0 end  )  dbtime,
sum(case when a.stat_name='hard parse elapsed time' then  a.value else 0 end  )  hardptime,
sum(case when a.stat_name='parse time elapsed' then  a.value else 0 end  )  ptime,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id,instance_number order by snap_id ) a1 ) a2 
where a2.db_time>0 and a2.db_cpu>0 and a2.sql_exec_time>0;
  FETCH my_cur BULK COLLECT INTO snaptime,dbtime,cputime,sqltime;
 close my_cur;
---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 dbtime.extend;
 dbtime(1):='0';
 cputime.extend;
 cputime(1):=0;
 sqltime.extend;
 sqltime(1):=0;
 end if;
-----------------------------------------
FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('], datasets: [');
DBMS_OUTPUT.PUT_LINE ('{label: "CPU Time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(0, 204, 102, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(0, 255, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN cputime.FIRST .. cputime.LAST
LOOP
  if(i<cputime.count) then
DBMS_OUTPUT.PUT_LINE (cputime(i)||',');
elsif(i=cputime.count) then
DBMS_OUTPUT.PUT_LINE (cputime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],}, {label: "SQL time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(204, 102, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(255, 128, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
/*+copyright wangwenjie , do not copy this code to other business software*/
FOR i IN sqltime.FIRST .. sqltime.LAST
LOOP
  if(i<sqltime.count) then
DBMS_OUTPUT.PUT_LINE (sqltime(i)||',');
elsif(i=sqltime.count) then
DBMS_OUTPUT.PUT_LINE (sqltime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],}, {label: "DB time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(0, 0, 255, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(0, 128, 255, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN dbtime.FIRST .. dbtime.LAST
LOOP
  if(i<dbtime.count) then
DBMS_OUTPUT.PUT_LINE (dbtime(i)||',');
elsif(i=dbtime.count) then
DBMS_OUTPUT.PUT_LINE (dbtime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],},]},');
DBMS_OUTPUT.PUT_LINE ('			options: {');
DBMS_OUTPUT.PUT_LINE ('				responsive: true,');
DBMS_OUTPUT.PUT_LINE ('				title:{');
DBMS_OUTPUT.PUT_LINE ('					display:true,');
DBMS_OUTPUT.PUT_LINE ('					text:"&_dbname&inid - DB time"');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				tooltips: {');
DBMS_OUTPUT.PUT_LINE ('					mode: "index",');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				hover: {');
DBMS_OUTPUT.PUT_LINE ('					mode: "index"');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				scales: {');
DBMS_OUTPUT.PUT_LINE ('					xAxes: [{');
DBMS_OUTPUT.PUT_LINE ('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE ('							display: true,');
DBMS_OUTPUT.PUT_LINE ('							labelString: "Snap Time"');
DBMS_OUTPUT.PUT_LINE ('						}');
DBMS_OUTPUT.PUT_LINE ('					}],');
DBMS_OUTPUT.PUT_LINE ('					yAxes: [{');
DBMS_OUTPUT.PUT_LINE ('						stacked: false,');
DBMS_OUTPUT.PUT_LINE ('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE ('							display: true,');
DBMS_OUTPUT.PUT_LINE ('							labelString: "Secs"');
DBMS_OUTPUT.PUT_LINE ('						}}]}}};	');
END;
/
----------------------------------dbtime end-------------------------
-------------------------------parsetime----------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
parsetime ValueList;
hparsetime ValueList;
snaptime ValueList;
my_cur SYS_REFCURSOR;
v_snap_time varchar2(200);
begin
dbms_output.put_line('var parsetimedata = { type: "line", data: { labels: [' );
open my_cur for
select 
  snap_time, ptime, hardptime
 from (
select  a1.snap_id,
trunc((a1.hardptime - lag(a1.hardptime, 1, a1.hardptime) over(order by a1.snap_id))/1000000) hardptime,
trunc((a1.ptime - lag(a1.ptime, 1, a1.ptime) over(order by a1.snap_id))/1000000) ptime,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a.snap_id,instance_number,
sum(case when a.stat_name='hard parse elapsed time' then  a.value else 0 end  )  hardptime,
sum(case when a.stat_name='parse time elapsed' then  a.value else 0 end  )  ptime
 from  dba_hist_sys_time_model a 
where a.stat_name in (  'parse time elapsed','hard parse elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id,instance_number order by snap_id ) a1 ) a2 
where a2.ptime>0;
  FETCH my_cur BULK COLLECT INTO snaptime,parsetime,hparsetime;
 close my_cur;
---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 parsetime.extend;
 parsetime(1):='0';
 hparsetime.extend;
 hparsetime(1):=0;
 end if;
-----------------------------------------
FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('], datasets: [');
DBMS_OUTPUT.PUT_LINE ('{label: "Hard parse time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: window.awrColors.blue1 ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: window.awrColors.blue2 ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN hparsetime.FIRST .. hparsetime.LAST
LOOP
  if(i<hparsetime.count) then
DBMS_OUTPUT.PUT_LINE (hparsetime(i)||',');
elsif(i=hparsetime.count) then
DBMS_OUTPUT.PUT_LINE (hparsetime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],}, {label: "Parse time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE ('borderColor: "rgba(204, 102, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('backgroundColor: "rgba(255, 128, 0, 1)" ,');
DBMS_OUTPUT.PUT_LINE ('data: [');
-----------------------------------------
FOR i IN parsetime.FIRST .. parsetime.LAST
LOOP
  if(i<parsetime.count) then
DBMS_OUTPUT.PUT_LINE (parsetime(i)||',');
elsif(i=parsetime.count) then
DBMS_OUTPUT.PUT_LINE (parsetime(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE ('],},]},');
DBMS_OUTPUT.PUT_LINE ('			options: {');
DBMS_OUTPUT.PUT_LINE ('				responsive: true,');
DBMS_OUTPUT.PUT_LINE ('				title:{');
DBMS_OUTPUT.PUT_LINE ('					display:true,');
DBMS_OUTPUT.PUT_LINE ('					text:"&_dbname&inid - Parse time"');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				tooltips: {');
DBMS_OUTPUT.PUT_LINE ('					mode: "index",');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				hover: {');
DBMS_OUTPUT.PUT_LINE ('					mode: "index"');
DBMS_OUTPUT.PUT_LINE ('				},');
DBMS_OUTPUT.PUT_LINE ('				scales: {');
DBMS_OUTPUT.PUT_LINE ('					xAxes: [{');
DBMS_OUTPUT.PUT_LINE ('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE ('							display: true,');
DBMS_OUTPUT.PUT_LINE ('							labelString: "Snap Time"');
DBMS_OUTPUT.PUT_LINE ('						}');
DBMS_OUTPUT.PUT_LINE ('					}],');
DBMS_OUTPUT.PUT_LINE ('					yAxes: [{');
DBMS_OUTPUT.PUT_LINE ('						stacked: false,');
DBMS_OUTPUT.PUT_LINE ('						scaleLabel: {');
DBMS_OUTPUT.PUT_LINE ('							display: true,');
DBMS_OUTPUT.PUT_LINE ('							labelString: "Secs"');
DBMS_OUTPUT.PUT_LINE ('						}}]}}};	');
END;
/
-------------------------------parsetime end------------------------
-------------------------------ash---------------------------------
set serveroutput on size unlimited
declare
cursor cur1 is
select to_char(time,'yyyy-mm-dd hh24:mi') time,
       sum(case activity
             when 'CPU' then
              1
             else
              0
           end) CPU,
       sum(case activity
             when 'Concurrency' then
              1
             else
              0
           end) Concurrency,
       sum(case activity
             when 'System I/O' then
              1
             else
              0
           end) Systemio,
       sum(case activity
             when 'User I/O' then
              1
             else
              0
           end) userio,
       sum(case activity
             when 'Administrative' then
              1
             else
              0
           end) Administrative,
       sum(case activity
             when 'Configuration' then
              1
             else
              0
           end) Configuration,
       sum(case activity
             when 'Application' then
              1
             else
              0
           end) Application,
       sum(case activity
             when 'Network' then
              1
             else
              0
           end) Network,
       sum(case activity
             when 'Commit' then
              1
             else
              0
           end) Commit,
       sum(case activity
             when 'Scheduler' then
              1
             else
              0
           end) Scheduler,
       sum(case activity
             when 'Cluster' then
              1
             else
              0
           end) Cluster1,
       sum(case activity
             when 'Queueing' then
              1
             else
              0
           end) Queueing,
       sum(case activity
             when 'Other' then
              1
             else
              0
           end) Other
  from (select to_date(substr(to_char(sample_time, 'yyyymmdd hh24:mi'),1,13)||'0','yyyymmdd hh24:mi') time,
               nvl(wait_class, 'CPU') activity
          from  dba_hist_active_sess_history a
         where session_type = 'FOREGROUND' 
         and a.snap_id >=&bid and snap_id <=&eid  and a.instance_number=&inid
         )
 group by time
 order by time;
 r1 cur1%rowtype;
 TYPE Roster IS TABLE OF cur1%rowtype;
 r2 Roster;
 i number:=1;
 m number;
begin
  r2:=Roster();
  OPEN cur1;
loop
FETCH cur1 INTO r1;
exit when cur1%notfound;
r2.extend;
r2(i):=r1;
i:=i+1;
END LOOP;
CLOSE cur1;
---
m:=r2.count();
DBMS_OUTPUT.PUT_LINE('var ashdata = {labels: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m   then
DBMS_OUTPUT.PUT_LINE('"'||r1.time||'",');
else
DBMS_OUTPUT.PUT_LINE('"'||r1.time||'"');
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('],datasets: [{');
DBMS_OUTPUT.PUT_LINE('label: "CPU time",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
DBMS_OUTPUT.PUT_LINE('data: [');
----
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.CPU||',');
else
DBMS_OUTPUT.PUT_LINE(r1.CPU);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Concurrency",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
DBMS_OUTPUT.PUT_LINE('data: [');
--         
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Concurrency||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Concurrency);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "System io",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.yellow1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Systemio||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Systemio);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "User io",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.userio||',');
else
DBMS_OUTPUT.PUT_LINE(r1.userio);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Administrative",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Administrative||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Administrative);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Configuration",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Configuration||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Configuration);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Application",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Application||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Application);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Network",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Network||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Network);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Commit",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Commit||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Commit);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Scheduler",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.black1,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Scheduler||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Scheduler);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Cluster",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange2,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Cluster1||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Cluster1);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Queueing",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Queueing||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Queueing);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('] },  {');
DBMS_OUTPUT.PUT_LINE('label: "Other",');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
DBMS_OUTPUT.PUT_LINE('data: [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Other||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Other);
end if;
END LOOP;
DBMS_OUTPUT.PUT_LINE(' ]}] };');
---
end;
/
-------------------------ash end------------------------------------------------------
--------------------------sql----------------------------------------------------
----sqlcount 
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snaptime ValueList;
  sqlcnt   ValueList;
  sqltime ValueList;
  sqlcnt_cur sys_refcursor;
begin
  dbms_output.put_line('var sqldata = {labels: [');
  open sqlcnt_cur for
    select snap_time,sql_exec_count,   trunc(sql_time/ sql_exec_count  )   avg_sql_time
      from (select 
                   a1.snap_time,
                  trunc( (a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id))/&_iv) sql_exec_count,
                 trunc(( a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/&_iv) sql_time
              from (select a.snap_id,
                           sum(case
                                 when a.stat_name = 'sql execute elapsed time' then
                                  a.value
                                 else
                                  0
                               end) sql_time,
                           (select b.value
                              from DBA_HIST_SYSSTAT b
                             where b.snap_id = a.snap_id
                               and b.stat_name = 'execute count'
                               and b.instance_number = &inid) exec_count,
                           (select '"' || to_char(f.begin_interval_time,
                                                     'mm-dd hh24:mi') || '"'
                                 from dba_hist_snapshot f
                                where f.snap_id = a.snap_id
                                  and f.instance_number = &inid) snap_time
                      from dba_hist_sys_time_model a
                     where a.stat_name in
                           ('DB time',
                            'DB CPU',
                            'parse time elapsed',
                            'hard parse elapsed time',
                            'sql execute elapsed time')
                       and A.snap_id >= &bid
                       and A.snap_id <= &eid
                       and a.instance_number = &inid
                     group by a.snap_id
                     order by snap_id) a1)
     where sql_exec_count > 0;
  FETCH sqlcnt_cur BULK COLLECT
    INTO  snaptime, sqlcnt,sqltime;
  close sqlcnt_cur;
---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 sqlcnt.extend;
 sqlcnt(1):='0';
 sqltime.extend;
 sqltime(1):='0';
 end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  -----------------------------------------
dbms_output.put_line('],datasets: [{');
dbms_output.put_line('label: "SQL Execution Count",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('backgroundColor: window.awrColors.red2,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('data: [');
  -----------------------------------------
  FOR i IN sqlcnt.FIRST .. sqlcnt.LAST LOOP
    if (i < sqlcnt.count) then
      DBMS_OUTPUT.PUT_LINE(sqlcnt(i) || ',');
    elsif (i = sqlcnt.count) then
      DBMS_OUTPUT.PUT_LINE(sqlcnt(i));
    end if;
  END LOOP;
/*+copyright wangwenjie , do not copy this code to other business software*/
dbms_output.put_line('], yAxisID: "y-axis-1", }, {');
dbms_output.put_line('label: "SQL Execution Time",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('borderColor: window.awrColors.blue1,');
dbms_output.put_line('backgroundColor: window.awrColors.blue2,');
dbms_output.put_line('fill: true,');
dbms_output.put_line('data: [');
  -----------------------------------------
  FOR i IN sqltime.FIRST .. sqltime.LAST LOOP
    if (i < sqltime.count) then
      DBMS_OUTPUT.PUT_LINE(sqltime(i) || ',');
    elsif (i = sqltime.count) then
      DBMS_OUTPUT.PUT_LINE(sqltime(i));
    end if;
  END LOOP;
  -----------------------------------------        
dbms_output.put_line('],');
dbms_output.put_line('yAxisID: "y-axis-2"');
dbms_output.put_line(' }]};');
end;
/
--------------------------------sql end---------------------------------------------
---------------------------------logic read----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  CG       ValueList; ---consistent gets
  SL       ValueList; ---Session Logical Reads
  SNAPTIME ValueList;
  lg_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var logicdata = { type: "line", data: { labels: [');
  OPEN LG_CUR FOR
    select  
          trunc(( a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id))/&_iv) cg,
         trunc( ( a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id))/&_iv) sl,
          (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
      from (select a1.snap_id,
                   sum(case
                         when a1.stat_name = 'consistent gets' then
                          a1.value
                         else
                          0
                       end) csget,
                   sum(case
                         when a1.stat_name = 'session logical reads' then
                          a1.value
                         else
                          0
                       end) slr
              from (select a.snap_id, a.stat_name, a.value
                      from dba_hist_sysstat a
                     where (a.stat_name = 'consistent gets' or
                           a.stat_name = 'session logical reads')
                       and snap_id >= &bid
                       and snap_id <= &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name) a1
             group by a1.snap_id
             order by a1.snap_id) a2;

  FETCH LG_CUR BULK COLLECT
    INTO  CG,  SL,   SNAPTIME;
  CLOSE LG_CUR;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 SL.extend;
 SL(1):='0';
 CG.extend;
 CG(1):=0;
 end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [');
  DBMS_OUTPUT.PUT_LINE('{label: "Consistent Gets",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2 ,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1 ,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN cg.FIRST .. cg.LAST LOOP
    if (i < cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i) || ',');
    elsif (i = cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('],}, {label: "Session Logic Read",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1 ,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2 ,');
DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN SL.FIRST .. SL.LAST LOOP
    if (i < SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i) || ',');
    elsif (i = SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('],},]}, ');
DBMS_OUTPUT.PUT_LINE('options: { ');
DBMS_OUTPUT.PUT_LINE('responsive: true, ');
DBMS_OUTPUT.PUT_LINE('title:{ ');
DBMS_OUTPUT.PUT_LINE('display:true, ');
DBMS_OUTPUT.PUT_LINE('text:"&_dbname&inid - Logical Reads" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('tooltips: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index", ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('hover: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('scales: { ');
DBMS_OUTPUT.PUT_LINE('xAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('labelString: "Snap Time" ');
DBMS_OUTPUT.PUT_LINE('} ');
DBMS_OUTPUT.PUT_LINE('}], ');
DBMS_OUTPUT.PUT_LINE('yAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('stacked: false, ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true, ');
DBMS_OUTPUT.PUT_LINE('labelString: "Blocks/Sec" ');
DBMS_OUTPUT.PUT_LINE('}}]}}};'); 
END;
/
---------------------------logic read end------------------------------------------
-----------------------------commit and redo--------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  RD       ValueList; ---redo size
  UC       ValueList; ---User Commits
  rewt       ValueList;
  SNAPTIME ValueList;
  uc_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var commitdata = {labels: [');
  open uc_cur for
    select  
        trunc(  ( a2.rd - lag(a2.rd, 1, a2.rd) over(order by a2.snap_id))/&_iv/1024) rd,
       trunc(  (  a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id))/&_iv) uc,
	   trunc(  (  a2.rw - lag(a2.rw, 1, a2.rw) over(order by a2.snap_id))/&_iv/1024) rw,
           (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
      from (select a1.snap_id,
                   sum(case
                         when a1.stat_name = 'redo size' then
                          a1.value
                         else
                          0
                       end) rd,
                   sum(case
                         when a1.stat_name = 'user commits' then
                          a1.value
                         else
                          0
                       end) uc,
					                      sum(case
                         when a1.stat_name = 'redo wastage' then
                          a1.value
                         else
                          0
                       end) rw
              from (select a.snap_id, a.stat_name, a.value
                      from dba_hist_sysstat a
                     where (
                           a.stat_name = 'redo size' or
                           a.stat_name = 'user commits' or
						   a.stat_name = 'redo wastage')
                       and snap_id >= &bid
                       and snap_id <= &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name) a1
             group by a1.snap_id
             order by a1.snap_id) a2;

  fetch uc_cur bulk collect
    into rd, uc,rewt, snaptime;
 close uc_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 uc.extend;
 uc(1):='0';
 end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ],datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "User Commit",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN uc.FIRST .. uc.LAST LOOP
    if (i < uc.count) then
      DBMS_OUTPUT.PUT_LINE(uc(i) || ',');
    elsif (i = uc.count) then
      DBMS_OUTPUT.PUT_LINE(uc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], yAxisID: "y-axis-1", }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Redo size(KB)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor:window.awrColors.green0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rd.FIRST .. rd.LAST LOOP
    if (i < rd.count) then
      DBMS_OUTPUT.PUT_LINE(rd(i) || ',');
    elsif (i = rd.count) then
      DBMS_OUTPUT.PUT_LINE(rd(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], yAxisID: "y-axis-2", }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Redo Waste(KB)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor:window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rewt.FIRST .. rewt.LAST LOOP
    if (i < rewt.count) then
      DBMS_OUTPUT.PUT_LINE(rewt(i) || ',');
    elsif (i = rewt.count) then
      DBMS_OUTPUT.PUT_LINE(rewt(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('],yAxisID: "y-axis-2"}]};');
END;
/
---------------------------------commit and redo end------------------------------------
---------------------------------Redo Log Space Activity ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  CG       ValueList; 
  SL       ValueList; 
  SNAPTIME ValueList;
  lg_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var redo2 = { type: "line", data: { labels: [');
  OPEN LG_CUR FOR
    select  
          trunc(( a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id))/&_iv) cg,
         trunc( ( a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id))/&_iv/100) sl,
          (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
      from (select a1.snap_id,
                   sum(case
                         when a1.stat_name = 'redo log space requests' then
                          a1.value
                         else
                          0
                       end) csget,
                   sum(case
                         when a1.stat_name = 'redo log space wait time' then
                          a1.value
                         else
                          0
                       end) slr
              from (select a.snap_id, a.stat_name, a.value
                      from dba_hist_sysstat a
                     where a.stat_name in ('redo log space requests','redo log space wait time')
                       and snap_id >= &bid
                       and snap_id <= &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name) a1
             group by a1.snap_id
             order by a1.snap_id) a2;

  FETCH LG_CUR BULK COLLECT
    INTO  CG,  SL,   SNAPTIME;
  CLOSE LG_CUR;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 SL.extend;
 SL(1):='0';
 CG.extend;
 CG(1):=0;
 end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [');
  DBMS_OUTPUT.PUT_LINE('{label: "Redo Log Space Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2 ,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1 ,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN cg.FIRST .. cg.LAST LOOP
    if (i < cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i) || ',');
    elsif (i = cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
DBMS_OUTPUT.PUT_LINE('label: "Redo Log Space Wait Time Secondd",');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1 ,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2 ,');
DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN SL.FIRST .. SL.LAST LOOP
    if (i < SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i) || ',');
    elsif (i = SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('],},]}, ');
DBMS_OUTPUT.PUT_LINE('options: { ');
DBMS_OUTPUT.PUT_LINE('responsive: true, ');
DBMS_OUTPUT.PUT_LINE('title:{ ');
DBMS_OUTPUT.PUT_LINE('display:true, ');
DBMS_OUTPUT.PUT_LINE('text:"&_dbname&inid - Redo Log Space Activity" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('tooltips: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index", ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('hover: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('scales: { ');
DBMS_OUTPUT.PUT_LINE('xAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('labelString: "Redo Log Space Activity" ');
DBMS_OUTPUT.PUT_LINE('} ');
DBMS_OUTPUT.PUT_LINE('}], ');
DBMS_OUTPUT.PUT_LINE('yAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('stacked: false, ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true, ');
DBMS_OUTPUT.PUT_LINE('labelString: "Count" ');
DBMS_OUTPUT.PUT_LINE('}}]}}};'); 
END;
/
---------------------------------Redo Log Space Activity ----------------------------------
---------------------------------Redo Buffer Retries----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  CG       ValueList; 
  SL       ValueList; 
  SNAPTIME ValueList;
  lg_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var redo3 = { type: "line", data: { labels: [');
  OPEN LG_CUR FOR
    select  
          trunc(( a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id))/&_iv) cg,
         trunc( ( a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id))/&_iv) sl,
          (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
      from (select a1.snap_id,
                   sum(case
                         when a1.stat_name = 'redo blocks written' then
                          a1.value
                         else
                          0
                       end) csget,
                   sum(case
                         when a1.stat_name = 'redo buffer allocation retries' then
                          a1.value
                         else
                          0
                       end) slr
              from (select a.snap_id, a.stat_name, a.value
                      from dba_hist_sysstat a
                     where a.stat_name in ('redo blocks written','redo buffer allocation retries')
                       and snap_id >= &bid
                       and snap_id <= &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name) a1
             group by a1.snap_id
             order by a1.snap_id) a2;

  FETCH LG_CUR BULK COLLECT
    INTO  CG,  SL,   SNAPTIME;
  CLOSE LG_CUR;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 SL.extend;
 SL(1):='0';
 CG.extend;
 CG(1):=0;
 end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [');
  DBMS_OUTPUT.PUT_LINE('{label: "Redo Blocks Written",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2 ,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1 ,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN cg.FIRST .. cg.LAST LOOP
    if (i < cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i) || ',');
    elsif (i = cg.count) then
      DBMS_OUTPUT.PUT_LINE(cg(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
DBMS_OUTPUT.PUT_LINE('label: "Redo Buffer Allocation Retries",');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1 ,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2 ,');
DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN SL.FIRST .. SL.LAST LOOP
    if (i < SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i) || ',');
    elsif (i = SL.count) then
      DBMS_OUTPUT.PUT_LINE(SL(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('],},]}, ');
DBMS_OUTPUT.PUT_LINE('options: { ');
DBMS_OUTPUT.PUT_LINE('responsive: true, ');
DBMS_OUTPUT.PUT_LINE('title:{ ');
DBMS_OUTPUT.PUT_LINE('display:true, ');
DBMS_OUTPUT.PUT_LINE('text:"&_dbname&inid - Redo Buffer Retries" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('tooltips: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index", ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('hover: { ');
DBMS_OUTPUT.PUT_LINE('mode: "index" ');
DBMS_OUTPUT.PUT_LINE('}, ');
DBMS_OUTPUT.PUT_LINE('scales: { ');
DBMS_OUTPUT.PUT_LINE('xAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('labelString: "Redo Buffer Retries" ');
DBMS_OUTPUT.PUT_LINE('} ');
DBMS_OUTPUT.PUT_LINE('}], ');
DBMS_OUTPUT.PUT_LINE('yAxes: [{ ');
DBMS_OUTPUT.PUT_LINE('stacked: false, ');
DBMS_OUTPUT.PUT_LINE('scaleLabel: { ');
DBMS_OUTPUT.PUT_LINE('display: true, ');
DBMS_OUTPUT.PUT_LINE('labelString: "Blocks/sec" ');
DBMS_OUTPUT.PUT_LINE('}}]}}};'); 
END;
/
---------------------------------Redo Buffer Retries ----------------------------------
-----------------------------UNDO STATISTIC--------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  maxquery     ValueList; 
  trans       ValueList; 
  tunedundo 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var undostat = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select 	max(un.MAXQUERYLEN) maxquery,
	sum(un.TXNCOUNT) trans,
	max(un.TUNED_UNDORETENTION) tunedundo,
	'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,s.snap_id
from dba_hist_undostat un , dba_hist_snapshot s
where un.snap_id = s.snap_id
and un.instance_number = s.instance_number
and s.snap_id >=&bid and s.snap_id <=&eid and un.instance_number=&inid
group by s.snap_id,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"'
order by snap_time;
Fetch se_cur bulk collect
    into maxquery, trans,tunedundo,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 maxquery.extend;
maxquery(1):='0';
 tunedundo.extend;
tunedundo(1):='0';
 trans.extend;
 trans(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Tuned UndoRetention(Sec)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN tunedundo.FIRST .. tunedundo.LAST LOOP
    if (i < tunedundo.count) then
      DBMS_OUTPUT.PUT_LINE(tunedundo(i) || ',');
    elsif (i = tunedundo.count) then
      DBMS_OUTPUT.PUT_LINE(tunedundo(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Transactions(Count)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN trans.FIRST .. trans.LAST LOOP
    if (i < trans.count) then
      DBMS_OUTPUT.PUT_LINE(trans(i) || ',');
    elsif (i = trans.count) then
      DBMS_OUTPUT.PUT_LINE(trans(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Max Query Length(Sec)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN maxquery.FIRST .. maxquery.LAST LOOP
    if (i < maxquery.count) then
      DBMS_OUTPUT.PUT_LINE(maxquery(i) || ',');
    elsif (i = maxquery.count) then
      DBMS_OUTPUT.PUT_LINE(maxquery(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Undo Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Undo User"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Count vs Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
-----------------------------UNDO STATISTIC END--------------------------------
-------------------------------Temporary Tablespace Physical Read/Write Blocks-------------------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  PR       ValueList; ---Physical Reads bytes
  PW       ValueList; ---physical write bytes
  SNAPTIME ValueList;
  pw_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var tempact = { type: "line", data: { labels: [');
  open pw_cur for
select round(phyrds/s_et,2) phyrds, round(phywrts/s_et,2) phywrts,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number
      , sum(e.phyrds         - LEAST(b.phyrds,e.phyrds))                  phyrds
      , sum(e.phywrts        - LEAST(b.phywrts,e.phywrts))                phywrts
	  ,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_tempstatxs b
, dba_hist_tempstatxs e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and b.file# = e.file#
group by s.end_interval_time,s.begin_interval_time,s.snap_id,s.instance_number)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
  fetch pw_cur bulk collect into pw, pr, snaptime;
  close pw_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 pr.extend;
 pr(1):='0';
 pw.extend;
 pw(1):=0;
  end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ],  datasets: [{');
  DBMS_OUTPUT.PUT_LINE(' label: "Physical reads",');
  DBMS_OUTPUT.PUT_LINE(' fill: false,');
  DBMS_OUTPUT.PUT_LINE(' backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE(' borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE(' data: [');
  FOR i IN pr.FIRST .. pr.LAST LOOP
    if (i < pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i) || ',');
    elsif (i = pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Physcial writes",');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pw.FIRST .. pw.LAST LOOP
    if (i < pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i) || ',');
    elsif (i = pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('     ], }]},');
DBMS_OUTPUT.PUT_LINE('options: {');
DBMS_OUTPUT.PUT_LINE('    responsive: true,');
DBMS_OUTPUT.PUT_LINE('    title:{');
DBMS_OUTPUT.PUT_LINE('        display:true,');
DBMS_OUTPUT.PUT_LINE('        text:"&_dbname&inid - Temporary Tablespace Physical R/W per Second"');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    tooltips: {');
DBMS_OUTPUT.PUT_LINE('        mode: "index",');
DBMS_OUTPUT.PUT_LINE('        intersect: false,');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    hover: {');
DBMS_OUTPUT.PUT_LINE('        mode: "nearest",');
DBMS_OUTPUT.PUT_LINE('        intersect: true');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    scales: {');
DBMS_OUTPUT.PUT_LINE(' xAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Snap"');
DBMS_OUTPUT.PUT_LINE('     }');
DBMS_OUTPUT.PUT_LINE(' }],');
DBMS_OUTPUT.PUT_LINE(' yAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Sec"');
DBMS_OUTPUT.PUT_LINE('     } }] } } };');
END;
/
-------------------------------Temporary Tablespace Physical Read/Write Sec End-------------------------------------------
-------------------------------Temporary Tablespace I/O Throughput-------------------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  PR       ValueList; ---Physical Reads bytes
  PW       ValueList; ---physical write bytes
  SNAPTIME ValueList;
  pw_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var tempiothpt = { type: "line", data: { labels: [');
  open pw_cur for
select round(phyblkrd/s_et,2) phyblkrd, round(phyblkwrt/s_et,2) phyblkwrt,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number
      , sum(e.phyblkrd         - LEAST(b.phyblkrd,e.phyblkrd))*e.block_size/1024                  phyblkrd
      , sum(e.phyblkwrt        - LEAST(b.phyblkwrt,e.phyblkwrt))*e.block_size/1024                phyblkwrt
	  ,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_tempstatxs b
, dba_hist_tempstatxs e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and b.file# = e.file#
group by s.end_interval_time,s.begin_interval_time,s.snap_id,s.instance_number,e.block_size)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
  fetch pw_cur bulk collect into pw, pr, snaptime;
  close pw_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 pr.extend;
 pr(1):='0';
 pw.extend;
 pw(1):=0;
  end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ],  datasets: [{');
  DBMS_OUTPUT.PUT_LINE(' label: "Physical reads Mb/s",');
  DBMS_OUTPUT.PUT_LINE(' fill: false,');
  DBMS_OUTPUT.PUT_LINE(' backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE(' borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE(' data: [');
  FOR i IN pr.FIRST .. pr.LAST LOOP
    if (i < pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i) || ',');
    elsif (i = pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Physcial writes Mb/s",');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pw.FIRST .. pw.LAST LOOP
    if (i < pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i) || ',');
    elsif (i = pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('     ], }]},');
DBMS_OUTPUT.PUT_LINE('options: {');
DBMS_OUTPUT.PUT_LINE('    responsive: true,');
DBMS_OUTPUT.PUT_LINE('    title:{');
DBMS_OUTPUT.PUT_LINE('        display:true,');
DBMS_OUTPUT.PUT_LINE('        text:"&_dbname&inid - Temporary Tablespace I/O Throughput per Second"');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    tooltips: {');
DBMS_OUTPUT.PUT_LINE('        mode: "index",');
DBMS_OUTPUT.PUT_LINE('        intersect: false,');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    hover: {');
DBMS_OUTPUT.PUT_LINE('        mode: "nearest",');
DBMS_OUTPUT.PUT_LINE('        intersect: true');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    scales: {');
DBMS_OUTPUT.PUT_LINE(' xAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Temporary Tablespace I/O Throughput"');
DBMS_OUTPUT.PUT_LINE('     }');
DBMS_OUTPUT.PUT_LINE(' }],');
DBMS_OUTPUT.PUT_LINE(' yAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Mb/Sec"');
DBMS_OUTPUT.PUT_LINE('     } }] } } };');
END;
/
-------------------------------Temporary Tablespace I/O Throughput Sec-------------------------------------------
---------------------------------IO Single vs Multi----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  sr 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iosm = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,  STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME IN ('physical read total IO requests','physical read total multi block requests','physical write total IO requests','physical write total multi block requests')
 ),
 y AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
    TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
    EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
    EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
    EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT)
    WHERE end_snap_time1 IS NOT NULL
 ),
 z AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, y.end_snap_time, x.instance_number,
    SUM(DECODE(x.stat_name, 'physical read total IO requests',  ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read,
    SUM(DECODE(x.stat_name, 'physical write total IO requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_write,
    SUM(DECODE(x.stat_name, 'physical read total multi block requests',                      ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read_mul,
    SUM(DECODE(x.stat_name, 'physical write total multi block requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) IOPS_write_mul
    FROM x JOIN y ON (x.dbid=y.dbid AND x.instance_number=y.instance_number AND x.end_snap_id=y.snap_id)
    WHERE x.begin_snap_id IS NOT NULL
    GROUP BY x.begin_snap_id, x.end_snap_id, y.end_snap_time, x.instance_number
 ),
 k AS (
 SELECT (IOPS_read-IOPS_read_mul) single_block_reads,(IOPS_write-IOPS_write_mul) single_block_writes,IOPS_read_mul,IOPS_write_mul, '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM z where snap_id >=&bid and snap_id <=&eid and instance_number=&inid)
 select * from k order by snap_time;
 Fetch se_cur bulk collect
    into rt, pt,st,sr,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
 sr.extend;
 sr(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Multi Blocks Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Single Blocks Writes:",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Single Blocks Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Multi Blocks Writes",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sr.FIRST .. sr.LAST LOOP
    if (i < sr.count) then
      DBMS_OUTPUT.PUT_LINE(sr(i) || ',');
    elsif (i = sr.count) then
      DBMS_OUTPUT.PUT_LINE(sr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - IO Single vs Multi"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "IO Single vs Multi"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Blocks/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------IO Single vs Multi End----------------------------------
----------------------------iowait time------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
iotimedata ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var useriodata = { type: "line", data: { labels: [');
open my_cur for
select 
  trunc(iotime/&_iv) ,snap_time
 from (
select a2.snap_id  , 
a2.iotime - lag(a2.iotime, 1, a2.iotime) over(order by a2.snap_id) iotime,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
a1.value  iotime  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    ( a.stat_name = 'user I/O wait time' ) 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 order by a1.snap_id) a2 ) a3;
 FETCH my_cur BULK COLLECT INTO iotimedata,snaptime;
 close my_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 iotimedata.extend;
 iotimedata(1):='0';
 end if;
-----------------------------------------  

  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line(' ], datasets: [{');  
dbms_output.put_line('label: "IO wait time (Second)",');  
dbms_output.put_line('backgroundColor: window.awrColors.grey1,');  
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('borderColor: window.awrColors.purple2,');  
dbms_output.put_line('data: [');  
------------------------------
 FOR i IN iotimedata.FIRST .. iotimedata.LAST
LOOP
  if(i<iotimedata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (iotimedata(i)||',');
end if;
elsif(i=iotimedata.count) then
DBMS_OUTPUT.PUT_LINE (iotimedata(i));
end if;
END LOOP;
dbms_output.put_line('        ], fill: true, } ] },');
dbms_output.put_line('options: {');
dbms_output.put_line('    responsive: true,');
dbms_output.put_line('    title:{');
dbms_output.put_line('        display:true,');
dbms_output.put_line('        text:"&_dbname&inid - User IO Wait Time per Second"');
dbms_output.put_line('    },');
dbms_output.put_line('    tooltips: {');
dbms_output.put_line('        mode: "index",');
dbms_output.put_line('        intersect: false,');
dbms_output.put_line('    },');
dbms_output.put_line('    hover: {');
dbms_output.put_line('        mode: "nearest",');
dbms_output.put_line('        intersect: true');
dbms_output.put_line('    },');
dbms_output.put_line('    scales: {');
dbms_output.put_line('        xAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Snap"');
dbms_output.put_line('            }');
dbms_output.put_line('        }],');
dbms_output.put_line('        yAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Value"');
dbms_output.put_line('            }  }] }  } };');
end;
/
------------------------iowait time end-----------------------------------------
------------------------avg io------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
control ValueList;
dbseq ValueList;
dbsca ValueList;
dbparaell ValueList;
logsync ValueList;
drtpath ValueList;
cpu_cur SYS_REFCURSOR;
v_control varchar2(200);
v_dbseq varchar2(200);
v_dbsca varchar2(200);
v_dbparaell varchar2(200);
v_logsync varchar2(200);
v_drtpath varchar2(200);
v_snap_time varchar2(200);
begin
dbms_output.put_line('var avgiodata = {type: "line", data: { labels: [' );
open cpu_cur for
select a3.snap_time,
decode(controlfilewaits,0,1 ,ceil(controlfilewaitstimes/controlfilewaits/1000)) controlfilewaits,
decode(dbfileseqwaits,0,1 ,ceil(dbfileseqtimes/dbfileseqwaits/1000)) dbfileseqwaits,
decode(dbfilesctwaits,0,1 ,ceil(dbfilescttimes/dbfilesctwaits/1000)) dbfilesctwaits,
decode(drtwaits,0,1 ,ceil(drttimes/drtwaits/1000)) drtwaits,
decode(logwaits,0,1 ,ceil(logtimes/logwaits/1000)) logwaits,
decode(dbparallelwaits,0,1 ,ceil(dbparalleltimes/dbparallelwaits/1000)) dbparallelwaits
 from (
select a2.snap_id,
          trunc(( a2.controlfilewaitstimes - lag(a2.controlfilewaitstimes, 1, a2.controlfilewaitstimes) over(order by a2.snap_id))) controlfilewaitstimes ,
            trunc(( a2.controlfilewaits - lag(a2.controlfilewaits, 1, a2.controlfilewaits) over(order by a2.snap_id)))  controlfilewaits,
              trunc(( a2.dbfileseqtimes - lag(a2.dbfileseqtimes, 1, a2.dbfileseqtimes) over(order by a2.snap_id))) dbfileseqtimes ,
            trunc(( a2.dbfileseqwaits - lag(a2.dbfileseqwaits, 1, a2.dbfileseqwaits) over(order by a2.snap_id)))  dbfileseqwaits,
              trunc(( a2.dbfilescttimes - lag(a2.dbfilescttimes, 1, a2.dbfilescttimes) over(order by a2.snap_id))) dbfilescttimes ,
            trunc(( a2.dbfilesctwaits - lag(a2.dbfilesctwaits, 1, a2.dbfilesctwaits) over(order by a2.snap_id)))  dbfilesctwaits,
              trunc(( a2.drttimes - lag(a2.drttimes, 1, a2.drttimes) over(order by a2.snap_id))) drttimes ,
            trunc(( a2.drtwaits - lag(a2.drtwaits, 1, a2.drtwaits) over(order by a2.snap_id)))  drtwaits,
              trunc(( a2.logtimes - lag(a2.logtimes, 1, a2.logtimes) over(order by a2.snap_id))) logtimes ,
            trunc(( a2.logwaits - lag(a2.logwaits, 1, a2.logwaits) over(order by a2.snap_id)))  logwaits, 
              trunc(( a2.dbparalleltimes - lag(a2.dbparalleltimes, 1, a2.dbparalleltimes) over(order by a2.snap_id))) dbparalleltimes ,
            trunc(( a2.dbparallelwaits - lag(a2.dbparallelwaits, 1, a2.dbparallelwaits) over(order by a2.snap_id)))  dbparallelwaits,
           (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
           from (
select a1.snap_id,
       sum(case
             when a1.event_name = 'control file sequential read' then
              a1.total_waits_fg
             else
              0
           end) controlfilewaits,
       sum(case
             when a1.event_name = 'control file sequential read' then
              a1.time_waited_micro_fg
             else
              0
           end) controlfilewaitstimes,
       sum(case
             when a1.event_name = 'db file sequential read' then
              a1.total_waits_fg
             else
              0
           end) dbfileseqwaits,
       sum(case
             when a1.event_name = 'db file sequential read' then
              a1.time_waited_micro_fg
             else
              0
           end) dbfileseqtimes,
       sum(case
             when a1.event_name = 'db file scattered read' then
              a1.total_waits_fg
             else
              0
           end) dbfilesctwaits,
       sum(case
             when a1.event_name = 'db file scattered read' then
              a1.time_waited_micro_fg
             else
              0
           end) dbfilescttimes,
       sum(case
             when a1.event_name = 'direct path read' then
              a1.total_waits_fg
             else
              0
           end) drtwaits,
       sum(case
             when a1.event_name = 'direct path read' then
              a1.time_waited_micro_fg
             else
              0
           end) drttimes,
       sum(case
             when a1.event_name = 'log file sync' then
              a1.total_waits_fg
             else
              0
           end) logwaits,
       sum(case
             when a1.event_name = 'log file sync' then
              a1.time_waited_micro_fg
             else
              0
           end) logtimes,
       sum(case
             when a1.event_name = 'db file parallel read' then
              a1.total_waits_fg
             else
              0
           end) dbparallelwaits,
       sum(case
             when a1.event_name = 'db file parallel read' then
              a1.time_waited_micro_fg
             else
              0
           end) dbparalleltimes
  from (select a.snap_id,
               a.event_name,
               a.time_waited_micro_fg,
               a.total_waits_fg
          from dba_hist_system_event a
         where event_name in ('control file sequential read',
                              'log file sync',
                              'db file sequential read',
                              'db file scattered read',
                              'db file parallel read',
                              'direct path read')
           and A.snap_id >= &bid and a.snap_id <=&eid  
 and a.instance_number = &inid) a1
 group by a1.snap_id
 order by a1.snap_id)a2)a3 order by snap_id;
   FETCH cpu_cur BULK COLLECT INTO snaptime,control,dbseq,dbsca,drtpath,logsync, dbparaell;
 close cpu_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 control.extend;
 control(1):='0';
 dbseq.extend;
 dbseq(1):=0;
 dbsca.extend;
 dbsca(1):=0;
  drtpath.extend;
 drtpath(1):=0;
  logsync.extend;
 logsync(1):=0;
  dbparaell.extend;
 dbparaell(1):=0;
 end if;
-----------------------------------------
FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
/*+copyright wangwenjie , do not copy this code to other business software*/
DBMS_OUTPUT.PUT_LINE('], datasets: [{');
DBMS_OUTPUT.PUT_LINE('label: "db file sequential read",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN dbseq.FIRST .. dbseq.LAST
LOOP
  if(i<dbseq.count) then
DBMS_OUTPUT.PUT_LINE (dbseq(i)||',');
elsif(i=dbseq.count) then
DBMS_OUTPUT.PUT_LINE (dbseq(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
DBMS_OUTPUT.PUT_LINE('label: "direct path read",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN drtpath.FIRST .. drtpath.LAST
LOOP
  if(i<drtpath.count) then
DBMS_OUTPUT.PUT_LINE (drtpath(i)||',');
elsif(i=drtpath.count) then
DBMS_OUTPUT.PUT_LINE (drtpath(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], }, {');
DBMS_OUTPUT.PUT_LINE('label: "log file sync",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN logsync.FIRST .. logsync.LAST
LOOP
  if(i<logsync.count) then
DBMS_OUTPUT.PUT_LINE (logsync(i)||',');
elsif(i=logsync.count) then
DBMS_OUTPUT.PUT_LINE (logsync(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], }, {');
DBMS_OUTPUT.PUT_LINE('label: "db file parallel read",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN dbparaell.FIRST .. dbparaell.LAST
LOOP
  if(i<dbparaell.count) then
DBMS_OUTPUT.PUT_LINE (dbparaell(i)||',');
elsif(i=dbparaell.count) then
DBMS_OUTPUT.PUT_LINE (dbparaell(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], }, {');
DBMS_OUTPUT.PUT_LINE('label: "control file sequential read",');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN control.FIRST .. control.LAST
LOOP
  if(i<control.count) then
DBMS_OUTPUT.PUT_LINE (control(i)||',');
elsif(i=control.count) then
DBMS_OUTPUT.PUT_LINE (control(i));
end if;
END LOOP;
-----------------------------------------
DBMS_OUTPUT.PUT_LINE('], }, {');
DBMS_OUTPUT.PUT_LINE('label: "db file scatter read",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
DBMS_OUTPUT.PUT_LINE('fill: false,');
DBMS_OUTPUT.PUT_LINE(' backgroundColor: window.awrColors.green1,');
DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
DBMS_OUTPUT.PUT_LINE('data: [');
-----------------------------------------
FOR i IN dbsca.FIRST .. dbsca.LAST
LOOP
  if(i<dbsca.count) then
DBMS_OUTPUT.PUT_LINE (dbsca(i)||',');
elsif(i=dbsca.count) then
DBMS_OUTPUT.PUT_LINE (dbsca(i));
end if;
END LOOP;
-----------------------------------------
dbms_output.put_line('        ], }]  },');
dbms_output.put_line('options: {');
dbms_output.put_line('    responsive: true,');
dbms_output.put_line('    title:{');
dbms_output.put_line('        display:true,');
dbms_output.put_line('        text:"&_dbname&inid - Average IO Wait Time (ms)"');
dbms_output.put_line('    },');
dbms_output.put_line('    tooltips: {');
dbms_output.put_line('        mode: "index",');
dbms_output.put_line('        intersect: false,');
dbms_output.put_line('    },');
dbms_output.put_line('    hover: {');
dbms_output.put_line('        mode: "nearest",');
dbms_output.put_line('        intersect: true');
dbms_output.put_line('    },');
dbms_output.put_line('    scales: {');
dbms_output.put_line('        xAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Snap"');
dbms_output.put_line('            }');
dbms_output.put_line('        }],');
dbms_output.put_line('        yAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Value"');
dbms_output.put_line('            } }] } } };');
END;
/
--------------------avg io end ----------------------------------------
---------------------------block change---------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
bchange ValueList;
snaptime ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var bchangedata = { type: "line", data: { labels: [');
open my_cur for
select 
  trunc(bc/&_iv) ,snap_time
 from (
select a2.snap_id  , 
a2.bc - lag(a2.bc, 1, a2.bc) over(order by a2.snap_id) bc,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
a1.value  bc  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    ( a.stat_name = 'db block changes' ) 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 order by a1.snap_id) a2 ) a3;
 FETCH my_cur BULK COLLECT INTO bchange,snaptime;
 close my_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 bchange.extend;
 bchange(1):='0';
 end if;
-----------------------------------------  

  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line(' ], datasets: [{');  
dbms_output.put_line('label: "Block changes ",');  
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.orange1,');  
dbms_output.put_line('borderColor: window.awrColors.black1,');  
dbms_output.put_line('data: [');  
------------------------------
 FOR i IN bchange.FIRST .. bchange.LAST
LOOP
  if(i<bchange.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (bchange(i)||',');
end if;
elsif(i=bchange.count) then
DBMS_OUTPUT.PUT_LINE (bchange(i));
end if;
END LOOP;
dbms_output.put_line('        ], fill: true, } ] },');
dbms_output.put_line('options: {');
dbms_output.put_line('    responsive: true,');
dbms_output.put_line('    title:{');
dbms_output.put_line('        display:true,');
dbms_output.put_line('        text:" &_dbname&inid - Block Changes per Second"');
dbms_output.put_line('    },');
dbms_output.put_line('    tooltips: {');
dbms_output.put_line('        mode: "index",');
dbms_output.put_line('        intersect: false,');
dbms_output.put_line('    },');
dbms_output.put_line('    hover: {');
dbms_output.put_line('        mode: "nearest",');
dbms_output.put_line('        intersect: true');
dbms_output.put_line('    },');
dbms_output.put_line('    scales: {');
dbms_output.put_line('        xAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Snap"');
dbms_output.put_line('            }');
dbms_output.put_line('        }],');
dbms_output.put_line('        yAxes: [{');
dbms_output.put_line('            display: true,');
dbms_output.put_line('            scaleLabel: {');
dbms_output.put_line('                display: true,');
dbms_output.put_line('                labelString: "Value"');
dbms_output.put_line('            }  }] }  } };');
end;
/
----------------------block changes end----------------------
--------------------conn-----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  PROC     ValueList; ---Process
  SE       ValueList; ---Session  
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var conndata = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
    select pr,
           se,
          (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a1.snap_id
                  and f.instance_number = &inid) snap_time,
           snap_id
      from (select snap_id,
                   sum(case
                         when a.resource_name = 'processes' then
                          a.current_utilization
                         else
                          0
                       end) pr,
                   sum(case
                         when a.resource_name = 'sessions' then
                          a.current_utilization
                         else
                          0
                       end) se
              from dba_hist_resource_limit a
             where a.snap_id >= &bid
               and a.snap_id <= &eid
               and a.instance_number = &inid
               and (a.resource_name = 'sessions' or
                   a.resource_name = 'processes')
             group by snap_id
             order by snap_id) a1;

  Fetch se_cur bulk collect
    into PROC, SE, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 proc.extend;
 proc(1):='0';
 SE.extend;
 SE(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Processes",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN proc.FIRST .. proc.LAST LOOP
    if (i < proc.count) then
      DBMS_OUTPUT.PUT_LINE(proc(i) || ',');
    elsif (i = proc.count) then
      DBMS_OUTPUT.PUT_LINE(proc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Sessions",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN SE.FIRST .. SE.LAST LOOP
    if (i < SE.count) then
      DBMS_OUTPUT.PUT_LINE(SE(i) || ',');
    elsif (i = SE.count) then
      DBMS_OUTPUT.PUT_LINE(SE(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Connections"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Snap"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Value" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------conn end-----------------------------------
----------------------------logon-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  max_logon ValueList; ---max logon
  avg_logon ValueList;
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var logondata = { type: "line", data: { labels: [');     
  OPEN CR_CUR FOR 
select sum(a1.maxlogon),sum(a1.avglogon),
        (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
             from dba_hist_snapshot f
            where f.snap_id = a1.snap_id
              and f.instance_number = &inid) snap_time
  from (select a.snap_id,
               case
                 when metric_name = 'Logons Per Sec' then
                   trunc(a.maxval) 
                 else
                  0
               end maxlogon,
               case
                 when metric_name = 'Logons Per Sec' then
                   trunc(a.average) 
                 else
                  0
               end avglogon
          from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid
           and a.snap_id <= &eid
           and a.instance_number = &inid
         and a.metric_name in
               ('Logons Per Sec'
                )) a1
 group by a1.snap_id order by a1.snap_id;
    FETCH CR_CUR     BULK COLLECT    INTO max_logon,avg_logon,SNAPTIME;
    close CR_CUR;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 max_logon.extend;
 max_logon(1):='0';
 avg_logon.extend;
 avg_logon(1):='0';
end if;
-----------------------------------------  
    FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{'); 
dbms_output.put_line('label: "Max Logon",'); 
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,'); 
dbms_output.put_line('borderColor: window.awrColors.red2,'); 
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN max_logon.FIRST .. max_logon.LAST
LOOP
  if(i<max_logon.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (max_logon(i)||',');
end if;
elsif(i=max_logon.count) then
DBMS_OUTPUT.PUT_LINE (max_logon(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Average logon",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('borderDash: [5, 5],');
dbms_output.put_line('backgroundColor: window.awrColors.blue1,');
dbms_output.put_line('borderColor: window.awrColors.blue2,');
dbms_output.put_line('data: [');
 FOR i IN avg_logon.FIRST .. avg_logon.LAST
LOOP
  if(i<avg_logon.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (avg_logon(i)||',');
end if;
elsif(i=avg_logon.count) then
DBMS_OUTPUT.PUT_LINE (avg_logon(i));
end if;
END LOOP;
dbms_output.put_line('], }] },                    ');
dbms_output.put_line('options: {                  ');
dbms_output.put_line('responsive: true,           ');
dbms_output.put_line('title:{                     ');
dbms_output.put_line('display:true,               ');
dbms_output.put_line('text:"&_dbname&inid - User logon per Second"');
dbms_output.put_line('},                          ');
dbms_output.put_line('tooltips: {                 ');
dbms_output.put_line('mode: "index",              ');
dbms_output.put_line('intersect: false,           ');
dbms_output.put_line('},                          ');
dbms_output.put_line('hover: {                    ');
dbms_output.put_line('mode: "nearest",            ');
dbms_output.put_line('intersect: true             ');
dbms_output.put_line('},                          ');
dbms_output.put_line('scales: {                   ');
dbms_output.put_line('xAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString: "Snap"         ');
dbms_output.put_line('}                           ');
dbms_output.put_line('}],                         ');
dbms_output.put_line('yAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString:  "Value"       ');
dbms_output.put_line('} }] } } };                 ');
end;
/
----------------------------logon end-----------------------------
------Database Sorts Statistic BreakDown ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var sorts = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(sortdisk/s_et,2) sortdisk
     , round(sortmem/s_et,2) sortmem
     ,round(sortrow/s_et,2) sortrow,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'sorts (disk)','sorts (memory)','sorts (rows)'))
         pivot (sum(value) for stat_name in (
'sorts (disk)' sortdisk,
'sorts (memory)' sortmem,
'sorts (rows)' sortrow
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Sorts (Disks)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Sorts (Memory)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Sorts Rows",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Database Sorts Per Seconds"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Database Sorts Per Seconds"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Value" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Database Sorts Statistic BreakDown ---------------------------------Cursor Statistic BreakDown ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var curinfo = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(crl/s_et,2) crl
     , round(occ/s_et,2) occ
     ,round(sccc/s_et,2) sccc,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'cursor reload failures','opened cursors current','session cursor cache count'))
         pivot (sum(value) for stat_name in (
'cursor reload failures'     crl
, 'opened cursors current'     occ
, 'session cursor cache count' sccc
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Session Cached Cursors",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Open Cursors",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cursor Reload Failures",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Database Cursors"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Database Cursors"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Value" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Database Cursors Statistic BreakDown -------------
---------------------------------Global Current Block Service Time ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  ft 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glcur = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select gccurt*10/decode(gccurv,0,null,gccurv)         gccurt
     , gccupt*10/decode(gccusv,0,null,gccusv)         gccupt
     , gccust*10/decode(gccusv,0,null,gccusv)         gccust
     , gccuft*10/decode(gccufl,0,null,gccufl)         gccuft
	 ,'"'||to_char(st.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,st.snap_id
   from ((select se.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time
              , se.stat_name
              , (se.value - nvl(sb.value,0)) value
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
         	,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
            and se.dbid            = sb.dbid            (+)
            and se.instance_number = sb.instance_number (+)
            and se.stat_id         = sb.stat_id         (+)
            and se.stat_name in
                ( 'gc cr blocks received', 'gc cr block receive time'
                , 'gc current blocks received', 'gc current block receive time'
                , 'gc cr blocks served', 'gc cr block build time'
                , 'gc cr block flush time', 'gc cr block send time'
                , 'gc current block pin time', 'gc current blocks served' 
                , 'gc current block send time', 'gc current block flush time'
                , 'global enqueue get time'
                , 'global enqueue gets sync', 'global enqueue gets async'
                ))
           pivot (sum(value) for stat_name in (
                 'gc cr blocks received'               gccrrv
               , 'gc cr block receive time'            gccrrt
               , 'gc current blocks received'          gccurv
               , 'gc current block receive time'       gccurt
               , 'gc cr blocks served'                 gccrsv
               , 'gc cr block build time'              gccrbt
               , 'gc cr block send time'               gccrst
               , 'gc cr block flush time'              gccrft
               , 'gc current blocks served'            gccusv
               , 'gc current block pin time'           gccupt
               , 'gc current block send time'          gccust
               , 'gc current block flush time'         gccuft
               , 'global enqueue get time'               glgt
               , 'global enqueue gets sync'              glsg
               , 'global enqueue gets async'             glag)) ) st
     , (select  cufl.instance_number, cufl.snap_id,gccrfl,gccufl from ( select e.instance_number,s.snap_id
              , sum(e.flushes - b.flushes)    gccrfl
           from dba_hist_cr_block_server b
              , dba_hist_cr_block_server e
              ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number) crfl
     , ( select e.instance_number,s.snap_id
              , sum((e.flush1+e.flush10+e.flush100+e.flush1000+e.flush10000) 
                             - (b.flush1+b.flush10+b.flush100+b.flush1000+b.flush10000)) gccufl
           from dba_hist_current_block_server b
              , dba_hist_current_block_server e
               ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number)     cufl
		 where crfl.instance_number=cufl.instance_number
		 and crfl.snap_id=cufl.snap_id) s
 where st.instance_number = s.instance_number
   and st.snap_id = s.snap_id
    and st.snap_id >=&bid and st.snap_id <=&eid and st.instance_number=&inid
 order by snap_time;
Fetch se_cur bulk collect
    into rt, pt,st,ft,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
  ft.extend;
 ft(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "GC current block send time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC current block pin time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC current block receive time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC current block flush time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ft.FIRST .. ft.LAST LOOP
    if (i < ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i) || ',');
    elsif (i = ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Current Block Service Time"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Current Block Service Time"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Time(ms)" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Current Block Service Time End----------------------------------
---------------------------------Global CR Block Service Time ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  ft 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glcr = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select gccrrt*10/decode(gccrrv,0,null,gccrrv) gccrrt
     , gccrbt*10/decode(gccrsv,0,null,gccrsv)         gccrbt
     , gccrst*10/decode(gccrsv,0,null,gccrsv)         gccrst
     , gccrft*10/decode(gccrfl,0,null,gccrfl)         gccrft
	 ,'"'||to_char(st.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,st.snap_id
  from ((select se.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time
              , se.stat_name
              , (se.value - nvl(sb.value,0)) value
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
         	,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
            and se.dbid            = sb.dbid            (+)
            and se.instance_number = sb.instance_number (+)
            and se.stat_id         = sb.stat_id         (+)
            and se.stat_name in
                ( 'gc cr blocks received', 'gc cr block receive time'
                , 'gc current blocks received', 'gc current block receive time'
                , 'gc cr blocks served', 'gc cr block build time'
                , 'gc cr block flush time', 'gc cr block send time'
                , 'gc current block pin time', 'gc current blocks served' 
                , 'gc current block send time', 'gc current block flush time'
                , 'global enqueue get time'
                , 'global enqueue gets sync', 'global enqueue gets async'
                ))
           pivot (sum(value) for stat_name in (
                 'gc cr blocks received'               gccrrv
               , 'gc cr block receive time'            gccrrt
               , 'gc current blocks received'          gccurv
               , 'gc current block receive time'       gccurt
               , 'gc cr blocks served'                 gccrsv
               , 'gc cr block build time'              gccrbt
               , 'gc cr block send time'               gccrst
               , 'gc cr block flush time'              gccrft
               , 'gc current blocks served'            gccusv
               , 'gc current block pin time'           gccupt
               , 'gc current block send time'          gccust
               , 'gc current block flush time'         gccuft
               , 'global enqueue get time'               glgt
               , 'global enqueue gets sync'              glsg
               , 'global enqueue gets async'             glag)) ) st
     , (select  cufl.instance_number, cufl.snap_id,gccrfl,gccufl from ( select e.instance_number,s.snap_id
              , sum(e.flushes - b.flushes)    gccrfl
           from dba_hist_cr_block_server b
              , dba_hist_cr_block_server e
              ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number) crfl
     , ( select e.instance_number,s.snap_id
              , sum((e.flush1+e.flush10+e.flush100+e.flush1000+e.flush10000) 
                             - (b.flush1+b.flush10+b.flush100+b.flush1000+b.flush10000)) gccufl
           from dba_hist_current_block_server b
              , dba_hist_current_block_server e
               ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number)     cufl
		 where crfl.instance_number=cufl.instance_number
		 and crfl.snap_id=cufl.snap_id) s
 where st.instance_number = s.instance_number
   and st.snap_id = s.snap_id
    and st.snap_id >=&bid and st.snap_id <=&eid and st.instance_number=&inid
 order by snap_time;
Fetch se_cur bulk collect
    into rt, pt,st,ft,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
  ft.extend;
 ft(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "GC CR block send time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC CR block build time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC CR block receive time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC CR block flush time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ft.FIRST .. ft.LAST LOOP
    if (i < ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i) || ',');
    elsif (i = ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global CR Block Service Time"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global CR Block Service Time"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Time(ms)" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global CR Block Service Time End----------------------------------
---------------------------------Global Cache Log Flushes Percentage Time ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glper = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select gccrfl/decode(gccrsv,0,null,gccrsv)*100    gccrflp
     , gccufl        /decode(gccusv,0,null,gccusv)*100    gccuflp
	 ,'"'||to_char(st.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,st.snap_id
  from ((select se.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time
              , se.stat_name
              , (se.value - nvl(sb.value,0)) value
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
         	,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
            and se.dbid            = sb.dbid            (+)
            and se.instance_number = sb.instance_number (+)
            and se.stat_id         = sb.stat_id         (+)
            and se.stat_name in
                ( 'gc cr blocks received', 'gc cr block receive time'
                , 'gc current blocks received', 'gc current block receive time'
                , 'gc cr blocks served', 'gc cr block build time'
                , 'gc cr block flush time', 'gc cr block send time'
                , 'gc current block pin time', 'gc current blocks served' 
                , 'gc current block send time', 'gc current block flush time'
                , 'global enqueue get time'
                , 'global enqueue gets sync', 'global enqueue gets async'
                ))
           pivot (sum(value) for stat_name in (
                 'gc cr blocks received'               gccrrv
               , 'gc cr block receive time'            gccrrt
               , 'gc current blocks received'          gccurv
               , 'gc current block receive time'       gccurt
               , 'gc cr blocks served'                 gccrsv
               , 'gc cr block build time'              gccrbt
               , 'gc cr block send time'               gccrst
               , 'gc cr block flush time'              gccrft
               , 'gc current blocks served'            gccusv
               , 'gc current block pin time'           gccupt
               , 'gc current block send time'          gccust
               , 'gc current block flush time'         gccuft
               , 'global enqueue get time'               glgt
               , 'global enqueue gets sync'              glsg
               , 'global enqueue gets async'             glag)) ) st
     , (select  cufl.instance_number, cufl.snap_id,gccrfl,gccufl from ( select e.instance_number,s.snap_id
              , sum(e.flushes - b.flushes)    gccrfl
           from dba_hist_cr_block_server b
              , dba_hist_cr_block_server e
              ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number) crfl
     , ( select e.instance_number,s.snap_id
              , sum((e.flush1+e.flush10+e.flush100+e.flush1000+e.flush10000) 
                             - (b.flush1+b.flush10+b.flush100+b.flush1000+b.flush10000)) gccufl
           from dba_hist_current_block_server b
              , dba_hist_current_block_server e
               ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
            and b.instance_number  = e.instance_number
          group by s.snap_id,e.instance_number)     cufl
		 where crfl.instance_number=cufl.instance_number
		 and crfl.snap_id=cufl.snap_id) s
 where st.instance_number = s.instance_number
   and st.snap_id = s.snap_id
    and st.snap_id >=&bid and st.snap_id <=&eid and st.instance_number=&inid
 order by snap_time;
Fetch se_cur bulk collect
    into rt, pt,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 pt.extend;
 pt(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "GC log flushes for current blocks served %",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC log flushes for cr blocks served %",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache Log Flushes %"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Cache Log Flushes %"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Percentage" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache Log Flushes Percentage End----------------------------------
---------------------------------Global Cache Load Profile ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  ft 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var gllp = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER, STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME in ('gc cr blocks received','gc cr blocks served','gc current blocks received',
    'gc current blocks served','gcs messages sent','ges messages sent')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
    UNION
    SELECT DBID, INSTANCE_NUMBER, NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_DLM_MISC
    WHERE NAME in ('ges msgs received','gcs msgs received')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, begin_snap_id, end_snap_id,
       SUM(DECODE(stat_name, 'gc cr blocks received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) cr_blks_recv,
       SUM(DECODE(stat_name, 'gc cr blocks served',   (NVL(end_value,0)-NVL(begin_value,0)),0))  cr_blks_serv,
       SUM(DECODE(stat_name, 'gc current blocks received',(NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_recv,
       SUM(DECODE(stat_name, 'gc current blocks served',  (NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_serv,
       SUM(DECODE(stat_name, 'gcs msgs received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) gcs_msg_recv,
       SUM(DECODE(stat_name, 'gcs messages sent', (NVL(end_value,0)-NVL(begin_value,0)), 0)) gcs_msg_sent,
       SUM(DECODE(stat_name, 'ges msgs received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) ges_msg_recv,
       SUM(DECODE(stat_name, 'ges messages sent', (NVL(end_value,0)-NVL(begin_value,0)), 0)) ges_msg_sent
    FROM x 
    WHERE begin_snap_id IS NOT NULL
    GROUP BY dbid, instance_number, begin_snap_id, end_snap_id
 ),
 z AS (
    SELECT a.dbid, a.instance_number, a.snap_id, a.end_snap_time2 end_snap_time,
       TRUNC(EXTRACT(DAY from a.end_snap_time2-a.end_snap_time1)*24*60*60 +
       EXTRACT(HOUR from      a.end_snap_time2-a.end_snap_time1)*60*60 +
       EXTRACT(MINUTE from    a.end_snap_time2-a.end_snap_time1)*60 +
       EXTRACT(SECOND from    a.end_snap_time2-a.end_snap_time1)) duration, b.VALUE blk_size
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid
       ) a JOIN DBA_HIST_PARAMETER b
       ON (a.DBID=b.DBID AND a.INSTANCE_NUMBER=b.INSTANCE_NUMBER AND a.SNAP_ID=b.SNAP_ID)
    WHERE a.end_snap_time1 IS NOT NULL AND b.PARAMETER_NAME='db_block_size'
 )
 SELECT /*+ NO_MERGE(z) */ 
 ROUND((y.cr_blks_recv+ y.cur_blks_recv)/z.duration,2) gc_blks_recv_per_second,
 ROUND((y.cr_blks_serv+ y.cur_blks_serv)/z.duration,2) gc_blks_serv_per_second,
 ROUND((y.gcs_msg_recv+ y.ges_msg_recv )/z.duration,2) gc_msg_recv_per_second,
 ROUND((y.gcs_msg_sent+ y.ges_msg_sent )/z.duration,2) gc_msg_sent_per_second,
'"'||to_char(z.end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,y.end_snap_id snap_id
 FROM y JOIN z ON (y.dbid=z.dbid AND y.instance_number=z.instance_number AND y.end_snap_id=z.snap_id)
 ORDER BY snap_time;
 Fetch se_cur bulk collect
    into rt, pt,st,ft,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
  ft.extend;
 ft(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "GCS/GES messages received",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Global Cache blocks served",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Global Cache blocks received",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GCS/GES messages sent",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ft.FIRST .. ft.LAST LOOP
    if (i < ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i) || ',');
    elsif (i = ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache Load Profile"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Cache Load Profile"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Count/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache Load Profile End----------------------------------
---------------------------------Global Cache Load Profile- Estd Interconnect traffic (KB) ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  st 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glinter = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER, STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME in ('gc cr blocks received','gc cr blocks served','gc current blocks received',
    'gc current blocks served','gcs messages sent','ges messages sent')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
    UNION
    SELECT DBID, INSTANCE_NUMBER, NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_DLM_MISC
    WHERE NAME in ('ges msgs received','gcs msgs received')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, begin_snap_id, end_snap_id,
       SUM(DECODE(stat_name, 'gc cr blocks received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) cr_blks_recv,
       SUM(DECODE(stat_name, 'gc cr blocks served',   (NVL(end_value,0)-NVL(begin_value,0)),0))  cr_blks_serv,
       SUM(DECODE(stat_name, 'gc current blocks received',(NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_recv,
       SUM(DECODE(stat_name, 'gc current blocks served',  (NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_serv,
       SUM(DECODE(stat_name, 'gcs msgs received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) gcs_msg_recv,
       SUM(DECODE(stat_name, 'gcs messages sent', (NVL(end_value,0)-NVL(begin_value,0)), 0)) gcs_msg_sent,
       SUM(DECODE(stat_name, 'ges msgs received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) ges_msg_recv,
       SUM(DECODE(stat_name, 'ges messages sent', (NVL(end_value,0)-NVL(begin_value,0)), 0)) ges_msg_sent
    FROM x 
    WHERE begin_snap_id IS NOT NULL
    GROUP BY dbid, instance_number, begin_snap_id, end_snap_id
 ),
 z AS (
    SELECT a.dbid, a.instance_number, a.snap_id, a.end_snap_time2 end_snap_time,
       TRUNC(EXTRACT(DAY from a.end_snap_time2-a.end_snap_time1)*24*60*60 +
       EXTRACT(HOUR from      a.end_snap_time2-a.end_snap_time1)*60*60 +
       EXTRACT(MINUTE from    a.end_snap_time2-a.end_snap_time1)*60 +
       EXTRACT(SECOND from    a.end_snap_time2-a.end_snap_time1)) duration, b.VALUE blk_size
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid
       ) a JOIN DBA_HIST_PARAMETER b
       ON (a.DBID=b.DBID AND a.INSTANCE_NUMBER=b.INSTANCE_NUMBER AND a.SNAP_ID=b.SNAP_ID)
    WHERE a.end_snap_time1 IS NOT NULL AND b.PARAMETER_NAME='db_block_size'
 )
 SELECT /*+ NO_MERGE(z) */ 
  ROUND(((cr_blks_recv+cr_blks_serv+cur_blks_recv+cur_blks_serv)*z.blk_size +
        (gcs_msg_recv+gcs_msg_sent+ges_msg_recv+ges_msg_sent)*200)/1024/z.duration,2) gc_traffic_KB_per_second,
'"'||to_char(z.end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,y.end_snap_id snap_id
 FROM y JOIN z ON (y.dbid=z.dbid AND y.instance_number=z.instance_number AND y.end_snap_id=z.snap_id)
 ORDER BY snap_time;
 Fetch se_cur bulk collect
    into st,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 st.extend;
st(1):='0';

end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Estd Interconnect traffic (KB)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Estd Interconnect traffic (KB)"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Estd Interconnect traffic (KB)"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Kb/sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache Load Profile- Estd Interconnect traffic (KB----------------------------------
---------------------------------Global Cache Efficiency Percentages----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glep = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select (100*(1-(phyrc + gccrrv + gccurv)/(cgfc+dbfc)))   lc
     , (100*(gccurv+gccrrv)/(cgfc+dbfc))                 rc
     , (100*phyrc/(cgfc+dbfc))                           dsk,
	 '"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.instance_number,se.snap_id,s.end_interval_time
              , se.stat_name
              , (se.value - nvl(sb.value,0))          value
           from dba_hist_sysstat sb
              , dba_hist_sysstat se
          ,dba_hist_snapshot       s
         where sb.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
            and se.dbid            = sb.dbid            (+)
            and se.instance_number = sb.instance_number (+)
            and se.stat_id         = sb.stat_id         (+)
		   and s.snap_id >=&bid and s.snap_id <=&eid and se.instance_number=&inid
            and se.stat_name in
                ( 'gc cr blocks received', 'gc current blocks received'
                , 'physical reads cache'
                , 'consistent gets from cache', 'db block gets from cache'
                ))
           pivot (sum(value) for stat_name in (
                 'gc cr blocks received'          gccrrv
               , 'gc current blocks received'     gccurv
               , 'physical reads cache'            phyrc
               , 'consistent gets from cache'       cgfc
               , 'db block gets from cache'         dbfc))) st
  order by snap_time;
 Fetch se_cur bulk collect
    into rt, pt,st,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer access - disk %",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer access - remote cache %:",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer access - local cache %:",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache Efficiency Percentages"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Cache Efficiency Percentages"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Percentage" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache Efficiency Percentages End----------------------------------
---------------------------------Global Cache and Enqueue Services - Messaging Statistics----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  ft 	ValueList;
  ct 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var gles = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select msgsqt /decode(msgsq,0,null,msgsq)                          msgsqt
     , msgsqtk/decode(msgsqk,0,null,msgsqk)                       msgsqtk
     , msgrqt /decode(msgrq,0,null,msgrq)                          msgrqt
     , pmpt   /decode(pmrv,0,null,pmrv)                              pmpt
     , npmpt  /decode(npmrv,0,null,npmrv)                           npmpt
	 ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.instance_number,s.snap_id,s.end_interval_time
              , se.name
              , (se.value - nvl(sb.value,0))    value
           from dba_hist_dlm_misc sb
              , dba_hist_dlm_misc se
           ,dba_hist_snapshot       s
         where se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and s.snap_id >=&bid and s.snap_id <=&eid and se.instance_number=&inid
            and se.dbid            = sb.dbid             (+)
            and se.instance_number = sb.instance_number  (+)
            and se.statistic#      = sb.statistic#       (+)
            and se.name            = sb.name             (+)
            and se.name in ( 'msgs sent queued', 'msgs sent queue time (ms)'
                , 'msgs sent queue time on ksxp (ms)', 'msgs sent queued on ksxp'
                , 'msgs received queue time (ms)', 'msgs received queued' 
                , 'gcs msgs received', 'gcs msgs process time(ms)'
                , 'ges msgs received', 'ges msgs process time(ms)'
                , 'messages sent directly', 'messages sent indirectly'
                , 'messages flow controlled'
                ))
           pivot (sum(value) for name in (
                 'msgs sent queued'                        msgsq
               , 'msgs sent queue time (ms)'              msgsqt
               , 'msgs sent queue time on ksxp (ms)'     msgsqtk
               , 'msgs sent queued on ksxp'               msgsqk
               , 'msgs received queue time (ms)'          msgrqt
               , 'msgs received queued'                    msgrq
               , 'gcs msgs received'                        pmrv
               , 'gcs msgs process time(ms)'                pmpt
               , 'ges msgs received'                       npmrv
               , 'ges msgs process time(ms)'               npmpt
               , 'messages sent directly'                   dmsd
               , 'messages sent indirectly'                 dmsi
               , 'messages flow controlled'                 dmfc))) st
 order by snap_time;
Fetch se_cur bulk collect
    into rt, pt,st,ft,ct,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
  ft.extend;
 ft(1):='0';
 ct.extend;
 ct(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Avg message received queue time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Avg message sent queue time on ksxp",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Avg message sent queue time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Avg GCS message process time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ft.FIRST .. ft.LAST LOOP
    if (i < ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i) || ',');
    elsif (i = ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Avg GES message process time",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ct.FIRST .. ct.LAST LOOP
    if (i < ct.count) then
      DBMS_OUTPUT.PUT_LINE(ct(i) || ',');
    elsif (i = ct.count) then
      DBMS_OUTPUT.PUT_LINE(ct(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache and Enqueue Services - Messaging Statistics"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Cache and Enqueue Services - Messaging Statistics"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Time(ms)" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache and Enqueue Services - Messaging Statistics End----------------------------------
---------------------------------Global Cache Messaging Statistics Sent----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glesper = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select 100*dmsd/decode((dmsd+dmsi+dmfc),0,null,(dmsd+dmsi+dmfc))    dmsdp
     , 100*dmsi/decode((dmsd+dmsi+dmfc),0,null,(dmsd+dmsi+dmfc))    dmsip
     , 100*dmfc/decode((dmsd+dmsi+dmfc),0,null,(dmsd+dmsi+dmfc))    dmfcp
	 ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.instance_number,s.snap_id,s.end_interval_time
              , se.name
              , (se.value - nvl(sb.value,0))    value
           from dba_hist_dlm_misc sb
              , dba_hist_dlm_misc se
           ,dba_hist_snapshot       s
         where se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and s.snap_id >=&bid and s.snap_id <=&eid and se.instance_number=&inid
            and se.dbid            = sb.dbid             (+)
            and se.instance_number = sb.instance_number  (+)
            and se.statistic#      = sb.statistic#       (+)
            and se.name            = sb.name             (+)
            and se.name in ( 'msgs sent queued', 'msgs sent queue time (ms)'
                , 'msgs sent queue time on ksxp (ms)', 'msgs sent queued on ksxp'
                , 'msgs received queue time (ms)', 'msgs received queued' 
                , 'gcs msgs received', 'gcs msgs process time(ms)'
                , 'ges msgs received', 'ges msgs process time(ms)'
                , 'messages sent directly', 'messages sent indirectly'
                , 'messages flow controlled'
                ))
           pivot (sum(value) for name in (
                 'msgs sent queued'                        msgsq
               , 'msgs sent queue time (ms)'              msgsqt
               , 'msgs sent queue time on ksxp (ms)'     msgsqtk
               , 'msgs sent queued on ksxp'               msgsqk
               , 'msgs received queue time (ms)'          msgrqt
               , 'msgs received queued'                    msgrq
               , 'gcs msgs received'                        pmrv
               , 'gcs msgs process time(ms)'                pmpt
               , 'ges msgs received'                       npmrv
               , 'ges msgs process time(ms)'               npmpt
               , 'messages sent directly'                   dmsd
               , 'messages sent indirectly'                 dmsi
               , 'messages flow controlled'                 dmfc))) st
 order by snap_time;
Fetch se_cur bulk collect
    into rt, pt,st,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "% of flow controlled messages",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "% of indirect sent messages",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "% of direct sent messages",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache Messaging Statistics Sent"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global Cache Messaging Statistics Sent"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Percentage" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global Cache Messaging Statistics Sent End----------------------------------
----------------------------gclost-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var gclostdata = { type: "line", data: { labels: [');
open my_cur for
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER, STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME in ('gc cr blocks received','gc cr blocks served','gc current blocks received',
    'gc current blocks served','gc blocks lost')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, begin_snap_id, end_snap_id,
       SUM(DECODE(stat_name, 'gc cr blocks received', (NVL(end_value,0)-NVL(begin_value,0)), 0)) cr_blks_recv,
       SUM(DECODE(stat_name, 'gc cr blocks served',   (NVL(end_value,0)-NVL(begin_value,0)),0))  cr_blks_serv,
       SUM(DECODE(stat_name, 'gc current blocks received',(NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_recv,
       SUM(DECODE(stat_name, 'gc current blocks served',  (NVL(end_value,0)-NVL(begin_value,0)), 0)) cur_blks_serv,
       SUM(DECODE(stat_name, 'gc blocks lost', (NVL(end_value,0)-NVL(begin_value,0)), 0)) gcs_blks_lost
    FROM x 
    WHERE begin_snap_id IS NOT NULL
    GROUP BY dbid, instance_number, begin_snap_id, end_snap_id
 ),
 z AS (
    SELECT a.dbid, a.instance_number, a.snap_id, a.end_snap_time2 end_snap_time,
       TRUNC(EXTRACT(DAY from a.end_snap_time2-a.end_snap_time1)*24*60*60 +
       EXTRACT(HOUR from      a.end_snap_time2-a.end_snap_time1)*60*60 +
       EXTRACT(MINUTE from    a.end_snap_time2-a.end_snap_time1)*60 +
       EXTRACT(SECOND from    a.end_snap_time2-a.end_snap_time1)) duration, b.VALUE blk_size
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid
       ) a JOIN DBA_HIST_PARAMETER b
       ON (a.DBID=b.DBID AND a.INSTANCE_NUMBER=b.INSTANCE_NUMBER AND a.SNAP_ID=b.SNAP_ID)
    WHERE a.end_snap_time1 IS NOT NULL AND b.PARAMETER_NAME='db_block_size'
 )
 SELECT /*+ NO_MERGE(z) */ 
  ROUND((y.gcs_blks_lost)/z.duration,2) gc_blks_lost_per_second,
 ROUND((y.cr_blks_recv+ y.cur_blks_recv)/z.duration,2) gc_blks_recv_per_second,
 ROUND((y.cr_blks_serv+ y.cur_blks_serv)/z.duration,2) gc_blks_serv_per_second,
 '"'||to_char(z.end_snap_time, 'mm-dd hh24:mi')||'"' snap_time
 FROM y JOIN z ON (y.dbid=z.dbid AND y.instance_number=z.instance_number AND y.end_snap_id=z.snap_id)
 ORDER BY snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "GC Blocks Lost",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC Blocks Received",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC Blocks Served",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Global Cache Blocks Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Global Cache Blocks Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Blocks/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------gclost end----------------------------
----------------------------gcms--------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  GCMessage       ValueList; ---archive log size
  GCMessage_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var gcmsdata = { type: "line", data: { labels: [');
  OPEN   GCMessage_cur FOR 
    select  
           trunc((a2.gm - lag(a2.gm, 1, a2.gm) over(order by a2.snap_id)) / &_iv) gm,
           (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid)  snap_time
      from (select a1.snap_id,
                   sum(case
                         when a1.stat_name = 'ges messages sent' or
                              a1.stat_name = 'gcs messages sent' then
                          a1.value
                         else
                          0
                       end) gm
              from (select a.snap_id, a.stat_name, a.value
                      from dba_hist_sysstat a
                     where (a.stat_name = 'ges messages sent' or
                           a.stat_name = 'gcs messages sent')
                       and snap_id >= &bid
                       and snap_id <= &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name) a1
             group by a1.snap_id
             order by a1.snap_id) a2;     
    FETCH  GCMessage_cur BULK COLLECT INTO GCMessage,SNAPTIME;
    CLOSE  GCMessage_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 GCMessage.extend;
 GCMessage(1):='0';
end if;
-----------------------------------------      
/*+copyright wangwenjie , do not copy this code to other business software*/
    FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('], datasets: [{');
    DBMS_OUTPUT.PUT_LINE('label: "GCS/GES Messages ",');
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
    DBMS_OUTPUT.PUT_LINE('data: [');
    FOR i IN GCMessage.FIRST .. GCMessage.LAST LOOP
    if (i < GCMessage.count) then
      DBMS_OUTPUT.PUT_LINE(GCMessage(i) || ',');
    elsif (i = GCMessage.count) then
      DBMS_OUTPUT.PUT_LINE(GCMessage(i));
    end if;
    END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - GCS/GES Messages"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Counts/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
END;
/
-----------------------------gcmsend--------------------------------
--------------------------gcblocktime------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  avg_cr       ValueList; ---avg Global Cache Average CR Get Time 
  max_cr       ValueList; ---max Global Cache Average CR Get Time
  avg_current  ValueList; ---avg Global Cache Average Current Get Time
  max_current  ValueList; ---max Global Cache Average Current Get Time
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var gcbdata = { type: "line", data: { labels: [');    
  OPEN CR_CUR FOR 
          select   sum(maxval_cr) maxval_cr,sum(average_cr) average_cr,sum(maxval_cu) maxval_cu,sum(average_cu) average_cu,
          '"'||to_char(a2.begin_time,'mm-dd hh24:mi')||'"' begin_time
            from (select metric_name,  a.begin_time
                ,case when metric_name='Global Cache Average CR Get Time' then
                  sum(maxval) else
                  0 end maxval_cr
                   ,case when metric_name='Global Cache Average CR Get Time' then
                  sum(average) else
                  0 end average_cr
                   ,case when metric_name='Global Cache Average Current Get Time' then
                  sum(maxval) else
                  0 end maxval_cu
                   ,case when metric_name='Global Cache Average Current Get Time' then
                  sum(average) else
                  0 end average_cu
                from dba_hist_sysmetric_summary a
               where (a.metric_name like '%Global Cache Average CR Get Time%' or metric_name like '%Global Cache Average Current Get Time%')
                 and a.instance_number = &inid
                 and a.snap_id >= &bid
                 and a.snap_id <= &eid group by a.snap_id, a.metric_name,a.begin_time
               order by a.snap_id) a2  group by a2.begin_time order by a2.begin_time;
    FETCH CR_CUR     BULK COLLECT    INTO MAX_CR,AVG_CR,max_current,avg_current,SNAPTIME;
    close CR_CUR;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 AVG_CR.extend;
 AVG_CR(1):='0';
  MAX_CR.extend;
 MAX_CR(1):='0';
  avg_current.extend;
 avg_current(1):='0';
  max_current.extend;
 max_current(1):='0';
end if;
-----------------------------------------      
     FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
        END LOOP;
    DBMS_OUTPUT.PUT_LINE('],  datasets: [{');
    DBMS_OUTPUT.PUT_LINE('label: "Global Cache Average CR Time",');
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink2,');
    DBMS_OUTPUT.PUT_LINE('data: [');
         FOR i IN avg_cr.FIRST .. avg_cr.LAST LOOP
        if (i < avg_cr.count) then
          DBMS_OUTPUT.PUT_LINE(avg_cr(i) || ',');
        elsif (i = avg_cr.count) then
          DBMS_OUTPUT.PUT_LINE(avg_cr(i));
        end if;
        END LOOP; 
    DBMS_OUTPUT.PUT_LINE('], }, {');  
    DBMS_OUTPUT.PUT_LINE('label: "Global Cache MAX CR Time",');  
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('fill: false,');  
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');  
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');  
    DBMS_OUTPUT.PUT_LINE('borderDash: [5, 5],');  
    DBMS_OUTPUT.PUT_LINE('data: [');  
     FOR i IN max_cr.FIRST .. max_cr.LAST LOOP
        if (i < max_cr.count) then
          DBMS_OUTPUT.PUT_LINE(max_cr(i) || ',');
        elsif (i = max_cr.count) then
          DBMS_OUTPUT.PUT_LINE(max_cr(i));
        end if;
        END LOOP;
    DBMS_OUTPUT.PUT_LINE('], },{'); 
    DBMS_OUTPUT.PUT_LINE('label: "Global Cache Average Current Get Time",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,'); 
    DBMS_OUTPUT.PUT_LINE('data: ['); 
 FOR i IN max_current.FIRST .. max_current.LAST LOOP
        if (i < max_current.count) then
          DBMS_OUTPUT.PUT_LINE(max_current(i) || ',');
        elsif (i = max_current.count) then
          DBMS_OUTPUT.PUT_LINE(max_current(i));
        end if;
        END LOOP;
    DBMS_OUTPUT.PUT_LINE('],  fill: false,}, {'); 
    DBMS_OUTPUT.PUT_LINE('label: "Global Cache MAX Current Get Time",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('fill: false,'); 
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('borderDash: [5, 5],'); 
    DBMS_OUTPUT.PUT_LINE('data: ['); 
    FOR i IN avg_current.FIRST .. avg_current.LAST LOOP
        if (i < avg_current.count) then
          DBMS_OUTPUT.PUT_LINE(avg_current(i) || ',');
        elsif (i = avg_current.count) then
          DBMS_OUTPUT.PUT_LINE(avg_current(i));
        end if;
        END LOOP;
DBMS_OUTPUT.PUT_LINE('], }]},');
DBMS_OUTPUT.PUT_LINE('options: {');
DBMS_OUTPUT.PUT_LINE('responsive: true,');
DBMS_OUTPUT.PUT_LINE('title:{');
DBMS_OUTPUT.PUT_LINE('display:true,');
DBMS_OUTPUT.PUT_LINE('text:"&_dbname&inid - GC CR/CURRENT BLOCK TIME"');
DBMS_OUTPUT.PUT_LINE('},');
DBMS_OUTPUT.PUT_LINE('tooltips: {');
DBMS_OUTPUT.PUT_LINE('mode: "index",');
DBMS_OUTPUT.PUT_LINE('intersect: false,');
DBMS_OUTPUT.PUT_LINE('},');
DBMS_OUTPUT.PUT_LINE('hover: {');
DBMS_OUTPUT.PUT_LINE('mode: "nearest",');
DBMS_OUTPUT.PUT_LINE('intersect: true');
DBMS_OUTPUT.PUT_LINE('},');
DBMS_OUTPUT.PUT_LINE('scales: {');
DBMS_OUTPUT.PUT_LINE('xAxes: [{');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('labelString: "Snap"');
DBMS_OUTPUT.PUT_LINE('}');
DBMS_OUTPUT.PUT_LINE('}],');
DBMS_OUTPUT.PUT_LINE('yAxes: [{');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('display: true,');
DBMS_OUTPUT.PUT_LINE('labelString: "Value"');
DBMS_OUTPUT.PUT_LINE('} }] } } };');
END;
/
-----auther wangwenjie-----gcblocktime end--------------------
---------------------------------Global CR Served Stats----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  ft 	ValueList;
  ct 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var glcrss = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(CR_REQUESTS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_cr_requests,       CR_REQUESTS end_cr_requests,
    LAG(CURRENT_REQUESTS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_cur_requests, CURRENT_REQUESTS end_cur_requests,
    LAG(DATA_REQUESTS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_data_requests,   DATA_REQUESTS end_data_requests,
    LAG(UNDO_REQUESTS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_undo_requests,   UNDO_REQUESTS end_undo_requests,
    LAG(TX_REQUESTS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) begin_tx_requests,       TX_REQUESTS end_tx_requests
    FROM DBA_HIST_CR_BLOCK_SERVER
    WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, z.END_INTERVAL_TIME end_snap_time, x.instance_number,
    (NVL(x.end_cr_requests,0)- NVL(x.begin_cr_requests,0))  cr_requests,
    (NVL(x.end_cur_requests,0)-NVL(x.begin_cur_requests,0)) current_requests,
    (NVL(x.end_data_requests,0)-NVL(x.begin_data_requests,0)) data_requests,
    (NVL(x.end_undo_requests,0)-NVL(x.begin_undo_requests,0)) undo_requests,
    (NVL(x.end_tx_requests,0)-NVL(x.begin_tx_requests,0)) tx_requests
    FROM x JOIN DBA_HIST_SNAPSHOT z ON (x.dbid=z.DBID AND x.instance_number=z.INSTANCE_NUMBER AND x.end_snap_id=z.SNAP_ID)
    WHERE x.begin_snap_id IS NOT NULL
 )
 SELECT CR_REQUESTS, CURRENT_REQUESTS, DATA_REQUESTS, UNDO_REQUESTS, TX_REQUESTS,
  '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM y
 ORDER BY snap_time;
Fetch se_cur bulk collect
    into rt, pt,st,ft,ct,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
  ft.extend;
 ft(1):='0';
 ct.extend;
 ct(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Data Block Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "CURRENT Block Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "CR Block Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Undo Block Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ft.FIRST .. ft.LAST LOOP
    if (i < ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i) || ',');
    elsif (i = ft.count) then
      DBMS_OUTPUT.PUT_LINE(ft(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "TX Block Requests",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ct.FIRST .. ct.LAST LOOP
    if (i < ct.count) then
      DBMS_OUTPUT.PUT_LINE(ct(i) || ',');
    elsif (i = ct.count) then
      DBMS_OUTPUT.PUT_LINE(ct(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Global CR Served Stats"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Global CR Served Stats"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Blocks/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Global CR Served Stats----------------------------------

---------------------------lib hit-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  LIBRARY_HIT       ValueList; --- Library hit %
  LIB_CUR           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var libdata = { type: "line", data: { labels: [');
  OPEN LIB_CUR FOR   
    select  (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid)  snap_time,
           trunc(a2.ph / a2.p * 100, 2) hit
      from (SELECT snap_id,
                   a1.ph - lag(a1.ph, 1, a1.ph) over(order by a1.snap_id) ph,
                   a1.p - lag(a1.p, 1, a1.p) over(order by a1.snap_id) p
              from (select snap_id, sum(pinhits) PH, sum(pins) P
                      from DBA_HIST_LIBRARYCACHE
                     WHERE SNAP_ID >= &bid
                       AND SNAP_ID <= &eid
                       and instance_number = &inid
                     group by snap_id
                     ORDER BY SNAP_ID) a1) a2
     where p > 0;

   FETCH LIB_CUR BULK COLLECT INTO SNAPTIME ,LIBRARY_HIT;
   CLOSE LIB_CUR;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 LIBRARY_HIT.extend;
 LIBRARY_HIT(1):='0';
end if;
-----------------------------------------     
   FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;                                  
    DBMS_OUTPUT.PUT_LINE('], datasets: [{');
    DBMS_OUTPUT.PUT_LINE('label: "Library cache hit point",');
    DBMS_OUTPUT.PUT_LINE('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
    DBMS_OUTPUT.PUT_LINE('data: [');
    FOR i IN LIBRARY_HIT.FIRST .. LIBRARY_HIT.LAST LOOP
        if (i < LIBRARY_HIT.count) then
          DBMS_OUTPUT.PUT_LINE(LIBRARY_HIT(i) || ',');
        elsif (i = LIBRARY_HIT.count) then
          DBMS_OUTPUT.PUT_LINE(LIBRARY_HIT(i));
        end if;
    END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Library Cache Hit Ratio"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Value"                   ');
dbms_output.put_line('}  }] }  } };                          ');
END;
/
-----------------------lib hint end------------------------------------------------------
-------------------------Latch:Library Cache - Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchlc = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='library cache load lock'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:Library Cache - Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch:Library Cache - Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:Library Cache - Get/Miss Percentage---------------------
----------------------------Latch:Library Cache Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var lcbrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='library cache load lock'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Library Cache - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Library Cache - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Library Cache - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch:Library Cache Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch:Library Cache Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch Shared Pool Statistic End----------------------------
-----------------------------LIBRARY CACHE SQL AREA----------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  reload       ValueList; 
  invalid          ValueList;
  lcsql           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var libsqlarea = { type: "line", data: { labels: [');
  OPEN lcsql FOR   
  select '"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,e.reloads - b.reloads reloads
, e.invalidations - b.invalidations invalid
from dba_hist_librarycache b
, dba_hist_librarycache e
,dba_hist_snapshot       s
where e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.namespace = e.namespace
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
and b.namespace='SQL AREA'
order by snap_time;
    FETCH lcsql BULK COLLECT INTO SNAPTIME,invalid,reload;
    CLOSE lcsql;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 reload.extend;
 reload(1):='0';
  invalid.extend;
 invalid(1):='0';
end if;
-----------------------------------------      
    FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ], datasets: [{'); 
    DBMS_OUTPUT.PUT_LINE('label: "Reloads",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('data: [   '); 
     FOR i IN reload.FIRST .. reload.LAST LOOP
        if (i < reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i) || ',');
        elsif (i = reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
    DBMS_OUTPUT.PUT_LINE('label: "Invalidations",');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('data: [');
     FOR i IN invalid.FIRST .. invalid.LAST LOOP
        if (i < invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i) || ',');
        elsif (i = invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i));
        end if;
    END LOOP;
dbms_output.put_line('], }] },                ');     
dbms_output.put_line('options: {              ');
dbms_output.put_line('responsive: true,       ');
dbms_output.put_line('title:{                 ');
dbms_output.put_line('display:true,           ');
dbms_output.put_line('text:"&_dbname&inid - LIBRARY CACHE SQL AREA" ');
dbms_output.put_line('},                      ');
dbms_output.put_line('tooltips: {             ');
dbms_output.put_line('mode: "index",          ');
dbms_output.put_line('intersect: false,       ');
dbms_output.put_line('},                      ');
dbms_output.put_line('hover: {                ');
dbms_output.put_line('mode: "nearest",        ');
dbms_output.put_line('intersect: true         ');
dbms_output.put_line('},                      ');
dbms_output.put_line('scales: {               ');
dbms_output.put_line('xAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString: "Snap"     ');
dbms_output.put_line('}                       ');
dbms_output.put_line('}],                     ');
dbms_output.put_line('yAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString:  "Count"   ');
dbms_output.put_line('} }] } } };             ');
END;
/
--------------------LIBRARY CACHE SQL AREA END-------------------------
-----------------------------LIBRARY CACHE TABLE/PROCEDURE----------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  reload       ValueList; 
  invalid          ValueList;
  lcsql           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var libtabpro = { type: "line", data: { labels: [');
  OPEN lcsql FOR   
  select '"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,e.reloads - b.reloads reloads
, e.invalidations - b.invalidations invalid
from dba_hist_librarycache b
, dba_hist_librarycache e
,dba_hist_snapshot       s
where e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.namespace = e.namespace
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
and b.namespace='TABLE/PROCEDURE'
order by snap_time;
    FETCH lcsql BULK COLLECT INTO SNAPTIME,invalid,reload;
    CLOSE lcsql;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 reload.extend;
 reload(1):='0';
  invalid.extend;
 invalid(1):='0';
end if;
-----------------------------------------      
    FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ], datasets: [{'); 
    DBMS_OUTPUT.PUT_LINE('label: "Reloads",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('data: [   '); 
     FOR i IN reload.FIRST .. reload.LAST LOOP
        if (i < reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i) || ',');
        elsif (i = reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
    DBMS_OUTPUT.PUT_LINE('label: "Invalidations",');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('data: [');
     FOR i IN invalid.FIRST .. invalid.LAST LOOP
        if (i < invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i) || ',');
        elsif (i = invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i));
        end if;
    END LOOP;
dbms_output.put_line('], }] },                ');     
dbms_output.put_line('options: {              ');
dbms_output.put_line('responsive: true,       ');
dbms_output.put_line('title:{                 ');
dbms_output.put_line('display:true,           ');
dbms_output.put_line('text:"&_dbname&inid - LIBRARY CACHE TABLE/PROCEDURE" ');
dbms_output.put_line('},                      ');
dbms_output.put_line('tooltips: {             ');
dbms_output.put_line('mode: "index",          ');
dbms_output.put_line('intersect: false,       ');
dbms_output.put_line('},                      ');
dbms_output.put_line('hover: {                ');
dbms_output.put_line('mode: "nearest",        ');
dbms_output.put_line('intersect: true         ');
dbms_output.put_line('},                      ');
dbms_output.put_line('scales: {               ');
dbms_output.put_line('xAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString: "Snap"     ');
dbms_output.put_line('}                       ');
dbms_output.put_line('}],                     ');
dbms_output.put_line('yAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString:  "Count"   ');
dbms_output.put_line('} }] } } };             ');
END;
/
--------------------LIBRARY CACHE TABLE/PROCEDURE END-------------------------
-----------------------------LIBRARY CACHE SQL AREA STATS----------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  reload       ValueList; 
  invalid          ValueList;
  lcsql           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var libsqlareastat = { type: "line", data: { labels: [');
  OPEN lcsql FOR   
  select '"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,e.reloads - b.reloads reloads
, e.invalidations - b.invalidations invalid
from dba_hist_librarycache b
, dba_hist_librarycache e
,dba_hist_snapshot       s
where e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.namespace = e.namespace
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
and b.namespace='SQL AREA STATS'
order by snap_time;
    FETCH lcsql BULK COLLECT INTO SNAPTIME,invalid,reload;
    CLOSE lcsql;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 reload.extend;
 reload(1):='0';
  invalid.extend;
 invalid(1):='0';
end if;
-----------------------------------------      
    FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ], datasets: [{'); 
    DBMS_OUTPUT.PUT_LINE('label: "Reloads",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('data: [   '); 
     FOR i IN reload.FIRST .. reload.LAST LOOP
        if (i < reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i) || ',');
        elsif (i = reload.count) then
          DBMS_OUTPUT.PUT_LINE(reload(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
    DBMS_OUTPUT.PUT_LINE('label: "Invalidations",');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('data: [');
     FOR i IN invalid.FIRST .. invalid.LAST LOOP
        if (i < invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i) || ',');
        elsif (i = invalid.count) then
          DBMS_OUTPUT.PUT_LINE(invalid(i));
        end if;
    END LOOP;
dbms_output.put_line('], }] },                ');     
dbms_output.put_line('options: {              ');
dbms_output.put_line('responsive: true,       ');
dbms_output.put_line('title:{                 ');
dbms_output.put_line('display:true,           ');
dbms_output.put_line('text:"&_dbname&inid - LIBRARY CACHE SQL AREA STATS" ');
dbms_output.put_line('},                      ');
dbms_output.put_line('tooltips: {             ');
dbms_output.put_line('mode: "index",          ');
dbms_output.put_line('intersect: false,       ');
dbms_output.put_line('},                      ');
dbms_output.put_line('hover: {                ');
dbms_output.put_line('mode: "nearest",        ');
dbms_output.put_line('intersect: true         ');
dbms_output.put_line('},                      ');
dbms_output.put_line('scales: {               ');
dbms_output.put_line('xAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString: "Snap"     ');
dbms_output.put_line('}                       ');
dbms_output.put_line('}],                     ');
dbms_output.put_line('yAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString:  "Count"   ');
dbms_output.put_line('} }] } } };             ');
END;
/
--------------------LIBRARY CACHE SQL AREA STATS END-------------------------
--------------------------latch hint--------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  LATCH_HIT          ValueList; --- Latch hit %
  LATCH_CUR           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var latchdata = { type: "line", data: { labels: [');
  OPEN LATCH_CUR FOR  
      select trunc(100 - (misses / gets * 100), 2) Get_rate,---change Miss_rate from Get_rate on 2016-12-30 by MaXuefeng
              (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                   from dba_hist_snapshot f
                  where f.snap_id = a2.snap_id
                    and f.instance_number = &inid) snap_time
        from (select a1.snap_id,
                     a1.gets - lag(a1.gets, 1, a1.gets) over(order by a1.snap_id) gets,
                     a1.misses - lag(a1.misses, 1, a1.misses) over(order by a1.snap_id) misses
                from (select a.snap_id, sum(a.gets) gets, sum(a.misses) misses
                        from dba_hist_latch a
                       where a.instance_number = &inid
                         and a.snap_id >= &bid
                         and a.snap_id <= &eid
                       group by a.snap_id
                       order by a.snap_id) a1) a2
       where gets > 0;
   FETCH LATCH_CUR BULK COLLECT INTO LATCH_HIT,SNAPTIME;
   CLOSE LATCH_CUR;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 LATCH_HIT.extend;
 LATCH_HIT(1):='0';
end if;
-----------------------------------------      
   FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('], datasets: [{');
    DBMS_OUTPUT.PUT_LINE('label: "Latch hit point",');
    DBMS_OUTPUT.PUT_LINE('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
    DBMS_OUTPUT.PUT_LINE('data: [');
    FOR i IN LATCH_HIT.FIRST .. LATCH_HIT.LAST LOOP
        if (i < LATCH_HIT.count) then
          DBMS_OUTPUT.PUT_LINE(LATCH_HIT(i) || ',');
        elsif (i = LATCH_HIT.count) then
          DBMS_OUTPUT.PUT_LINE(LATCH_HIT(i));
        end if;
    END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Hit Ratio"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
END;
/
-------------------------------------latch hint end--------------------------------------
-------------------------Latch:Shared Pool- Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchspdata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='shared pool'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:Shared Pool- Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Shared Pool- Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:Shared Pool- Get/Miss Percentage---------------------
----------------------------Latch Shared Pool Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var spbrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='shared pool'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Shared Pool - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Shared Pool - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Shared Pool - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Shared Pool Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch Shared Pool Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch Shared Pool Statistic End----------------------------
-------------------------Latch:Row Cache Objects - Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchrcodata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='row cache objects'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:Row Cache Objects - Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Row Cache Objects - Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:row cache objects - Get/Miss Percentage---------------------
----------------------------Latch Row Cache Objects Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var rcobrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='row cache objects'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Row Cache Objects - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Row Cache Objects - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Row Cache Objects - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Row Cache Objects Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch Row Cache Objects Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch Row Cache Objects Statistic End----------------------------
-------------------------Latch:cache buffers chains - Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchcbcdata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='cache buffers chains'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:cache buffers chains - Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Cache Buffer Chain - Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:cache buffers chains - Get/Miss Percentage---------------------
----------------------------Latch Cache Buffer Chain Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var cbcbrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='cache buffers chains'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cache Buffer Chain - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cache Buffer Chain - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cache Buffer Chain - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Cache Buffer Chain Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch Cache Buffer Chain Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch Cache Buffer Chain Statistic End----------------------------
-------------------------Latch:Cache Buffers LRU Chain- Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchlrudata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='cache buffers lru chain'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:Cache Buffers LRU Chain- Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Cache Buffers LRU Chain- Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:Cache Buffers LRU Chain- Get/Miss Percentage---------------------
----------------------------Latch Cache Buffers LRU Chain Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var cbclrubrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='cache buffers lru chain'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cache Buffers LRU Chain - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cache Buffers LRU Chain - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Cache Buffers LRU Chain - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch Cache Buffers LRU Chain Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch Cache Buffers LRU Chain Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch Cache Buffers LRU Chain Statistic End----------------------------
-------------------------Latch:GC Element- Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchgcdata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='gc element'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:GC Element- Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch GC Element- Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:GC Element- Get/Miss Percentage---------------------
----------------------------Latch GC Element Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var gcbrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='gc element'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "GC Element - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC Element - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "GC Element - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch GC Element Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch GC Element Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch GC Element Statistic End----------------------------
-------------------------Latch:DML Lock Allocation- Get/Miss Percentage-------------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
latch_cbc ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var latchdmldata = { type: "line", data: { labels: [');
open my_cur for
select to_number(decode(e.gets, b.gets, null,(e.misses - b.misses) * 100/(e.gets - b.gets))) pctgetmis,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='DML lock allocation'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0
and s.snap_id >=&bid and s.snap_id <=&eid and s.instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO latch_cbc,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 latch_cbc.extend;
 latch_cbc(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Latch:DML Lock Allocation- Get/Miss Percentage  ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.green0,');
dbms_output.put_line('borderColor: window.awrColors.green2,');
dbms_output.put_line('data: [');
------------------------------
 FOR i IN latch_cbc.FIRST .. latch_cbc.LAST
LOOP
  if(i<latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i)||',');
elsif(i=latch_cbc.count) then
DBMS_OUTPUT.PUT_LINE (latch_cbc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch DML Lock Allocation- Get/Miss Percentage"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "%"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
----------------------------Latch:DML Lock Allocation- Get/Miss Percentage---------------------
----------------------------Latch DML Lock Allocation Statistic-----------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
gclostdata ValueList;
gclr ValueList;
gcls ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var dmlbrk = { type: "line", data: { labels: [');
open my_cur for
select round(gets/s_et,2) gets, round(misses/s_et,2) misses, round(sleeps/s_et,2) sleeps,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time from (
select s.end_interval_time,s.snap_id,s.instance_number,e.latch_name latchname, e.gets - b.gets gets,
e.misses-b.misses misses,
e.sleeps-b.sleeps sleeps,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
from dba_hist_latch b
, dba_hist_latch e
,dba_hist_snapshot       s
where b.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.instance_number = e.instance_number
and e.latch_name='DML lock allocation'
and b.latch_hash = e.latch_hash
and e.gets - b.gets > 0)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 FETCH my_cur BULK COLLECT INTO gclostdata,gclr,gcls,snaptime;
 close my_cur;
   ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 gclostdata.extend;
 gclostdata(1):='0';
  gclr.extend;
 gclr(1):='0';
  gcls.extend;
 gcls(1):='0';
end if;
-----------------------------------------   
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "DML Lock Allocation - Gets/Sec",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red1,');
dbms_output.put_line('data: [');
 FOR i IN gclostdata.FIRST .. gclostdata.LAST
LOOP
  if(i<gclostdata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (gclostdata(i)||',');
end if;
elsif(i=gclostdata.count) then
DBMS_OUTPUT.PUT_LINE (gclostdata(i));
end if;
END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DML Lock Allocation - Misses/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gclr.FIRST .. gclr.LAST LOOP
    if (i < gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i) || ',');
    elsif (i = gclr.count) then
      DBMS_OUTPUT.PUT_LINE(gclr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DML Lock Allocation - Sleeps/Sec",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN gcls.FIRST .. gcls.LAST LOOP
    if (i < gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i) || ',');
    elsif (i = gcls.count) then
      DBMS_OUTPUT.PUT_LINE(gcls(i));
    end if;
	END LOOP;
dbms_output.put_line('], fill: false, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Latch DML Lock Allocation Statistic"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Latch DML Lock Allocation Statistic"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------Latch DML Lock Allocation Statistic End----------------------------
---------------------------------CHAIN ROWS----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var fctdata = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(phyread/s_et,2) phyread
     , round(phyreadcach/s_et,2) phyreadcach
     ,round(phyreaddir/s_et,2) phyreaddir,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'table fetch by rowid','table fetch continued row','table scan rows gotten'))
         pivot (sum(value) for stat_name in (
'table fetch by rowid' phyread,                  
'table fetch continued row'  phyreadcach,         
'table scan rows gotten' phyreaddir
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Table scan rows gotten",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Table fetch continued row",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Table fetch by rowid",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Chain Rows"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Chain Rows"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Rows/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Chain Rows----------------------------------
---------------------------------TABLE SCANS----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  ls     ValueList; 
  sc       ValueList; 
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var tablescan = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(longscan/s_et,2) longscan
     , round(shortscan/s_et,2) shortscan
     ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'table scans (long tables)','table scans (short tables)'))
         pivot (sum(value) for stat_name in (
'table scans (long tables)' longscan,                  
'table scans (short tables)'  shortscan
))) order by snap_time;
Fetch se_cur bulk collect
    into ls,sc,SNAPTIME;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ls.extend;
ls(1):='0';
 sc.extend;
sc(1):='0';

end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Short Tables",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN sc.FIRST .. sc.LAST LOOP
    if (i < sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i) || ',');
    elsif (i = sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Long Tables",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ls.FIRST .. ls.LAST LOOP
    if (i < ls.count) then
      DBMS_OUTPUT.PUT_LINE(ls(i) || ',');
    elsif (i = ls.count) then
      DBMS_OUTPUT.PUT_LINE(ls(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Table Scans"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Table Scans"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Tables/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Table Scans Ends----------------------------------
---------------------------------Average Active Session----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  cpucore     ValueList; ----CPUCore
  aas       ValueList; ---AAS 
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var avact = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
    SELECT * FROM
( 
 select s3t2.value,
  ((s5t1.value - s5t0.value) / 1000000)/60/round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2) aas,
'"'||to_char(s1.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,s1.snap_id
FROM dba_hist_snapshot s0,
  dba_hist_snapshot s1,
  dba_hist_osstat s3t1,
  dba_hist_osstat s3t2, 
  dba_hist_sys_time_model s5t0,
  dba_hist_sys_time_model s5t1
WHERE s1.dbid              = s0.dbid
AND s3t1.dbid            = s0.dbid
AND s3t2.dbid            = s0.dbid
AND s5t0.dbid            = s0.dbid
AND s5t1.dbid            = s0.dbid
AND s1.instance_number   = s0.instance_number
AND s3t1.instance_number = s0.instance_number
AND s3t2.instance_number = s0.instance_number
AND s5t0.instance_number = s0.instance_number
AND s5t1.instance_number = s0.instance_number
AND s1.snap_id           = s0.snap_id + 1
AND s3t1.snap_id         = s0.snap_id + 1
AND s3t2.snap_id         = s0.snap_id + 1
AND s5t0.snap_id         = s0.snap_id
AND s5t1.snap_id         = s0.snap_id + 1
AND s3t1.stat_name       = 'NUM_CPUS'
AND s3t2.stat_name       = 'NUM_CPU_CORES'
AND s5t0.stat_name       = 'DB time'
AND s5t1.stat_name       = s5t0.stat_name
and s0.snap_id >= &bid
and s0.snap_id <= &eid
and s0.instance_number= &inid
order by snap_time
);
  Fetch se_cur bulk collect
    into cpucore, aas, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cpucore.extend;
 cpucore(1):='0';
 aas.extend;
 aas(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "CpuCores",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN cpucore.FIRST .. cpucore.LAST LOOP
    if (i < cpucore.count) then
      DBMS_OUTPUT.PUT_LINE(cpucore(i) || ',');
    elsif (i = cpucore.count) then
      DBMS_OUTPUT.PUT_LINE(cpucore(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "AAS",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN aas.FIRST .. aas.LAST LOOP
    if (i < aas.count) then
      DBMS_OUTPUT.PUT_LINE(aas(i) || ',');
    elsif (i = aas.count) then
      DBMS_OUTPUT.PUT_LINE(aas(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - AvgActSession"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Snap"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "AAS" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------average active session end--------------------------
---------------------------------OS Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  osbusy     ValueList; ---osbusy
  osidle       ValueList; ---osidle 
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var osstat = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   select 100 * busy_time_v/decode(busy_time_v + idle_time_v,0,null,busy_time_v+idle_time_v)  pct_busy
     , 100 * idle_time_v/decode(busy_time_v + idle_time_v,0,null,busy_time_v+idle_time_v)  pct_idl
	 ,snap_time,snap_id
  from ((select se.snap_id,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time
             , se.stat_name
             , sb.value bval
             , se.value eval
             , (se.value - nvl(sb.value,0))  value
        from dba_hist_osstat sb
           , dba_hist_osstat se
           ,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
             AND se.instance_number = s.instance_number
  and s.snap_id >= &bid
and s.snap_id <= &eid
and i.instance_number= &inid)
        pivot (sum(value) v, max(bval) b, max(eval) e 
               for stat_name in (
              'BUSY_TIME'  busy_time
              ,'IDLE_TIME'  idle_time))) order by snap_time;
  Fetch se_cur bulk collect
    into osbusy, osidle, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 osbusy.extend;
 osbusy(1):='0';
 osidle.extend;
 osidle(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Busy",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN osbusy.FIRST .. osbusy.LAST LOOP
    if (i < osbusy.count) then
      DBMS_OUTPUT.PUT_LINE(osbusy(i) || ',');
    elsif (i = osbusy.count) then
      DBMS_OUTPUT.PUT_LINE(osbusy(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Idle",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN osidle.FIRST .. osidle.LAST LOOP
    if (i < osidle.count) then
      DBMS_OUTPUT.PUT_LINE(osidle(i) || ',');
    elsif (i = osidle.count) then
      DBMS_OUTPUT.PUT_LINE(osidle(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - OS Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Snap"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Percent" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------OS End----------------------------------
---------------------------------Memory Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  sga     ValueList; ---sga
  pga       ValueList; ---pga 
  dbmem 	ValueList;
  osmem 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var memstat = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   SELECT 
    MAX (DECODE (stat_name, 'SGA', stat_value, NULL)) sga,
    MAX (DECODE (stat_name, 'PGA', stat_value, NULL)) pga,
    MAX (DECODE (stat_name, 'SGA', stat_value, NULL)) + MAX (DECODE (stat_name, 'PGA', stat_value,
    NULL)) dbmem,
    MAX (DECODE (stat_name, 'OSMEM', stat_value, NULL)) osmem,
	'"'||to_char(a.begin_interval_time, 'mm-dd hh24:mi')||'"' snap_time,b.snap_id
   FROM
    (SELECT snap_id,
        instance_number,
        ROUND (SUM (bytes) / 1024 / 1024 / 1024, 1) stat_value,
        MAX ('SGA') stat_name
       FROM dba_hist_sgastat
	   where  snap_id >= &bid
and snap_id <= &eid
and instance_number= &inid
   GROUP BY snap_id,
        instance_number
  UNION ALL
     SELECT snap_id,
        instance_number,
        ROUND (value / 1024 / 1024 / 1024, 1) stat_value,
        'PGA' stat_name
       FROM dba_hist_pgastat
      WHERE NAME = 'total PGA allocated'
  UNION ALL
     SELECT snap_id,
        instance_number,
        ROUND (value / 1024 / 1024 / 1024, 1) stat_value,
        'OSMEM' stat_name
       FROM dba_hist_osstat
      WHERE stat_name = 'PHYSICAL_MEMORY_BYTES'
    ) B, DBA_HIST_SNAPSHOT A
where A.INSTANCE_NUMBER = B.INSTANCE_NUMBER
AND A.SNAP_ID = B.SNAP_ID
and a.snap_id >= &bid
and a.snap_id <= &eid
and a.instance_number=&inid
GROUP BY b.snap_id,a.begin_interval_time,
    b.instance_number
ORDER BY b.snap_id;
  Fetch se_cur bulk collect
    into sga, pga, dbmem, osmem, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 sga.extend;
 sga(1):='0';
 pga.extend;
 pga(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "SGA",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN sga.FIRST .. sga.LAST LOOP
    if (i < sga.count) then
      DBMS_OUTPUT.PUT_LINE(sga(i) || ',');
    elsif (i = sga.count) then
      DBMS_OUTPUT.PUT_LINE(sga(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "PGA",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pga.FIRST .. pga.LAST LOOP
    if (i < pga.count) then
      DBMS_OUTPUT.PUT_LINE(pga(i) || ',');
    elsif (i = pga.count) then
      DBMS_OUTPUT.PUT_LINE(pga(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DBMem",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN dbmem.FIRST .. dbmem.LAST LOOP
    if (i < dbmem.count) then
      DBMS_OUTPUT.PUT_LINE(dbmem(i) || ',');
    elsif (i = dbmem.count) then
      DBMS_OUTPUT.PUT_LINE(dbmem(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "OSMem",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.yellow2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.yellow2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN osmem.FIRST .. osmem.LAST LOOP
    if (i < osmem.count) then
      DBMS_OUTPUT.PUT_LINE(osmem(i) || ',');
    elsif (i = osmem.count) then
      DBMS_OUTPUT.PUT_LINE(osmem(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Memory Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Snap"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Gb" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Memory Statistic End----------------------------------
---------------------------------Memory Free----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  Free     ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var memfree = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   SELECT 
    MAX (DECODE (stat_name, 'FREE', stat_value, NULL)) osfree,
	'"'||to_char(a.begin_interval_time, 'mm-dd hh24:mi')||'"' snap_time,b.snap_id
   FROM
    (SELECT snap_id,
        instance_number,
        ROUND (value / 1024 / 1024 / 1024, 1) stat_value,
        'FREE' stat_name
       FROM dba_hist_osstat
      WHERE stat_name = 'FREE_MEMORY_BYTES'
    ) B, DBA_HIST_SNAPSHOT A
where A.INSTANCE_NUMBER = B.INSTANCE_NUMBER
AND A.SNAP_ID = B.SNAP_ID
and a.snap_id >= &bid
and a.snap_id <= &eid
and a.instance_number=&inid
GROUP BY b.snap_id,a.begin_interval_time,
    b.instance_number
ORDER BY snap_time;
  Fetch se_cur bulk collect
    into Free, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 Free.extend;
 Free(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "OS Free Memory",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN Free.FIRST .. Free.LAST LOOP
    if (i < Free.count) then
      DBMS_OUTPUT.PUT_LINE(Free(i) || ',');
    elsif (i = Free.count) then
      DBMS_OUTPUT.PUT_LINE(Free(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - OS Memory Free"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "OS Memory Free"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Gb" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Memory Free End----------------------------------
---------------------------------OS Load ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  osload     ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var osload = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
  SELECT value,
	'"'||to_char(a.begin_interval_time, 'mm-dd hh24:mi')||'"' snap_time,b.snap_id
   FROM
    (     SELECT snap_id,
        instance_number,
        value
       FROM dba_hist_osstat
      WHERE stat_name = 'LOAD'
    ) B, DBA_HIST_SNAPSHOT A
where A.INSTANCE_NUMBER = B.INSTANCE_NUMBER
and A.snap_id >=&bid and A.snap_id <=&eid and A.instance_number=&inid
AND A.SNAP_ID = B.SNAP_ID
ORDER BY snap_time;
  Fetch se_cur bulk collect
    into osload, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 osload.extend;
 osload(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "OS Load",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN osload.FIRST .. osload.LAST LOOP
    if (i < osload.count) then
      DBMS_OUTPUT.PUT_LINE(osload(i) || ',');
    elsif (i = osload.count) then
      DBMS_OUTPUT.PUT_LINE(osload(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - OS Load"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "OS Load"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Count" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------OS Load End----------------------------------
-----------------------------BUFFER CACHE HIT RATIO----------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME         ValueList;
  Buffer_hit       ValueList; --- buffer hit %
  BH_CUR           sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var bchit = { type: "line", data: { labels: [');
  OPEN BH_CUR FOR   
 select '"'||to_char(sn.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time
, decode( e.db_block_gets - nvl(b.db_block_gets,0)+ e.consistent_gets - nvl(b.consistent_gets,0), 0, to_number(null), 
(100* (1 - ( (e.physical_reads - nvl(b.physical_reads,0))/ ( e.db_block_gets - nvl(b.db_block_gets,0)+ e.consistent_gets - nvl(b.consistent_gets,0)))))) poolhr
from dba_hist_buffer_pool_stat b
, dba_hist_buffer_pool_stat e,
DBA_HIST_snapshot sn
where sn.dbid = (select dbid from v$database)
  AND sn.dbid = e.dbid
  AND sn.instance_number = e.instance_number
  AND e.dbid = b.dbid
  AND e.instance_number = b.instance_number
  and e.name = b.name
  and e.snap_id = sn.snap_id
  AND b.snap_id = sn.snap_id-1
  and sn.snap_id >=&bid and sn.snap_id <=&eid and sn.instance_number=&inid
order by snap_time;
    FETCH BH_CUR BULK COLLECT INTO SNAPTIME,Buffer_hit;
    CLOSE BH_CUR;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 Buffer_hit.extend;
 Buffer_hit(1):='0';
end if;
-----------------------------------------      
    FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
        if (i < snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
        elsif (i = snaptime.count) then
          DBMS_OUTPUT.PUT_LINE(snaptime(i));
        end if;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(' ], datasets: [{'); 
    DBMS_OUTPUT.PUT_LINE('label: "Buffer Cache %",'); 
    DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,'); 
    DBMS_OUTPUT.PUT_LINE('data: [   '); 
     FOR i IN Buffer_hit.FIRST .. Buffer_hit.LAST LOOP
        if (i < Buffer_hit.count) then
          DBMS_OUTPUT.PUT_LINE(Buffer_hit(i) || ',');
        elsif (i = Buffer_hit.count) then
          DBMS_OUTPUT.PUT_LINE(Buffer_hit(i));
        end if;
    END LOOP;
dbms_output.put_line('], }] },                ');     
dbms_output.put_line('options: {              ');
dbms_output.put_line('responsive: true,       ');
dbms_output.put_line('title:{                 ');
dbms_output.put_line('display:true,           ');
dbms_output.put_line('text:"&_dbname&inid - BUFFER CACHE HIT RATIO" ');
dbms_output.put_line('},                      ');
dbms_output.put_line('tooltips: {             ');
dbms_output.put_line('mode: "index",          ');
dbms_output.put_line('intersect: false,       ');
dbms_output.put_line('},                      ');
dbms_output.put_line('hover: {                ');
dbms_output.put_line('mode: "nearest",        ');
dbms_output.put_line('intersect: true         ');
dbms_output.put_line('},                      ');
dbms_output.put_line('scales: {               ');
dbms_output.put_line('xAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString: "Snap"     ');
dbms_output.put_line('}                       ');
dbms_output.put_line('}],                     ');
dbms_output.put_line('yAxes: [{               ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('scaleLabel: {           ');
dbms_output.put_line('display: true,          ');
dbms_output.put_line('labelString:  "Percentage"   ');
dbms_output.put_line('} }] } } };             ');
END;
/
--------------------BUFFER CACHE HIT RATIO END-------------------------
---------------------------------Buffer Cache Wait Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  fbwait     ValueList; 
  wcwait       ValueList; 
  bbwait 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var buffercache = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
 select e.free_buffer_wait - nvl(b.free_buffer_wait,0) fbwait
, e.write_complete_wait - nvl(b.write_complete_wait,0) wcwait
, e.buffer_busy_wait - nvl(b.buffer_busy_wait,0) bbwait,
 '"'||to_char(sn.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,sn.snap_id
from dba_hist_buffer_pool_stat b
, dba_hist_buffer_pool_stat e,
DBA_HIST_snapshot sn
where sn.dbid = (select dbid from v$database)
  AND sn.dbid = e.dbid
  AND sn.instance_number = e.instance_number
  AND e.dbid = b.dbid
  AND e.instance_number = b.instance_number
  and e.name = b.name
  and e.snap_id = sn.snap_id
  AND b.snap_id = sn.snap_id-1
  and sn.snap_id >=&bid and sn.snap_id <=&eid and sn.instance_number=&inid
  order by snap_time;
Fetch se_cur bulk collect
    into fbwait,wcwait,bbwait, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 fbwait.extend;
 fbwait(1):='0';
 wcwait.extend;
 wcwait(1):='0';
 bbwait.extend;
 bbwait(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Free Buffer Busy Wait",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN fbwait.FIRST .. fbwait.LAST LOOP
    if (i < fbwait.count) then
      DBMS_OUTPUT.PUT_LINE(fbwait(i) || ',');
    elsif (i = fbwait.count) then
      DBMS_OUTPUT.PUT_LINE(fbwait(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Write Complete Wait",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN wcwait.FIRST .. wcwait.LAST LOOP
    if (i < wcwait.count) then
      DBMS_OUTPUT.PUT_LINE(wcwait(i) || ',');
    elsif (i = wcwait.count) then
      DBMS_OUTPUT.PUT_LINE(wcwait(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer BusyWait",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN bbwait.FIRST .. bbwait.LAST LOOP
    if (i < bbwait.count) then
      DBMS_OUTPUT.PUT_LINE(bbwait(i) || ',');
    elsif (i = bbwait.count) then
      DBMS_OUTPUT.PUT_LINE(bbwait(i));
    end if;
   END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Buffer Cache Waits"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Buffer Cache Blocks Waits"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Waits" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Buffer Cache Wait Statistic End----------------------------------
---------------------------------PGA Statistic Total ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  pgatotal     ValueList; 
  pgause       ValueList; 
  pgaos 	ValueList;
  pgafree 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var pgastatistic = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
  WITH 
pgastat_denorm_1 AS (
SELECT snap_id,
       dbid,
       instance_number,
       SUM(CASE name WHEN 'PGA memory freed back to OS'           THEN value ELSE 0 END) pga_mem_freed_to_os,
       SUM(CASE name WHEN 'aggregate PGA auto target'             THEN value ELSE 0 END) aggr_pga_auto_target,
       SUM(CASE name WHEN 'aggregate PGA target parameter'        THEN value ELSE 0 END) aggr_pga_target_param,
       SUM(CASE name WHEN 'bytes processed'                       THEN value ELSE 0 END) bytes_processed,
       SUM(CASE name WHEN 'extra bytes read/written'              THEN value ELSE 0 END) extra_bytes_rw,
       SUM(CASE name WHEN 'global memory bound'                   THEN value ELSE 0 END) global_memory_bound,
       SUM(CASE name WHEN 'maximum PGA allocated'                 THEN value ELSE 0 END) max_pga_allocated,
       SUM(CASE name WHEN 'maximum PGA used for auto workareas'   THEN value ELSE 0 END) max_pga_used_aut_wa,
       SUM(CASE name WHEN 'maximum PGA used for manual workareas' THEN value ELSE 0 END) max_pga_used_man_wa,
       SUM(CASE name WHEN 'total PGA allocated'                   THEN value ELSE 0 END) tot_pga_allocated,
       SUM(CASE name WHEN 'total PGA inuse'                       THEN value ELSE 0 END) tot_pga_inuse,
       SUM(CASE name WHEN 'total PGA used for auto workareas'     THEN value ELSE 0 END) tot_pga_used_aut_wa,
       SUM(CASE name WHEN 'total PGA used for manual workareas'   THEN value ELSE 0 END) tot_pga_used_man_wa,
       SUM(CASE name WHEN 'total freeable PGA memory'             THEN value ELSE 0 END) tot_freeable_pga_mem,
	   SUM(CASE name WHEN 'cache hit percentage'             THEN value ELSE 0 END) cachehit
  FROM dba_hist_pgastat
 WHERE name IN
('PGA memory freed back to OS'
,'aggregate PGA auto target'
,'aggregate PGA target parameter'
,'bytes processed'
,'extra bytes read/written'
,'global memory bound'
,'maximum PGA allocated'
,'maximum PGA used for auto workareas'
,'maximum PGA used for manual workareas'
,'total PGA allocated'
,'total PGA inuse'
,'total PGA used for auto workareas'
,'total PGA used for manual workareas'
,'total freeable PGA memory'
,'cache hit percentage'
)
 GROUP BY
       snap_id,
       dbid,
       instance_number
),
pgastat_denorm_2 AS (
SELECT h.dbid,
       h.instance_number,
       s.startup_time,
       MIN(h.pga_mem_freed_to_os) pga_mem_freed_to_os,
       MIN(h.bytes_processed) bytes_processed,
       MIN(h.extra_bytes_rw) extra_bytes_rw
  FROM pgastat_denorm_1 h,
       dba_hist_snapshot s
 WHERE s.snap_id = h.snap_id
   AND s.dbid = h.dbid
   AND s.instance_number = h.instance_number
 GROUP BY
       h.dbid,
       h.instance_number,
       s.startup_time
),
pgastat_delta AS (
SELECT h1.snap_id,
       h1.dbid,
       h1.instance_number,
       s1.begin_interval_time,
       s1.end_interval_time,
       ROUND((CAST(s1.end_interval_time AS DATE) - CAST(s1.begin_interval_time AS DATE)) * 24 * 60 * 60) interval_secs,
       (h1.pga_mem_freed_to_os - h0.pga_mem_freed_to_os) pga_mem_freed_to_os,
       h1.aggr_pga_auto_target,
       h1.aggr_pga_target_param,
       (h1.bytes_processed - h0.bytes_processed) bytes_processed,
       (h1.extra_bytes_rw - h0.extra_bytes_rw) extra_bytes_rw,
       h1.global_memory_bound,
       h1.max_pga_allocated,
       h1.max_pga_used_aut_wa,
       h1.max_pga_used_man_wa,
       h1.tot_pga_allocated,
       h1.tot_pga_inuse,
       h1.tot_pga_used_aut_wa,
       h1.tot_pga_used_man_wa,
       h1.tot_freeable_pga_mem,   
       h1.cachehit	   
  FROM pgastat_denorm_1 h0,
       pgastat_denorm_1 h1,
       dba_hist_snapshot s0,
       dba_hist_snapshot s1,
       pgastat_denorm_2 min /* to see cumulative use (replace h0 with min on select list above) */
 WHERE h1.snap_id = h0.snap_id + 1
   AND h1.dbid = h0.dbid
   AND h1.instance_number = h0.instance_number
   AND s0.snap_id = h0.snap_id
   AND s0.dbid = h0.dbid
   AND s0.instance_number = h0.instance_number
   AND s1.snap_id = h1.snap_id
   AND s1.dbid = h1.dbid
   AND s1.instance_number = h1.instance_number
   AND s1.snap_id = s0.snap_id + 1
   AND s1.startup_time = s0.startup_time
   AND s1.begin_interval_time > (s0.begin_interval_time + (1 / (24 * 60))) /* filter out snaps apart < 1 min */
   AND min.dbid = s1.dbid
   AND min.instance_number = s1.instance_number
   AND min.startup_time = s1.startup_time
)
SELECT SUM(tot_pga_allocated)/1048576 tot_pga_allocated,
	   SUM(tot_pga_inuse)/1048576 tot_pga_inuse,
	   SUM(aggr_pga_target_param)/1048576 aggr_pga_target_param,
       SUM(tot_freeable_pga_mem)/1048576 tot_freeable_pga_mem,
       '"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  FROM pgastat_delta
  where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 GROUP BY
       snap_id,end_interval_time
order by end_interval_time;
Fetch se_cur bulk collect
    into pgatotal, pgause,pgaos,pgafree, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 pgatotal.extend;
pgatotal(1):='0';
 pgause.extend;
pgause(1):='0';
 pgaos.extend;
 pgaos(1):='0';
 pgafree.extend;
 pgafree(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "PGA_Usage",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN pgause.FIRST .. pgause.LAST LOOP
    if (i < pgause.count) then
      DBMS_OUTPUT.PUT_LINE(pgause(i) || ',');
    elsif (i = pgause.count) then
      DBMS_OUTPUT.PUT_LINE(pgause(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "PGA Freeable",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pgafree.FIRST .. pgafree.LAST LOOP
    if (i < pgafree.count) then
      DBMS_OUTPUT.PUT_LINE(pgafree(i) || ',');
    elsif (i = pgafree.count) then
      DBMS_OUTPUT.PUT_LINE(pgafree(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "PGA Total",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pgatotal.FIRST .. pgatotal.LAST LOOP
    if (i < pgatotal.count) then
      DBMS_OUTPUT.PUT_LINE(pgatotal(i) || ',');
    elsif (i = pgatotal.count) then
      DBMS_OUTPUT.PUT_LINE(pgatotal(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Aggregate PGA target parameter",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pgaos.FIRST .. pgaos.LAST LOOP
    if (i < pgaos.count) then
      DBMS_OUTPUT.PUT_LINE(pgaos(i) || ',');
    elsif (i = pgaos.count) then
      DBMS_OUTPUT.PUT_LINE(pgaos(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - PGA Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "PGA Statistic"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------PGA Statistic End----------------------------------
----------------------------PGA HIT RATIO-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  pgaratio ValueList;
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var pgahitratio = { type: "line", data: { labels: [');     
  OPEN CR_CUR FOR 
select sum(a1.pgaratio),
        (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
             from dba_hist_snapshot f
            where f.snap_id = a1.snap_id
              and f.instance_number = &inid) snap_time
  from (select a.snap_id,
               case
                 when metric_name = 'PGA Cache Hit %' then
                   trunc(a.average) 
                 else
                  0
               end pgaratio
               from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid
           and a.snap_id <= &eid
           and a.instance_number = &inid
         and a.metric_name in
               ('PGA Cache Hit %')) a1
 group by a1.snap_id order by a1.snap_id;
    FETCH CR_CUR     BULK COLLECT    INTO pgaratio,SNAPTIME;
    close CR_CUR;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 pgaratio.extend;
 pgaratio(1):='0';
end if;
-----------------------------------------  
    FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{'); 
dbms_output.put_line('label: "PGA Hit Ratio",'); 
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,'); 
dbms_output.put_line('borderColor: window.awrColors.red2,'); 
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN pgaratio.FIRST .. pgaratio.LAST
LOOP
  if(i<pgaratio.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (pgaratio(i)||',');
end if;
elsif(i=pgaratio.count) then
DBMS_OUTPUT.PUT_LINE (pgaratio(i));
end if;
END LOOP;
dbms_output.put_line('], }] },                    ');
dbms_output.put_line('options: {                  ');
dbms_output.put_line('responsive: true,           ');
dbms_output.put_line('title:{                     ');
dbms_output.put_line('display:true,               ');
dbms_output.put_line('text:"&_dbname&inid - PGA Hit Ratio"');
dbms_output.put_line('},                          ');
dbms_output.put_line('tooltips: {                 ');
dbms_output.put_line('mode: "index",              ');
dbms_output.put_line('intersect: false,           ');
dbms_output.put_line('},                          ');
dbms_output.put_line('hover: {                    ');
dbms_output.put_line('mode: "nearest",            ');
dbms_output.put_line('intersect: true             ');
dbms_output.put_line('},                          ');
dbms_output.put_line('scales: {                   ');
dbms_output.put_line('xAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString: "PGA Hit Ratio"         ');
dbms_output.put_line('}                           ');
dbms_output.put_line('}],                         ');
dbms_output.put_line('yAxes: [{                   ');
dbms_output.put_line('display: true,              ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString:  "Percentage"       ');
dbms_output.put_line('} }] } } };                 ');
end;
/

----------------------------PGA HIT RATIO End-----------------------------
----------------------------INSTANCE SUFFICIENCT RATIO-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  sp ValueList;
  ms ValueList;
  rcm ValueList;
  rd ValueList;
  rc ValueList;
  exwp ValueList;
  lb ValueList;
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var instancesufficient = { type: "line", data: { labels: [');     
  OPEN CR_CUR FOR 
select sum(a1.spratio),sum(a1.msratio),sum(a1.rcmissratio),sum(a1.redoratio),sum(a1.rcratio),sum(a1.ewprratio),sum(a1.lcmratio),
        (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
             from dba_hist_snapshot f
            where f.snap_id = a1.snap_id
              and f.instance_number = &inid) snap_time
  from (select a.snap_id,
               case
                 when metric_name = 'Soft Parse Ratio' then
                   trunc(a.average) 
                 else
                  0
               end spratio,
               case
                 when metric_name = 'Memory Sorts Ratio' then
                   trunc(a.average) 
                 else
                  0
               end msratio,
			                  case
                 when metric_name = 'Row Cache Miss Ratio' then
                   trunc(a.average) 
                 else
                  0
               end rcmissratio,
			                  case
                 when metric_name = 'Redo Allocation Hit Ratio' then
                   trunc(a.average) 
                 else
                  0
               end redoratio,
			                  case
                 when metric_name = 'Row Cache Hit Ratio' then
                   trunc(a.average) 
                 else
                  0
               end rcratio,
			                 case
                 when metric_name = 'Execute Without Parse Ratio' then
                   trunc(a.average) 
                 else
                  0
               end ewprratio,
			                 case
                 when metric_name = 'Library Cache Miss Ratio' then
                   trunc(a.average) 
                 else
                  0
               end lcmratio
          from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid
           and a.snap_id <= &eid
           and a.instance_number = &inid
         and a.metric_name in
               ('Soft Parse Ratio','Memory Sorts Ratio','Row Cache Miss Ratio','User Calls Ratio','Redo Allocation Hit Ratio','Row Cache Hit Ratio','Execute Without Parse Ratio','Library Cache Miss Ratio'
                )) a1
 group by a1.snap_id order by a1.snap_id;
    FETCH CR_CUR     BULK COLLECT    INTO sp,ms,rcm,rd,rc,exwp,lb,SNAPTIME;
    close CR_CUR;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 sp.extend;
 sp(1):='0';
 ms.extend;
 ms(1):='0';
 rcm.extend;
 rcm(1):='0';
 rd.extend;
 rd(1):='0';
  rc.extend;
 rc(1):='0';
 exwp.extend;
 exwp(1):='0';
 lb.extend;
 lb(1):='0';
end if;
-----------------------------------------  
    FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{'); 
dbms_output.put_line('label: "SoftParse Ratio",'); 
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,'); 
dbms_output.put_line('borderColor: window.awrColors.red1,'); 
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN sp.FIRST .. sp.LAST
LOOP
  if(i<sp.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (sp(i)||',');
end if;
elsif(i=sp.count) then
DBMS_OUTPUT.PUT_LINE (sp(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Memory Sort Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.blue1,');
dbms_output.put_line('borderColor: window.awrColors.blue1,');
dbms_output.put_line('data: [');
 FOR i IN ms.FIRST .. ms.LAST
LOOP
  if(i<ms.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (ms(i)||',');
end if;
elsif(i=ms.count) then
DBMS_OUTPUT.PUT_LINE (ms(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Row Cache Miss Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.purple1,');
dbms_output.put_line('borderColor: window.awrColors.purple1,');
dbms_output.put_line('data: [');
 FOR i IN rcm.FIRST .. rcm.LAST
LOOP
  if(i<rcm.count) then
   if i=1 then
    null;
  else
dbms_OUTPUT.PUT_LINE (rcm(i)||',');
end if;
elsif(i=rcm.count) then
DBMS_OUTPUT.PUT_LINE (rcm(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Redo Allocation Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.orange1,');
dbms_output.put_line('borderColor: window.awrColors.orange1,');
dbms_output.put_line('data: [');
 FOR i IN rd.FIRST .. rd.LAST
LOOP
  if(i<rd.count) then
   if i=1 then
    null;
  else
dbms_OUTPUT.PUT_LINE (rd(i)||',');
end if;
elsif(i=rd.count) then
DBMS_OUTPUT.PUT_LINE (rd(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Row Cache Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.purple2,');
dbms_output.put_line('borderColor: window.awrColors.purple2,');
dbms_output.put_line('data: [');
 FOR i IN rc.FIRST .. rc.LAST
LOOP
  if(i<rc.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (rc(i)||',');
end if;
elsif(i=rc.count) then
DBMS_OUTPUT.PUT_LINE (rc(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Execute Without Parse Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.yellow2,');
dbms_output.put_line('borderColor: window.awrColors.yellow2,');
dbms_output.put_line('data: [');
 FOR i IN exwp.FIRST .. exwp.LAST
LOOP
  if(i<exwp.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (exwp(i)||',');
end if;
elsif(i=exwp.count) then
DBMS_OUTPUT.PUT_LINE (exwp(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Library Cache Miss Ratio",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.blue2,');
dbms_output.put_line('borderColor: window.awrColors.blue2,');
dbms_output.put_line('data: [');
 FOR i IN lb.FIRST .. lb.LAST
LOOP
  if(i<lb.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (lb(i)||',');
end if;
elsif(i=lb.count) then
DBMS_OUTPUT.PUT_LINE (lb(i));
end if;
END LOOP;
dbms_output.put_line('], }] },                    ');
dbms_output.put_line('options: {                  ');
dbms_output.put_line('responsive: true,           ');
dbms_output.put_line('title:{                     ');
dbms_output.put_line('display:true,               ');
dbms_output.put_line('text:"&_dbname&inid - Instance Sufficient Ratio"');
dbms_output.put_line('},                          ');
dbms_output.put_line('tooltips: {                 ');
dbms_output.put_line('mode: "index",              ');
dbms_output.put_line('intersect: false,           ');
dbms_output.put_line('},                          ');
dbms_output.put_line('hover: {                    ');
dbms_output.put_line('mode: "nearest",            ');
dbms_output.put_line('intersect: true             ');
dbms_output.put_line('},                          ');
dbms_output.put_line('scales: {                   ');
dbms_output.put_line('xAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString: "Instance Sufficient Ratio"         ');
dbms_output.put_line('}                           ');
dbms_output.put_line('}],                         ');
dbms_output.put_line('yAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString:  "Percentage"       ');
dbms_output.put_line('} }] } } };                 ');
end;
/
----------------------------INSTANCE SUFFICIENCT END-----------------------------
---------------------------------Transaction and DB Calls ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  ucom     ValueList; 
  tnxroll       ValueList; 
  uroll 	ValueList;
  execcnt 	ValueList;
  ucall 	ValueList;
  recurcall 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var dbcalls = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(ucom/s_et,2) ucom
	 , round(tnxroll/s_et,2) tnxroll
	 , round(uroll/s_et,2) uroll
	 , round(execcnt/s_et,2) execcnt
	 , round(ucall/s_et,2) ucall
	 , round(recurcall/s_et,2) recurcall,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           and s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ('user commits','transaction rollbacks','user rollbacks','recursive calls','user calls','execute count'))
         pivot (sum(value) for stat_name in (
'user commits' ucom,
'transaction rollbacks' tnxroll,
'user rollbacks' uroll,
'recursive calls' recurcall,
'user calls' ucall,
'execute count' execcnt
))) order by snap_time;
Fetch se_cur bulk collect
    into ucom, tnxroll,uroll,execcnt,ucall,recurcall, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ucom.extend;
ucom(1):='0';
 uroll.extend;
uroll(1):='0';
 execcnt.extend;
 execcnt(1):='0';
 tnxroll.extend;
 tnxroll(1):='0';
  ucall.extend;
 ucall(1):='0';
 recurcall.extend;
 recurcall(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "User RollBack",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN uroll.FIRST .. uroll.LAST LOOP
    if (i < uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i) || ',');
    elsif (i = uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Execution Count",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execcnt.FIRST .. execcnt.LAST LOOP
    if (i < execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i) || ',');
    elsif (i = execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Transaction Rollback",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN tnxroll.FIRST .. tnxroll.LAST LOOP
    if (i < tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i) || ',');
    elsif (i = tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "User Commit",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ucom.FIRST .. ucom.LAST LOOP
    if (i < ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i) || ',');
    elsif (i = ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "User Calls",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ucall.FIRST .. ucall.LAST LOOP
    if (i < ucall.count) then
      DBMS_OUTPUT.PUT_LINE(ucall(i) || ',');
    elsif (i = ucall.count) then
      DBMS_OUTPUT.PUT_LINE(ucall(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Recursive Calls",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN recurcall.FIRST .. recurcall.LAST LOOP
    if (i < recurcall.count) then
      DBMS_OUTPUT.PUT_LINE(recurcall(i) || ',');
    elsif (i = recurcall.count) then
      DBMS_OUTPUT.PUT_LINE(recurcall(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Transaction And DB Calls"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Transaction And DB Calls"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Value" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Transaction and DB Calls ----------------------------------
---------------------------------IOPS Request Total ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  total_iops     ValueList; 
  iops_read       ValueList; 
  iops_write 	ValueList;
  iops_redo 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iopsbreak = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,  STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME IN ('physical read total IO requests','physical write total IO requests', 'redo writes',
    'physical read total bytes', 'physical write total bytes','redo size', 'physical reads','physical writes','physical read total bytes optimized')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
    TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
    EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
    EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
    EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid)
    WHERE end_snap_time1 IS NOT NULL
 ),
 z AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, y.end_snap_time, x.instance_number,
    SUM(DECODE(x.stat_name, 'physical read total IO requests',  ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read,
    SUM(DECODE(x.stat_name, 'physical write total IO requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_write,
    SUM(DECODE(x.stat_name, 'redo writes',                      ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_read,
    SUM(DECODE(x.stat_name, 'physical write total bytes',ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_write,
    SUM(DECODE(x.stat_name, 'redo size',                 ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes optimized', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_prtbo,
    SUM(DECODE(x.stat_name, 'physical reads',            ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_reads_per_second,
    SUM(DECODE(x.stat_name, 'physical writes',           ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_writes_per_second
    FROM x JOIN y ON (x.dbid=y.dbid AND x.instance_number=y.instance_number AND x.end_snap_id=y.snap_id)
    WHERE x.begin_snap_id IS NOT NULL
    GROUP BY x.begin_snap_id, x.end_snap_id, y.end_snap_time, x.instance_number
 ),
 k AS (
 SELECT IOPS_read+IOPS_write+IOPS_redo IOPS, IOPS_read, IOPS_write, IOPS_redo, '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM z)
 select * from k order by snap_time;
Fetch se_cur bulk collect
    into total_iops, iops_read, iops_write, iops_redo, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 total_iops.extend;
 total_iops(1):='0';
 iops_read.extend;
 iops_read(1):='0';
 iops_write.extend;
 iops_write(1):='0';
 iops_redo.extend;
 iops_redo(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "IOPS_Total",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN total_iops.FIRST .. total_iops.LAST LOOP
    if (i < total_iops.count) then
      DBMS_OUTPUT.PUT_LINE(total_iops(i) || ',');
    elsif (i = total_iops.count) then
      DBMS_OUTPUT.PUT_LINE(total_iops(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - IOPS Request Total"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "IOPS Request Total"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "IOPS" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------IOPS Request Total End----------------------------------
---------------------------------IOPS Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  total_iops     ValueList; 
  iops_read       ValueList; 
  iops_write 	ValueList;
  iops_redo 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iops = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,  STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME IN ('physical read total IO requests','physical write total IO requests', 'redo writes',
    'physical read total bytes', 'physical write total bytes','redo size', 'physical reads','physical writes','physical read total bytes optimized')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
    TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
    EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
    EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
    EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid)
    WHERE end_snap_time1 IS NOT NULL
 ),
 z AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, y.end_snap_time, x.instance_number,
    SUM(DECODE(x.stat_name, 'physical read total IO requests',  ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read,
    SUM(DECODE(x.stat_name, 'physical write total IO requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_write,
    SUM(DECODE(x.stat_name, 'redo writes',                      ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_read,
    SUM(DECODE(x.stat_name, 'physical write total bytes',ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_write,
    SUM(DECODE(x.stat_name, 'redo size',                 ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes optimized', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_prtbo,
    SUM(DECODE(x.stat_name, 'physical reads',            ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_reads_per_second,
    SUM(DECODE(x.stat_name, 'physical writes',           ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_writes_per_second
    FROM x JOIN y ON (x.dbid=y.dbid AND x.instance_number=y.instance_number AND x.end_snap_id=y.snap_id)
    WHERE x.begin_snap_id IS NOT NULL
    GROUP BY x.begin_snap_id, x.end_snap_id, y.end_snap_time, x.instance_number
 ),
 k AS (
 SELECT IOPS_read+IOPS_write+IOPS_redo IOPS, IOPS_read, IOPS_write, IOPS_redo, '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM z)
 select * from k order by snap_time;
Fetch se_cur bulk collect
    into total_iops, iops_read, iops_write, iops_redo, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 total_iops.extend;
 total_iops(1):='0';
 iops_read.extend;
 iops_read(1):='0';
 iops_write.extend;
 iops_write(1):='0';
 iops_redo.extend;
 iops_redo(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "IOPS_Redo",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN iops_redo.FIRST .. iops_redo.LAST LOOP
    if (i < iops_redo.count) then
      DBMS_OUTPUT.PUT_LINE(iops_redo(i) || ',');
    elsif (i = iops_redo.count) then
      DBMS_OUTPUT.PUT_LINE(iops_redo(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "IOPS_Write",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN iops_write.FIRST .. iops_write.LAST LOOP
    if (i < iops_write.count) then
      DBMS_OUTPUT.PUT_LINE(iops_write(i) || ',');
    elsif (i = iops_write.count) then
      DBMS_OUTPUT.PUT_LINE(iops_write(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "IOPS_Read",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN iops_read.FIRST .. iops_read.LAST LOOP
    if (i < iops_read.count) then
      DBMS_OUTPUT.PUT_LINE(iops_read(i) || ',');
    elsif (i = iops_read.count) then
      DBMS_OUTPUT.PUT_LINE(iops_read(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - IOPS Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Time"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "IOPS" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------IOPS Statistic End----------------------------------
---------------------------------IO Throughtput Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  total_iops     ValueList; 
  iops_read       ValueList; 
  iops_write 	ValueList;
  iops_redo 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iothrougputtotal = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,  STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME IN ('physical read total IO requests','physical write total IO requests', 'redo writes',
    'physical read total bytes', 'physical write total bytes','redo size', 'physical reads','physical writes','physical read total bytes optimized')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
    TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
    EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
    EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
    EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid)
    WHERE end_snap_time1 IS NOT NULL
 ),
 z AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, y.end_snap_time, x.instance_number,
    SUM(DECODE(x.stat_name, 'physical read total IO requests',  ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read,
    SUM(DECODE(x.stat_name, 'physical write total IO requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_write,
    SUM(DECODE(x.stat_name, 'redo writes',                      ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_read,
    SUM(DECODE(x.stat_name, 'physical write total bytes',ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_write,
    SUM(DECODE(x.stat_name, 'redo size',                 ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes optimized', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_prtbo,
    SUM(DECODE(x.stat_name, 'physical reads',            ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_reads_per_second,
    SUM(DECODE(x.stat_name, 'physical writes',           ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_writes_per_second
    FROM x JOIN y ON (x.dbid=y.dbid AND x.instance_number=y.instance_number AND x.end_snap_id=y.snap_id)
    WHERE x.begin_snap_id IS NOT NULL
    GROUP BY x.begin_snap_id, x.end_snap_id, y.end_snap_time, x.instance_number
 ),
 k AS (
 SELECT MBPS_read+MBPS_write+MBPS_redo MBPS,MBPS_read, MBPS_write, MBPS_redo, '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM z)
 select * from k order by snap_time;
Fetch se_cur bulk collect
    into total_iops,iops_read, iops_write, iops_redo, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 total_iops.extend;
 total_iops(1):=0;
 iops_read.extend;
 iops_read(1):='0';
 iops_write.extend;
 iops_write(1):='0';
 iops_redo.extend;
 iops_redo(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Total_Mb /Second",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN total_iops.FIRST .. total_iops.LAST LOOP
    if (i < total_iops.count) then
      DBMS_OUTPUT.PUT_LINE(total_iops(i) || ',');
    elsif (i = total_iops.count) then
      DBMS_OUTPUT.PUT_LINE(total_iops(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - IO Throughtput Total"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "IO Throughtput"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb/s" ');
dbms_output.put_line('} }] } } };           ');
END;
/

declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  total_iops     ValueList; 
  iops_read       ValueList; 
  iops_write 	ValueList;
  iops_redo 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iothrougput = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   WITH x AS (
    SELECT DBID, INSTANCE_NUMBER,  STAT_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(VALUE, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, STAT_NAME ORDER BY SNAP_ID) begin_value, VALUE end_value
    FROM DBA_HIST_SYSSTAT
    WHERE STAT_NAME IN ('physical read total IO requests','physical write total IO requests', 'redo writes',
    'physical read total bytes', 'physical write total bytes','redo size', 'physical reads','physical writes','physical read total bytes optimized')
    AND snap_id >=&bid and snap_id <=&eid and instance_number=&inid
 ),
 y AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
    TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
    EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
    EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
    EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT
       WHERE snap_id >=&bid and snap_id <=&eid and instance_number=&inid)
    WHERE end_snap_time1 IS NOT NULL
 ),
 z AS (
    SELECT x.begin_snap_id, x.end_snap_id snap_id, y.end_snap_time, x.instance_number,
    SUM(DECODE(x.stat_name, 'physical read total IO requests',  ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_read,
    SUM(DECODE(x.stat_name, 'physical write total IO requests', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_write,
    SUM(DECODE(x.stat_name, 'redo writes',                      ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) IOPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_read,
    SUM(DECODE(x.stat_name, 'physical write total bytes',ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_write,
    SUM(DECODE(x.stat_name, 'redo size',                 ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_redo,
    SUM(DECODE(x.stat_name, 'physical read total bytes optimized', ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/1024/1024/y.duration,2), 0)) MBPS_prtbo,
    SUM(DECODE(x.stat_name, 'physical reads',            ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_reads_per_second,
    SUM(DECODE(x.stat_name, 'physical writes',           ROUND((NVL(x.end_value,0)-NVL(x.begin_value,0))/y.duration,2), 0)) physical_writes_per_second
    FROM x JOIN y ON (x.dbid=y.dbid AND x.instance_number=y.instance_number AND x.end_snap_id=y.snap_id)
    WHERE x.begin_snap_id IS NOT NULL
    GROUP BY x.begin_snap_id, x.end_snap_id, y.end_snap_time, x.instance_number
 ),
 k AS (
 SELECT MBPS_read+MBPS_write+MBPS_redo MBPS,MBPS_read, MBPS_write, MBPS_redo, '"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
 FROM z)
 select * from k order by snap_time;
Fetch se_cur bulk collect
    into total_iops,iops_read, iops_write, iops_redo, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 total_iops.extend;
 total_iops(1):=0;
 iops_read.extend;
 iops_read(1):='0';
 iops_write.extend;
 iops_write(1):='0';
 iops_redo.extend;
 iops_redo(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Mb_Redo",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN iops_redo.FIRST .. iops_redo.LAST LOOP
    if (i < iops_redo.count) then
      DBMS_OUTPUT.PUT_LINE(iops_redo(i) || ',');
    elsif (i = iops_redo.count) then
      DBMS_OUTPUT.PUT_LINE(iops_redo(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Mb_Write",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN iops_write.FIRST .. iops_write.LAST LOOP
    if (i < iops_write.count) then
      DBMS_OUTPUT.PUT_LINE(iops_write(i) || ',');
    elsif (i = iops_write.count) then
      DBMS_OUTPUT.PUT_LINE(iops_write(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Mb_Read",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN iops_read.FIRST .. iops_read.LAST LOOP
    if (i < iops_read.count) then
      DBMS_OUTPUT.PUT_LINE(iops_read(i) || ',');
    elsif (i = iops_read.count) then
      DBMS_OUTPUT.PUT_LINE(iops_read(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - IO Throughtput Breakdown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "IO Throughtput"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb/s" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------IO ThroughtPut Statistic End----------------------------------
-------------------------------Physical Read/Write Blocks-------------------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  PR       ValueList; ---Physical Reads bytes
  PW       ValueList; ---physical write bytes
  SNAPTIME ValueList;
  pw_cur sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var phyio = { type: "line", data: { labels: [');
  open pw_cur for
 select  pw,pr,snap_time from 
(select trunc(  ( a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id))/&_iv ) pw,   
      trunc( ( a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id))/&_iv ) pr,
            (select '"' || to_char(f.begin_interval_time, 'mm-dd hh24:mi') || '"'
                 from dba_hist_snapshot f
                where f.snap_id = a2.snap_id
                  and f.instance_number = &inid) snap_time
      from (select a1.instance_number,a1.snap_id,
                   sum(case
                         when a1.stat_name = 'physical reads' then
                          a1.value
                         else
                          0
                       end) pr,
                   sum(case
                         when a1.stat_name = 'physical writes' then
                          a1.value
                         else
                          0
                       end) pw
              from (select a.snap_id, a.stat_name, a.value,a.instance_number 
                      from dba_hist_sysstat a
                     where  a.stat_name in ('physical reads','physical writes')
                       and snap_id >= &bid
                       and snap_id < &eid
                       and a.instance_number = &inid
                     order by a.snap_id, a.stat_name,a.instance_number) a1
             group by a1.snap_id,a1.instance_number
             order by a1.snap_id) a2) order by snap_time;
  fetch pw_cur bulk collect into pw, pr, snaptime;
  close pw_cur;
 ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 pr.extend;
 pr(1):='0';
 pw.extend;
 pw(1):=0;
  end if;
-----------------------------------------
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ],  datasets: [{');
  DBMS_OUTPUT.PUT_LINE(' label: "Physical reads",');
  DBMS_OUTPUT.PUT_LINE(' fill: false,');
  DBMS_OUTPUT.PUT_LINE(' backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE(' borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE(' data: [');
  FOR i IN pr.FIRST .. pr.LAST LOOP
    if (i < pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i) || ',');
    elsif (i = pr.count) then
      DBMS_OUTPUT.PUT_LINE(pr(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Physcial writes",');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pw.FIRST .. pw.LAST LOOP
    if (i < pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i) || ',');
    elsif (i = pw.count) then
      DBMS_OUTPUT.PUT_LINE(pw(i));
    end if;
  END LOOP;
DBMS_OUTPUT.PUT_LINE('     ], }]},');
DBMS_OUTPUT.PUT_LINE('options: {');
DBMS_OUTPUT.PUT_LINE('    responsive: true,');
DBMS_OUTPUT.PUT_LINE('    title:{');
DBMS_OUTPUT.PUT_LINE('        display:true,');
DBMS_OUTPUT.PUT_LINE('        text:"&_dbname&inid - Physical R/W per Second"');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    tooltips: {');
DBMS_OUTPUT.PUT_LINE('        mode: "index",');
DBMS_OUTPUT.PUT_LINE('        intersect: false,');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    hover: {');
DBMS_OUTPUT.PUT_LINE('        mode: "nearest",');
DBMS_OUTPUT.PUT_LINE('        intersect: true');
DBMS_OUTPUT.PUT_LINE('    },');
DBMS_OUTPUT.PUT_LINE('    scales: {');
DBMS_OUTPUT.PUT_LINE(' xAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Snap"');
DBMS_OUTPUT.PUT_LINE('     }');
DBMS_OUTPUT.PUT_LINE(' }],');
DBMS_OUTPUT.PUT_LINE(' yAxes: [{');
DBMS_OUTPUT.PUT_LINE('     display: true,');
DBMS_OUTPUT.PUT_LINE('     scaleLabel: {');
DBMS_OUTPUT.PUT_LINE('         display: true,');
DBMS_OUTPUT.PUT_LINE('         labelString: "Blocks"');
DBMS_OUTPUT.PUT_LINE('     } }] } } };');
END;
/
-------------------------------Physical Read/Write Blocks End-------------------------------------------
---------------------------------Physical Read BreakDown ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var phyreadbk = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(phyread/s_et,2) phyread
     , round(phyreadcach/s_et,2) phyreadcach
     ,round(phyreaddir/s_et,2) phyreaddir,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'physical reads','physical reads cache','physical reads direct', 'physical writes','physical writes from cache','physical writes direct'))
         pivot (sum(value) for stat_name in (
'physical reads' phyread,                  
'physical reads cache'  phyreadcach,         
'physical reads direct' phyreaddir,           
'physical writes' phywrt,           
'physical writes from cache'  phywrtcach,    
'physical writes direct' phywrtdir
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Reads Direct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Reads Cache",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Physical Reads BreakDown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Physical Reads BreakDown"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Blocks/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Physical Read BreakDown ----------------------------------
---------------------------------Physical Write BreakDown ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var phywrite = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(phywrt/s_et,2) phywrt
     , round(phywrtcach/s_et,2) phywrtcach
     ,round(phywrtdir/s_et,2) phywrtdir,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'physical reads','physical reads cache','physical reads direct', 'physical writes','physical writes from cache','physical writes direct'))
         pivot (sum(value) for stat_name in (
'physical reads' phyread,                  
'physical reads cache'  phyreadcach,         
'physical reads direct' phyreaddir,           
'physical writes' phywrt,           
'physical writes from cache'  phywrtcach,    
'physical writes direct' phywrtdir
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Write Direct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Write Cache",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Physical Writes",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Physical Writes BreakDown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Physical Writes BreakDown"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Blocks/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Physical Write BreakDown ----------------------------------
---------------------------------I/O Function By Throughput----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  bfc     ValueList; 
  dr    ValueList;
  dw      ValueList;
  dbw       ValueList;
  lgw       ValueList;
  rman       ValueList;
  sc       ValueList;
  saq       ValueList;
  oth       ValueList;
  xdb       ValueList;
  dp       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iofthpt = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(SMALL_READ_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_read_reqs, SMALL_READ_REQS end_s_read_reqs,
    LAG(LARGE_READ_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_read_reqs, LARGE_READ_REQS end_l_read_reqs,
    LAG(SMALL_WRITE_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_write_reqs, SMALL_WRITE_REQS end_s_write_reqs,
    LAG(LARGE_WRITE_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_write_reqs, LARGE_WRITE_REQS end_l_write_reqs,
    LAG(SMALL_READ_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_read_MB, SMALL_READ_MEGABYTES end_s_read_MB,
    LAG(LARGE_READ_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_read_MB, LARGE_READ_MEGABYTES end_l_read_MB,
    LAG(SMALL_WRITE_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_write_MB, SMALL_WRITE_MEGABYTES end_s_write_MB,
    LAG(LARGE_WRITE_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_write_MB, LARGE_WRITE_MEGABYTES end_l_write_MB,
    LAG(NUMBER_OF_WAITS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_waits, NUMBER_OF_WAITS end_waits,
    LAG(WAIT_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_wait_time, WAIT_TIME end_wait_time
    FROM DBA_HIST_IOSTAT_DETAIL
 ),
 y AS (
    SELECT dbid, instance_number, function_name, filetype_name, begin_snap_id, end_snap_id,
    (NVL(end_s_read_reqs,0) -NVL(begin_s_read_reqs,0)  + NVL(end_l_read_reqs,0) -NVL(begin_l_read_reqs,0)) read_reqs,
    (NVL(end_s_write_reqs,0)-NVL(begin_s_write_reqs,0) + NVL(end_l_write_reqs,0)-NVL(begin_l_write_reqs,0)) write_reqs,
    (NVL(end_s_read_MB,0) -NVL(begin_s_read_MB,0)  + NVL(end_l_read_MB,0) -NVL(begin_l_read_MB,0)) read_MB,
    (NVL(end_s_write_MB,0)-NVL(begin_s_write_MB,0) + NVL(end_l_write_MB,0)-NVL(begin_l_write_MB,0)) write_MB,
    (NVL(end_waits,0)-NVL(begin_waits,0)) waits,
    (NVL(end_wait_time,0)-NVL(begin_wait_time,0)) wait_time
    FROM x
    WHERE begin_snap_id IS NOT NULL
 ),
 z AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
       TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
       EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
       EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
       EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT)
    WHERE end_snap_time1 IS NOT NULL
 ),
 k AS (
 SELECT y.instance_number,y.end_snap_id snap_id,z.end_snap_time,
 y.function_name, ROUND((y.read_MB+y.write_MB)/z.duration, 2) mbps
  FROM y JOIN z ON (y.dbid=z.dbid AND y.instance_number=z.instance_number AND y.end_snap_id=z.snap_id)
)
select sum(case when function_name='Buffer Cache Reads' then  mbps else 0 end  )  bfc,
sum(case when function_name='Direct Reads' then  mbps else 0 end  )  dr,
sum(case when function_name='Direct Writes' then  mbps else 0 end  )  dw,
sum(case when function_name='DBWR' then  mbps else 0 end  )  dbw,
sum(case when function_name='LGWR' then  mbps else 0 end  )  lgw,
sum(case when function_name='RMAN' then  mbps else 0 end  )  rman,
sum(case when function_name='Smart Scan' then  mbps else 0 end  )  sc,
sum(case when function_name='Streams AQ' then  mbps else 0 end  )  saq,
sum(case when function_name='Others' then  mbps else 0 end  )  oth,
sum(case when function_name='XDB' then  mbps else 0 end  )  xdb,
sum(case when function_name='Data Pump' then  mbps else 0 end  )  dp,
'"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
from k 
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
group by end_snap_time,snap_id
order by end_snap_time;
  Fetch se_cur bulk collect
    into bfc,dr,dw,dbw,lgw,rman,sc,saq,oth,xdb,dp,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 bfc.extend;
 bfc(1):='0';
 dr.extend;
 dr(1):='0';
 dw.extend;
 dw(1):='0';
 dbw.extend;
 dbw(1):='0';
 lgw.extend;
 lgw(1):='0';
 rman.extend;
 rman(1):='0';
  sc.extend;
 sc(1):='0';
  saq.extend;
 saq(1):='0';
  oth.extend;
 oth(1):='0';
  xdb.extend;
 xdb(1):='0';
  dp.extend;
 dp(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer Cache Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN bfc.FIRST .. bfc.LAST LOOP
    if (i < bfc.count) then
      DBMS_OUTPUT.PUT_LINE(bfc(i) || ',');
    elsif (i = bfc.count) then
      DBMS_OUTPUT.PUT_LINE(bfc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Direct Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dr.FIRST .. dr.LAST LOOP
    if (i < dr.count) then
      DBMS_OUTPUT.PUT_LINE(dr(i) || ',');
    elsif (i = dr.count) then
      DBMS_OUTPUT.PUT_LINE(dr(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Direct Writes",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dw.FIRST .. dw.LAST LOOP
    if (i < dw.count) then
      DBMS_OUTPUT.PUT_LINE(dw(i) || ',');
    elsif (i = dw.count) then
      DBMS_OUTPUT.PUT_LINE(dw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DBWR",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dbw.FIRST .. dbw.LAST LOOP
    if (i < dbw.count) then
      DBMS_OUTPUT.PUT_LINE(dbw(i) || ',');
    elsif (i = dbw.count) then
      DBMS_OUTPUT.PUT_LINE(dbw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "LGWR",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN lgw.FIRST .. lgw.LAST LOOP
    if (i < lgw.count) then
      DBMS_OUTPUT.PUT_LINE(lgw(i) || ',');
    elsif (i = lgw.count) then
      DBMS_OUTPUT.PUT_LINE(lgw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "RMAN",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rman.FIRST .. rman.LAST LOOP
    if (i < rman.count) then
      DBMS_OUTPUT.PUT_LINE(rman(i) || ',');
    elsif (i = rman.count) then
      DBMS_OUTPUT.PUT_LINE(rman(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Smart Scan",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sc.FIRST .. sc.LAST LOOP
    if (i < sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i) || ',');
    elsif (i = sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Streams AQ",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN saq.FIRST .. saq.LAST LOOP
    if (i < saq.count) then
      DBMS_OUTPUT.PUT_LINE(saq(i) || ',');
    elsif (i = saq.count) then
      DBMS_OUTPUT.PUT_LINE(saq(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "XDB",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN xdb.FIRST .. xdb.LAST LOOP
    if (i < xdb.count) then
      DBMS_OUTPUT.PUT_LINE(xdb(i) || ',');
    elsif (i = xdb.count) then
      DBMS_OUTPUT.PUT_LINE(xdb(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data Pump",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dp.FIRST .. dp.LAST LOOP
    if (i < dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i) || ',');
    elsif (i = dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - I/O Function By Throughput"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "I/O Function By Throughput"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb/s" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------I/O Function By Throughput----------------------------------
---------------------------------I/O Function By IOPS----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  bfc     ValueList; 
  dr    ValueList;
  dw      ValueList;
  dbw       ValueList;
  lgw       ValueList;
  rman       ValueList;
  sc       ValueList;
  saq       ValueList;
  oth       ValueList;
  xdb       ValueList;
  dp       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var iofiops = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
WITH x AS (
    SELECT DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME,
    LAG(SNAP_ID, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_snap_id, SNAP_ID end_snap_id,
    LAG(SMALL_READ_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_read_reqs, SMALL_READ_REQS end_s_read_reqs,
    LAG(LARGE_READ_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_read_reqs, LARGE_READ_REQS end_l_read_reqs,
    LAG(SMALL_WRITE_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_write_reqs, SMALL_WRITE_REQS end_s_write_reqs,
    LAG(LARGE_WRITE_REQS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_write_reqs, LARGE_WRITE_REQS end_l_write_reqs,
    LAG(SMALL_READ_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_read_MB, SMALL_READ_MEGABYTES end_s_read_MB,
    LAG(LARGE_READ_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_read_MB, LARGE_READ_MEGABYTES end_l_read_MB,
    LAG(SMALL_WRITE_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_s_write_MB, SMALL_WRITE_MEGABYTES end_s_write_MB,
    LAG(LARGE_WRITE_MEGABYTES, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_l_write_MB, LARGE_WRITE_MEGABYTES end_l_write_MB,
    LAG(NUMBER_OF_WAITS, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_waits, NUMBER_OF_WAITS end_waits,
    LAG(WAIT_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER, FUNCTION_NAME, FILETYPE_NAME ORDER BY SNAP_ID) begin_wait_time, WAIT_TIME end_wait_time
    FROM DBA_HIST_IOSTAT_DETAIL
 ),
 y AS (
    SELECT dbid, instance_number, function_name, filetype_name, begin_snap_id, end_snap_id,
    (NVL(end_s_read_reqs,0) -NVL(begin_s_read_reqs,0)  + NVL(end_l_read_reqs,0) -NVL(begin_l_read_reqs,0)) read_reqs,
    (NVL(end_s_write_reqs,0)-NVL(begin_s_write_reqs,0) + NVL(end_l_write_reqs,0)-NVL(begin_l_write_reqs,0)) write_reqs,
    (NVL(end_s_read_MB,0) -NVL(begin_s_read_MB,0)  + NVL(end_l_read_MB,0) -NVL(begin_l_read_MB,0)) read_MB,
    (NVL(end_s_write_MB,0)-NVL(begin_s_write_MB,0) + NVL(end_l_write_MB,0)-NVL(begin_l_write_MB,0)) write_MB,
    (NVL(end_waits,0)-NVL(begin_waits,0)) waits,
    (NVL(end_wait_time,0)-NVL(begin_wait_time,0)) wait_time
    FROM x
    WHERE begin_snap_id IS NOT NULL
 ),
 z AS (
    SELECT dbid, instance_number, snap_id, end_snap_time2 end_snap_time,
       TRUNC(EXTRACT(DAY from end_snap_time2-end_snap_time1)*24*60*60 +
       EXTRACT(HOUR from   end_snap_time2-end_snap_time1)*60*60 +
       EXTRACT(MINUTE from end_snap_time2-end_snap_time1)*60 +
       EXTRACT(SECOND from end_snap_time2-end_snap_time1)) duration
    FROM (
       SELECT DBID, INSTANCE_NUMBER, SNAP_ID,
       LAG(END_INTERVAL_TIME, 1) OVER (PARTITION BY DBID, INSTANCE_NUMBER ORDER BY SNAP_ID) end_snap_time1, END_INTERVAL_TIME end_snap_time2
       FROM DBA_HIST_SNAPSHOT)
    WHERE end_snap_time1 IS NOT NULL
 ),
 k AS (
 SELECT y.instance_number,y.end_snap_id snap_id,z.end_snap_time,
 y.function_name, ROUND((y.read_reqs+y.write_reqs)/z.duration, 2) iops
  FROM y JOIN z ON (y.dbid=z.dbid AND y.instance_number=z.instance_number AND y.end_snap_id=z.snap_id)
)
select sum(case when function_name='Buffer Cache Reads' then  iops else 0 end  )  bfc,
sum(case when function_name='Direct Reads' then  iops else 0 end  )  dr,
sum(case when function_name='Direct Writes' then  iops else 0 end  )  dw,
sum(case when function_name='DBWR' then  iops else 0 end  )  dbw,
sum(case when function_name='LGWR' then  iops else 0 end  )  lgw,
sum(case when function_name='RMAN' then  iops else 0 end  )  rman,
sum(case when function_name='Smart Scan' then  iops else 0 end  )  sc,
sum(case when function_name='Streams AQ' then  iops else 0 end  )  saq,
sum(case when function_name='Others' then  iops else 0 end  )  oth,
sum(case when function_name='XDB' then  iops else 0 end  )  xdb,
sum(case when function_name='Data Pump' then  iops else 0 end  )  dp,
'"'||to_char(end_snap_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
from k 
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
group by end_snap_time,snap_id
order by end_snap_time;
  Fetch se_cur bulk collect
    into bfc,dr,dw,dbw,lgw,rman,sc,saq,oth,xdb,dp,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 bfc.extend;
 bfc(1):='0';
 dr.extend;
 dr(1):='0';
 dw.extend;
 dw(1):='0';
 dbw.extend;
 dbw(1):='0';
 lgw.extend;
 lgw(1):='0';
 rman.extend;
 rman(1):='0';
  sc.extend;
 sc(1):='0';
  saq.extend;
 saq(1):='0';
  oth.extend;
 oth(1):='0';
  xdb.extend;
 xdb(1):='0';
  dp.extend;
 dp(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer Cache Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN bfc.FIRST .. bfc.LAST LOOP
    if (i < bfc.count) then
      DBMS_OUTPUT.PUT_LINE(bfc(i) || ',');
    elsif (i = bfc.count) then
      DBMS_OUTPUT.PUT_LINE(bfc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Direct Reads",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dr.FIRST .. dr.LAST LOOP
    if (i < dr.count) then
      DBMS_OUTPUT.PUT_LINE(dr(i) || ',');
    elsif (i = dr.count) then
      DBMS_OUTPUT.PUT_LINE(dr(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Direct Writes",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dw.FIRST .. dw.LAST LOOP
    if (i < dw.count) then
      DBMS_OUTPUT.PUT_LINE(dw(i) || ',');
    elsif (i = dw.count) then
      DBMS_OUTPUT.PUT_LINE(dw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DBWR",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dbw.FIRST .. dbw.LAST LOOP
    if (i < dbw.count) then
      DBMS_OUTPUT.PUT_LINE(dbw(i) || ',');
    elsif (i = dbw.count) then
      DBMS_OUTPUT.PUT_LINE(dbw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "LGWR",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN lgw.FIRST .. lgw.LAST LOOP
    if (i < lgw.count) then
      DBMS_OUTPUT.PUT_LINE(lgw(i) || ',');
    elsif (i = lgw.count) then
      DBMS_OUTPUT.PUT_LINE(lgw(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "RMAN",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rman.FIRST .. rman.LAST LOOP
    if (i < rman.count) then
      DBMS_OUTPUT.PUT_LINE(rman(i) || ',');
    elsif (i = rman.count) then
      DBMS_OUTPUT.PUT_LINE(rman(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Smart Scan",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN sc.FIRST .. sc.LAST LOOP
    if (i < sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i) || ',');
    elsif (i = sc.count) then
      DBMS_OUTPUT.PUT_LINE(sc(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Streams AQ",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN saq.FIRST .. saq.LAST LOOP
    if (i < saq.count) then
      DBMS_OUTPUT.PUT_LINE(saq(i) || ',');
    elsif (i = saq.count) then
      DBMS_OUTPUT.PUT_LINE(saq(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "XDB",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN xdb.FIRST .. xdb.LAST LOOP
    if (i < xdb.count) then
      DBMS_OUTPUT.PUT_LINE(xdb(i) || ',');
    elsif (i = xdb.count) then
      DBMS_OUTPUT.PUT_LINE(xdb(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data Pump",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dp.FIRST .. dp.LAST LOOP
    if (i < dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i) || ',');
    elsif (i = dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - I/O Function By IOPS"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "I/O Function By IOPS"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "IOPS/sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------I/O Function By IOPS----------------------------------
---------------------------------I/O FileType By Throughput----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  ar     ValueList; 
  arbk    ValueList;
  cf      ValueList;
  df       ValueList;
  dfc       ValueList;
  dfbk       ValueList;
  dfibk       ValueList;
  dp       ValueList;
  fl       ValueList;
  lf       ValueList;
  oth       ValueList;
  tf       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var ioftthpt = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select sum(case when filetype_name='Archive Log' then  thp/s_et else 0 end  )  ar,
sum(case when filetype_name='Archive Log Backup' then  thp/s_et else 0 end  )  arbk,
sum(case when filetype_name='Control File' then  thp/s_et else 0 end  )  cf,
sum(case when filetype_name='Data File' then  thp/s_et else 0 end  )  df,
sum(case when filetype_name='Data File Copy' then  thp/s_et else 0 end  )  dfc,
sum(case when filetype_name='Data File Backup' then  thp/s_et else 0 end  )  dfbk,
sum(case when filetype_name='Data File Incremental Backup' then  thp/s_et else 0 end  )  dfibk,
sum(case when filetype_name='Data Pump Dump File' then  thp/s_et else 0 end  )  dp,
sum(case when filetype_name='Flashback Log' then  thp/s_et else 0 end  )  fl,
sum(case when filetype_name='Log File' then  thp/s_et else 0 end  )  lf,
sum(case when filetype_name='Other' then  thp/s_et else 0 end  )  oth,
sum(case when filetype_name='Temp File' then  thp/s_et else 0 end  )  tf,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id from
(select  e.snap_id,e.instance_number,s.end_interval_time
           , e.filetype_name
           , sum((e.small_read_megabytes - b.small_read_megabytes)
             + (e.large_read_megabytes - b.large_read_megabytes)
			 + (e.small_write_megabytes - b.small_write_megabytes)
             + (e.large_write_megabytes - b.large_write_megabytes))  thp
           , sum((e.small_read_reqs - b.small_read_reqs)
             + (e.large_read_reqs - b.large_read_reqs)
			 + (e.small_write_reqs - b.small_write_reqs)
             + (e.large_write_reqs - b.large_write_reqs))  iops          
            ,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
        from dba_hist_iostat_filetype b
           , dba_hist_iostat_filetype e
      ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.instance_number=s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
         and e.dbid    = b.dbid
         and e.instance_number = b.instance_number
         and e.filetype_id     = b.filetype_id
         and e.filetype_name   = b.filetype_name
       group by e.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time,e.filetype_name)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
group by end_interval_time,snap_id
order by end_interval_time; 
  Fetch se_cur bulk collect
    into ar,arbk,cf,df,dfc,dfbk,dfibk,dp,fl,lf,oth,tf,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ar.extend;
 ar(1):='0';
 arbk.extend;
 arbk(1):='0';
 cf.extend;
 cf(1):='0';
 df.extend;
 df(1):='0';
 dfc.extend;
 dfc(1):='0';
 dfbk.extend;
 dfbk(1):='0';
  dfibk.extend;
 dfibk(1):='0';
  dp.extend;
 dp(1):='0';
  fl.extend;
 fl(1):='0';
  lf.extend;
 lf(1):='0';
  oth.extend;
 oth(1):='0';
   tf.extend;
 tf(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Archive Log",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN ar.FIRST .. ar.LAST LOOP
    if (i < ar.count) then
      DBMS_OUTPUT.PUT_LINE(ar(i) || ',');
    elsif (i = ar.count) then
      DBMS_OUTPUT.PUT_LINE(ar(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Archive Log Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN arbk.FIRST .. arbk.LAST LOOP
    if (i < arbk.count) then
      DBMS_OUTPUT.PUT_LINE(arbk(i) || ',');
    elsif (i = arbk.count) then
      DBMS_OUTPUT.PUT_LINE(arbk(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Control File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN cf.FIRST .. cf.LAST LOOP
    if (i < cf.count) then
      DBMS_OUTPUT.PUT_LINE(cf(i) || ',');
    elsif (i = cf.count) then
      DBMS_OUTPUT.PUT_LINE(cf(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN df.FIRST .. df.LAST LOOP
    if (i < df.count) then
      DBMS_OUTPUT.PUT_LINE(df(i) || ',');
    elsif (i = df.count) then
      DBMS_OUTPUT.PUT_LINE(df(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Copy",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfc.FIRST .. dfc.LAST LOOP
    if (i < dfc.count) then
      DBMS_OUTPUT.PUT_LINE(dfc(i) || ',');
    elsif (i = dfc.count) then
      DBMS_OUTPUT.PUT_LINE(dfc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfbk.FIRST .. dfbk.LAST LOOP
    if (i < dfbk.count) then
      DBMS_OUTPUT.PUT_LINE(dfbk(i) || ',');
    elsif (i = dfbk.count) then
      DBMS_OUTPUT.PUT_LINE(dfbk(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Incremental Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfibk.FIRST .. dfibk.LAST LOOP
    if (i < dfibk.count) then
      DBMS_OUTPUT.PUT_LINE(dfibk(i) || ',');
    elsif (i = dfibk.count) then
      DBMS_OUTPUT.PUT_LINE(dfibk(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data Pump Dump File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dp.FIRST .. dp.LAST LOOP
    if (i < dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i) || ',');
    elsif (i = dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Flashback Log",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN fl.FIRST .. fl.LAST LOOP
    if (i < fl.count) then
      DBMS_OUTPUT.PUT_LINE(fl(i) || ',');
    elsif (i = fl.count) then
      DBMS_OUTPUT.PUT_LINE(fl(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Log File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN lf.FIRST .. lf.LAST LOOP
    if (i < lf.count) then
      DBMS_OUTPUT.PUT_LINE(lf(i) || ',');
    elsif (i = lf.count) then
      DBMS_OUTPUT.PUT_LINE(lf(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;
    DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Temp File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN tf.FIRST .. tf.LAST LOOP
    if (i < tf.count) then
      DBMS_OUTPUT.PUT_LINE(tf(i) || ',');
    elsif (i = tf.count) then
      DBMS_OUTPUT.PUT_LINE(tf(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - I/O FileType By Throughput"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "I/O FileType By Throughput"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb/s" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------I/O FileType By Throughput End----------------------------------
---------------------------------I/O FileType By IOPS----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  ar     ValueList; 
  arbk    ValueList;
  cf      ValueList;
  df       ValueList;
  dfc       ValueList;
  dfbk       ValueList;
  dfibk       ValueList;
  dp       ValueList;
  fl       ValueList;
  lf       ValueList;
  oth       ValueList;
  tf       ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var ioftiops = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select sum(case when filetype_name='Archive Log' then  iops/s_et else 0 end  )  ar,
sum(case when filetype_name='Archive Log Backup' then  iops/s_et else 0 end  )  arbk,
sum(case when filetype_name='Control File' then  iops/s_et else 0 end  )  cf,
sum(case when filetype_name='Data File' then  iops/s_et else 0 end  )  df,
sum(case when filetype_name='Data File Copy' then  iops/s_et else 0 end  )  dfc,
sum(case when filetype_name='Data File Backup' then  iops/s_et else 0 end  )  dfbk,
sum(case when filetype_name='Data File Incremental Backup' then  iops/s_et else 0 end  )  dfibk,
sum(case when filetype_name='Data Pump Dump File' then  iops/s_et else 0 end  )  dp,
sum(case when filetype_name='Flashback Log' then  iops/s_et else 0 end  )  fl,
sum(case when filetype_name='Log File' then  iops/s_et else 0 end  )  lf,
sum(case when filetype_name='Other' then  iops/s_et else 0 end  )  oth,
sum(case when filetype_name='Temp File' then  iops/s_et else 0 end  )  tf,
'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id from
(select  e.snap_id,e.instance_number,s.end_interval_time
           , e.filetype_name
           , sum((e.small_read_megabytes - b.small_read_megabytes)
             + (e.large_read_megabytes - b.large_read_megabytes)
			 + (e.small_write_megabytes - b.small_write_megabytes)
             + (e.large_write_megabytes - b.large_write_megabytes))  thp
           , sum((e.small_read_reqs - b.small_read_reqs)
             + (e.large_read_reqs - b.large_read_reqs)
			 + (e.small_write_reqs - b.small_write_reqs)
             + (e.large_write_reqs - b.large_write_reqs))  iops          
            ,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
        from dba_hist_iostat_filetype b
           , dba_hist_iostat_filetype e
      ,dba_hist_snapshot       s
         where b.instance_number = s.instance_number
           and e.instance_number=s.instance_number
           and e.dbid            = b.dbid
           and b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
         and e.dbid    = b.dbid
         and e.instance_number = b.instance_number
         and e.filetype_id     = b.filetype_id
         and e.filetype_name   = b.filetype_name
       group by e.snap_id,e.instance_number,s.begin_interval_time,s.end_interval_time,e.filetype_name)
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
group by end_interval_time,snap_id
order by end_interval_time; 
  Fetch se_cur bulk collect
    into ar,arbk,cf,df,dfc,dfbk,dfibk,dp,fl,lf,oth,tf,SNAPTIME,SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ar.extend;
 ar(1):='0';
 arbk.extend;
 arbk(1):='0';
 cf.extend;
 cf(1):='0';
 df.extend;
 df(1):='0';
 dfc.extend;
 dfc(1):='0';
 dfbk.extend;
 dfbk(1):='0';
  dfibk.extend;
 dfibk(1):='0';
  dp.extend;
 dp(1):='0';
  fl.extend;
 fl(1):='0';
  lf.extend;
 lf(1):='0';
  oth.extend;
 oth(1):='0';
   tf.extend;
 tf(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Archive Log",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN ar.FIRST .. ar.LAST LOOP
    if (i < ar.count) then
      DBMS_OUTPUT.PUT_LINE(ar(i) || ',');
    elsif (i = ar.count) then
      DBMS_OUTPUT.PUT_LINE(ar(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Archive Log Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN arbk.FIRST .. arbk.LAST LOOP
    if (i < arbk.count) then
      DBMS_OUTPUT.PUT_LINE(arbk(i) || ',');
    elsif (i = arbk.count) then
      DBMS_OUTPUT.PUT_LINE(arbk(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Control File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN cf.FIRST .. cf.LAST LOOP
    if (i < cf.count) then
      DBMS_OUTPUT.PUT_LINE(cf(i) || ',');
    elsif (i = cf.count) then
      DBMS_OUTPUT.PUT_LINE(cf(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN df.FIRST .. df.LAST LOOP
    if (i < df.count) then
      DBMS_OUTPUT.PUT_LINE(df(i) || ',');
    elsif (i = df.count) then
      DBMS_OUTPUT.PUT_LINE(df(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Copy",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfc.FIRST .. dfc.LAST LOOP
    if (i < dfc.count) then
      DBMS_OUTPUT.PUT_LINE(dfc(i) || ',');
    elsif (i = dfc.count) then
      DBMS_OUTPUT.PUT_LINE(dfc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.grey1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfbk.FIRST .. dfbk.LAST LOOP
    if (i < dfbk.count) then
      DBMS_OUTPUT.PUT_LINE(dfbk(i) || ',');
    elsif (i = dfbk.count) then
      DBMS_OUTPUT.PUT_LINE(dfbk(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data File Incremental Backup",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dfibk.FIRST .. dfibk.LAST LOOP
    if (i < dfibk.count) then
      DBMS_OUTPUT.PUT_LINE(dfibk(i) || ',');
    elsif (i = dfibk.count) then
      DBMS_OUTPUT.PUT_LINE(dfibk(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Data Pump Dump File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN dp.FIRST .. dp.LAST LOOP
    if (i < dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i) || ',');
    elsif (i = dp.count) then
      DBMS_OUTPUT.PUT_LINE(dp(i));
    end if;
  END LOOP;
   DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Flashback Log",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN fl.FIRST .. fl.LAST LOOP
    if (i < fl.count) then
      DBMS_OUTPUT.PUT_LINE(fl(i) || ',');
    elsif (i = fl.count) then
      DBMS_OUTPUT.PUT_LINE(fl(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Log File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN lf.FIRST .. lf.LAST LOOP
    if (i < lf.count) then
      DBMS_OUTPUT.PUT_LINE(lf(i) || ',');
    elsif (i = lf.count) then
      DBMS_OUTPUT.PUT_LINE(lf(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Other",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN oth.FIRST .. oth.LAST LOOP
    if (i < oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i) || ',');
    elsif (i = oth.count) then
      DBMS_OUTPUT.PUT_LINE(oth(i));
    end if;
  END LOOP;
    DBMS_OUTPUT.PUT_LINE('], fill: true, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Temp File",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: true,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.black1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN tf.FIRST .. tf.LAST LOOP
    if (i < tf.count) then
      DBMS_OUTPUT.PUT_LINE(tf(i) || ',');
    elsif (i = tf.count) then
      DBMS_OUTPUT.PUT_LINE(tf(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - I/O FileType By IOPS"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "I/O FileType By IOPS"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "IOPS/sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------I/O FileType By IOPS End----------------------------------
---------------------------------SGA Breakdown Statistic----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  sga     ValueList; 
  bc       ValueList; 
  spt 	ValueList;
  spf 	ValueList;
  jp	ValueList;
  lp 	ValueList;
  stp 	ValueList;
  fsga 	ValueList;
  lb 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var sgabreak = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
  SELECT ROUND(sum(bytes)/1024/1024) sga
     , ROUND(sum(DECODE(pool,null, DECODE(name,'buffer_cache',bytes,0),0))/1024/1024) bc
     , ROUND(sum(DECODE(pool,'shared pool', bytes,0))/1024/1024) spt
     , ROUND(sum(DECODE(name,'free memory',bytes,0))/1024/1024) spf
     , ROUND(sum(DECODE(pool,'java pool', bytes,0))/1024/1024)   jp
     , ROUND(sum(DECODE(pool,'large pool', bytes,0))/1024/1024)  lp
     , ROUND(sum(DECODE(pool,'streams pool', bytes,0))/1024/1024) stp,
	 '"'||to_char(a.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,b.snap_id
FROM DBA_HIST_SGAstat B, DBA_HIST_SNAPSHOT A
WHERE A.DBID = B.DBID
AND A.INSTANCE_NUMBER = B.INSTANCE_NUMBER
AND A.SNAP_ID = B.SNAP_ID
AND a.snap_id >=&bid and a.snap_id <=&eid and a.instance_number=&inid
group by b.instance_number,b.snap_id,a.end_interval_time
order by a.end_interval_time;
Fetch se_cur bulk collect
    into sga, bc, spt, spf,jp,lp,stp, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 sga.extend;
 sga(1):='0';
 bc.extend;
 bc(1):='0';
 spt.extend;
 spt(1):='0';
 spf.extend;
 spf(1):='0';
  jp.extend;
 jp(1):='0';
  lp.extend;
 lp(1):='0';
  stp.extend;
 stp(1):='0';
  fsga.extend;
 fsga(1):='0';
  lp.extend;
 lp(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Buffer Cache",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN bc.FIRST .. bc.LAST LOOP
    if (i < bc.count) then
      DBMS_OUTPUT.PUT_LINE(bc(i) || ',');
    elsif (i = bc.count) then
      DBMS_OUTPUT.PUT_LINE(bc(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Shared Pool Total",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN spt.FIRST .. spt.LAST LOOP
    if (i < spt.count) then
      DBMS_OUTPUT.PUT_LINE(spt(i) || ',');
    elsif (i = spt.count) then
      DBMS_OUTPUT.PUT_LINE(spt(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Java Pool",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.pink2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.pink2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN jp.FIRST .. jp.LAST LOOP
    if (i < jp.count) then
      DBMS_OUTPUT.PUT_LINE(jp(i) || ',');
    elsif (i = jp.count) then
      DBMS_OUTPUT.PUT_LINE(jp(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Large Pool",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
    DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN lp.FIRST .. lp.LAST LOOP
    if (i < lp.count) then
      DBMS_OUTPUT.PUT_LINE(lp(i) || ',');
    elsif (i = lp.count) then
      DBMS_OUTPUT.PUT_LINE(lp(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], },{');
  DBMS_OUTPUT.PUT_LINE('label: "Stream Pool",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
   DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN stp.FIRST .. stp.LAST LOOP
    if (i < stp.count) then
      DBMS_OUTPUT.PUT_LINE(stp(i) || ',');
    elsif (i = stp.count) then
      DBMS_OUTPUT.PUT_LINE(stp(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - SGA Memory Breakdown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "SGA Breakdown"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------SGA Breakdown Statistic End----------------------------------
-------------------exadata-------------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
cellpredicatedata ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var e1data = { type: "line", data: { labels: ['); 
open my_cur for
select trunc(predicate/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),  snap_time
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3 order by snap_time;
 FETCH my_cur BULK COLLECT INTO cellpredicatedata,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cellpredicatedata.extend;
 cellpredicatedata(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cell physical IO MB eligible for predicate offload / Second    ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.pink1,');
dbms_output.put_line('borderColor: window.awrColors.red2,');
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN cellpredicatedata.FIRST .. cellpredicatedata.LAST
LOOP
  if(i<cellpredicatedata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i)||',');
end if;
elsif(i=cellpredicatedata.count) then
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Cell physical IO MB eligible for predicate offload "');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Mb/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
cellpredicatedata ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var e2data = { type: "line", data: { labels: ['); 
open my_cur for
select trunc(storageidx/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),  snap_time
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;
 FETCH my_cur BULK COLLECT INTO cellpredicatedata,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cellpredicatedata.extend;
 cellpredicatedata(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cell physical IO MB saved by storage index / Second     ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.pink1,');
dbms_output.put_line('borderColor: window.awrColors.red2,');
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN cellpredicatedata.FIRST .. cellpredicatedata.LAST
LOOP
  if(i<cellpredicatedata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i)||',');
end if;
elsif(i=cellpredicatedata.count) then
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Cell physical IO MB saved by storage index "');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Mb/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
cellpredicatedata ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var e3data = { type: "line", data: { labels: ['); 
open my_cur for
select trunc(smart/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),  snap_time
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;
 FETCH my_cur BULK COLLECT INTO cellpredicatedata,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cellpredicatedata.extend;
 cellpredicatedata(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cell physical IO interconnect MB returned by smart scan / Second     ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.pink1,');
dbms_output.put_line('borderColor: window.awrColors.red2,');
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN cellpredicatedata.FIRST .. cellpredicatedata.LAST
LOOP
  if(i<cellpredicatedata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i)||',');
end if;
elsif(i=cellpredicatedata.count) then
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Cell physical IO interconnect MB returned by smart scan"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Mb/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
cellpredicatedata ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var e4data = { type: "line", data: { labels: ['); 
open my_cur for
select trunc(uncom/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),  snap_time
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
(select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;
 FETCH my_cur BULK COLLECT INTO cellpredicatedata,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 cellpredicatedata.extend;
 cellpredicatedata(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Cell IO uncompressed MB / Second      ",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.pink1,');
dbms_output.put_line('borderColor: window.awrColors.red2,');
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN cellpredicatedata.FIRST .. cellpredicatedata.LAST
LOOP
  if(i<cellpredicatedata.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i)||',');
end if;
elsif(i=cellpredicatedata.count) then
DBMS_OUTPUT.PUT_LINE (cellpredicatedata(i));
end if;
END LOOP;
dbms_output.put_line('], fill: true, } ] },                  ');      
dbms_output.put_line('options: {                             ');
dbms_output.put_line('responsive: true,                      ');
dbms_output.put_line('title:{                                ');
dbms_output.put_line('display:true,                          ');
dbms_output.put_line('text:"&_dbname&inid - Cell IO Uncompressed MB"');
dbms_output.put_line('},                                     ');
dbms_output.put_line('tooltips: {                            ');
dbms_output.put_line('mode: "index",                         ');
dbms_output.put_line('intersect: false,                      ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('hover: {                               ');
dbms_output.put_line('mode: "nearest",                       ');
dbms_output.put_line('intersect: true                        ');
dbms_output.put_line('},                                     ');
dbms_output.put_line('scales: {                              ');
dbms_output.put_line('xAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Snap"                    ');
dbms_output.put_line('}                                      ');
dbms_output.put_line('}],                                    ');
dbms_output.put_line('yAxes: [{                              ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('scaleLabel: {                          ');
dbms_output.put_line('display: true,                         ');
dbms_output.put_line('labelString: "Mb/Sec"                   ');
dbms_output.put_line('}  }] }  } };                          ');
end;
/
---------------------------exadataend--------------------------------------
---------------------------------Chain Rows By Cells----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  rt     ValueList; 
  pt       ValueList; 
  st 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var chainrowcell = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(chainpbc/s_et,2) chainpbc
     , round(chainsbc/s_et,2) chainsbc
     , round(chainrj/s_et,2) chainrj
	 ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select s.instance_number,s.snap_id,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
            where se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           and se.stat_name in
                 ( 'chained rows processed by cell','chained rows skipped by cell','chained rows rejected by cell'))
         pivot (sum(value) for stat_name in (
                'chained rows processed by cell'     chainpbc
               ,'chained rows skipped by cell'           chainsbc,
               'chained rows rejected by cell' chainrj)))
where snap_id >=&bid and snap_id <=&eid and instance_number=&inid
order by snap_time;
 Fetch se_cur bulk collect
    into rt, pt,st,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 rt.extend;
rt(1):='0';
 st.extend;
st(1):='0';
 pt.extend;
 pt(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Chained rows rejected by cell",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN st.FIRST .. st.LAST LOOP
    if (i < st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i) || ',');
    elsif (i = st.count) then
      DBMS_OUTPUT.PUT_LINE(st(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Chained rows skipped by cell",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN pt.FIRST .. pt.LAST LOOP
    if (i < pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i) || ',');
    elsif (i = pt.count) then
      DBMS_OUTPUT.PUT_LINE(pt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Chained rows processed by cell",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN rt.FIRST .. rt.LAST LOOP
    if (i < rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i) || ',');
    elsif (i = rt.count) then
      DBMS_OUTPUT.PUT_LINE(rt(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Chain Rows By Cells"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Chain Rows By Cells"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
DBMS_OUTPUT.PUT_LINE('stacked: true, ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Rows/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Chain Rows By Cells End----------------------------------
----------------------------EXADATA EFFICIENT RATIO-----------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  SNAPTIME ValueList;
  sp ValueList;
  ms ValueList;
  rcm ValueList;
  rd ValueList;
  rc ValueList;
  cr_cur sys_refcursor;
BEGIN
  DBMS_OUTPUT.PUT_LINE('var fchit = { type: "line", data: { labels: [');     
  OPEN CR_CUR FOR 
select decode(phy_read_tot_bytes,0,0,cell_phy_io_by_str_ind/phy_read_tot_bytes*100) pct_saved_by_storage,
decode(phy_read_tot_req,0,0,cell_flash_cache_hits/phy_read_tot_req*100) pct_flash_cache_hit,
decode(phy_read_tot_bytes,0,0,cell_eligible_for_offload/phy_read_tot_bytes*100) pct_predicate_offload,
decode(cell_eligible_for_offload,0,0,100-cell_io_returned_by_smart_scan/cell_eligible_for_offload*100) pct_Smart_Scan_efficiency,
decode(phy_read_tot_bytes,0,0,(cell_eligible_for_offload-cell_io_returned_by_smart_scan)/phy_read_tot_bytes*100) pct_Smart_Scan_offload
,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time
from (
select
    s1.instance_number,
    end_interval_time,
	s1.snap_id,
    sum(case when s1.stat_name ='cell physical IO interconnect bytes' then s1.stat_value end) cell_phy_io_intercon,
    sum(case when s1.stat_name ='cell physical IO bytes saved by storage index' then s1.stat_value end) cell_phy_io_by_str_ind,
    sum(case when s1.stat_name ='cell flash cache read hits' then s1.stat_value end) cell_flash_cache_hits,
    sum(case when s1.stat_name ='cell physical IO interconnect bytes returned by smart scan' then s1.stat_value end) cell_io_returned_by_smart_scan,
    sum(case when s1.stat_name ='cell physical IO bytes eligible for predicate offload' then s1.stat_value end) cell_eligible_for_offload,
    sum(case when s1.stat_name ='physical read total IO requests' then s1.stat_value end) phy_read_tot_req,
    sum(case when s1.stat_name ='physical read total bytes' then s1.stat_value end) phy_read_tot_bytes
from
(
select s1.snap_id, s1.stat_id, s1.stat_name,
      case when stat_name = lag(stat_name) over (order by s1.stat_name,s1.instance_number,s1.snap_id)  and
          s1.instance_number = lag(s1.instance_number) over (order by s1.stat_name,s1.instance_number,s1.snap_id) and
         value >= lag(value) over (order by s1.stat_name,s1.instance_number,s1.snap_id) then
         value - lag(value) over (order by s1.stat_name,s1.instance_number,s1.snap_id)
       end stat_value,
  s1.instance_number
from dba_hist_sysstat s1 where
   s1.stat_name
     in (
                'cell physical IO interconnect bytes',
                'cell physical IO bytes saved by storage index',
                'cell flash cache read hits',
                'cell physical IO interconnect bytes returned by smart scan',
                'cell physical IO bytes eligible for predicate offload',
                'physical read total IO requests',
                'physical read total bytes'
         )
) s1,
  dba_hist_snapshot s
  where s1.snap_id = s.snap_id
   and s1.instance_number = s.instance_number
group by s1.instance_number,end_interval_time,s1.snap_id
) where snap_id >= &bid and snap_id <= &eid     and instance_number = &inid
order by snap_time;
    FETCH CR_CUR     BULK COLLECT    INTO sp,ms,rcm,rd,rc,SNAPTIME;
    close CR_CUR;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 sp.extend;
 sp(1):='0';
 ms.extend;
 ms(1):='0';
 rcm.extend;
 rcm(1):='0';
 rd.extend;
 rd(1):='0';
  rc.extend;
 rc(1):='0';
end if;
-----------------------------------------  
    FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
  if i=1 then
   null;
  else
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
end if;
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{'); 
dbms_output.put_line('label: "Saved By Storage Index",'); 
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,'); 
dbms_output.put_line('borderColor: window.awrColors.red1,'); 
dbms_output.put_line('data: ['); 
------------------------------
 FOR i IN sp.FIRST .. sp.LAST
LOOP
  if(i<sp.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (sp(i)||',');
end if;
elsif(i=sp.count) then
DBMS_OUTPUT.PUT_LINE (sp(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Flash Cacht Hit",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.blue1,');
dbms_output.put_line('borderColor: window.awrColors.blue1,');
dbms_output.put_line('data: [');
 FOR i IN ms.FIRST .. ms.LAST
LOOP
  if(i<ms.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (ms(i)||',');
end if;
elsif(i=ms.count) then
DBMS_OUTPUT.PUT_LINE (ms(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Predicate OffLoad",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.purple1,');
dbms_output.put_line('borderColor: window.awrColors.purple1,');
dbms_output.put_line('data: [');
 FOR i IN rcm.FIRST .. rcm.LAST
LOOP
  if(i<rcm.count) then
   if i=1 then
    null;
  else
dbms_OUTPUT.PUT_LINE (rcm(i)||',');
end if;
elsif(i=rcm.count) then
DBMS_OUTPUT.PUT_LINE (rcm(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Smart Scan Efficiency",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.orange1,');
dbms_output.put_line('borderColor: window.awrColors.orange1,');
dbms_output.put_line('data: [');
 FOR i IN rd.FIRST .. rd.LAST
LOOP
  if(i<rd.count) then
   if i=1 then
    null;
  else
dbms_OUTPUT.PUT_LINE (rd(i)||',');
end if;
elsif(i=rd.count) then
DBMS_OUTPUT.PUT_LINE (rd(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Smart Scan Offload",');
DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.purple2,');
dbms_output.put_line('borderColor: window.awrColors.purple2,');
dbms_output.put_line('data: [');
 FOR i IN rc.FIRST .. rc.LAST
LOOP
  if(i<rc.count) then
   if i=1 then
    null;
  else
DBMS_OUTPUT.PUT_LINE (rc(i)||',');
end if;
elsif(i=rc.count) then
DBMS_OUTPUT.PUT_LINE (rc(i));
end if;
END LOOP;
dbms_output.put_line('], }] },                    ');
dbms_output.put_line('options: {                  ');
dbms_output.put_line('responsive: true,           ');
dbms_output.put_line('title:{                     ');
dbms_output.put_line('display:true,               ');
dbms_output.put_line('text:"&_dbname&inid  - Exadata Sufficient Ratio"');
dbms_output.put_line('},                          ');
dbms_output.put_line('tooltips: {                 ');
dbms_output.put_line('mode: "index",              ');
dbms_output.put_line('intersect: false,           ');
dbms_output.put_line('},                          ');
dbms_output.put_line('hover: {                    ');
dbms_output.put_line('mode: "nearest",            ');
dbms_output.put_line('intersect: true             ');
dbms_output.put_line('},                          ');
dbms_output.put_line('scales: {                   ');
dbms_output.put_line('xAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString: "Exadata Sufficient Ratio"         ');
dbms_output.put_line('}                           ');
dbms_output.put_line('}],                         ');
dbms_output.put_line('yAxes: [{                   ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('scaleLabel: {               ');
dbms_output.put_line('display: true,              ');
dbms_output.put_line('labelString:  "Percentage"       ');
dbms_output.put_line('} }] } } };                 ');
end;
/
----------------------------EXADATA EFFICIENT END-----------------------------
------------------------event---------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
pct ValueList;
event ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var eventdata = { data: { datasets: [{ data: ['); 
open my_cur for
select 
pct,event
 from
(
SELECT
        trunc(PCTWTT,2) pct , EVENT, rownum rn
  FROM (SELECT EVENT, WAITS, TIME, PCTWTT, WAIT_CLASS
          FROM (SELECT E.EVENT_NAME EVENT,
                       E.TOTAL_WAITS_FG - NVL(B.TOTAL_WAITS_FG, 0) WAITS,
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       1000000 TIME,
                       100 *
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       E.WAIT_CLASS WAIT_CLASS
                  FROM DBA_HIST_SYSTEM_EVENT B, DBA_HIST_SYSTEM_EVENT E
                 WHERE B.SNAP_ID(+) = &bid
                   AND E.SNAP_ID = &eid
                   AND B.INSTANCE_NUMBER(+) = &inid
                   AND E.INSTANCE_NUMBER = &inid
                   AND B.EVENT_ID(+) = E.EVENT_ID
                   AND E.TOTAL_WAITS > NVL(B.TOTAL_WAITS, 0)
                   AND E.WAIT_CLASS != 'Idle'
                UNION ALL
                SELECT 'CPU time' EVENT,
                       TO_NUMBER(NULL) WAITS,
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB CPU')) / 1000000 TIME,
                       100 * ((SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL e
                                WHERE e.SNAP_ID = &eid
                                  AND e.INSTANCE_NUMBER = &inid
                                  AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL b
                                WHERE b.SNAP_ID = &bid
                                  AND b.INSTANCE_NUMBER = &inid
                                  AND b.STAT_NAME = 'DB CPU')) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       NULL WAIT_CLASS
                  from dual
                 WHERE ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB CPU'))> 0)
         ORDER BY TIME DESC, WAITS DESC)
 WHERE ROWNUM <= 5) a1 order by rn;
 FETCH my_cur BULK COLLECT INTO pct,event;
 close my_cur;
 FOR i IN pct.FIRST .. pct.LAST
LOOP
  if(i<pct.count) then
DBMS_OUTPUT.PUT_LINE (pct(i)||',');
elsif(i=pct.count) then
DBMS_OUTPUT.PUT_LINE (pct(i));
end if;
END LOOP;
dbms_output.put_line('], backgroundColor: [');
dbms_output.put_line('window.awrColors.red2,');
dbms_output.put_line('window.awrColors.blue2,');
dbms_output.put_line('window.awrColors.green1,');
dbms_output.put_line('window.awrColors.yellow1,');
dbms_output.put_line('window.awrColors.orange1');
dbms_output.put_line('], label: "Event" }],');
dbms_output.put_line('labels: [');
FOR i IN event.FIRST .. event.LAST
LOOP
  if(i<event.count) then
DBMS_OUTPUT.PUT_LINE ('"'||event(i)||'",');
elsif(i=event.count) then
DBMS_OUTPUT.PUT_LINE ('"'||event(i)||'"');
end if;
END LOOP;
dbms_output.put_line('   ] },');
dbms_output.put_line('  options: {');
dbms_output.put_line('     responsive: true,');
dbms_output.put_line('   legend: {');
dbms_output.put_line('    position: "right",');
dbms_output.put_line(' },');
dbms_output.put_line(' title: {');
dbms_output.put_line('   display: true,');
dbms_output.put_line('  text: "event"');
dbms_output.put_line(' },');
dbms_output.put_line(' scale: {');
dbms_output.put_line(' ticks: {');
dbms_output.put_line(' beginAtZero: true');
dbms_output.put_line(' },');
dbms_output.put_line(' reverse: false');
dbms_output.put_line(' },');
dbms_output.put_line(' animation: {');
dbms_output.put_line(' animateRotate: false,');
dbms_output.put_line(' animateScale: true');
dbms_output.put_line('} } };');
end;
/
----------------------event end--------------------------------
-----------------pasrse count------------------------------
declare
TYPE ValueList IS TABLE OF varchar2(200);
snaptime ValueList;
p_data ValueList;
hp_data ValueList;
my_cur SYS_REFCURSOR;
begin
dbms_output.put_line('var parsedata = { type: "line", data: { labels: [');
open my_cur for
select hp,p,snap_time 
 from (
select 
trunc( ( a2.hp - lag(a2.hp, 1, a2.hp) over(order by a2.snap_id))/&_iv) hp,
trunc( (  a2.p - lag(a2.p, 1, a2.p) over(order by a2.snap_id))/&_iv) p,
 (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) snap_time
           from (
select b.snap_id,
       sum(case when b.STAT_NAME='parse count (total)' then value else 0 end) p,
       sum(case when b.STAT_NAME='parse count (hard)' then value else 0 end) hp
  FROM DBA_HIST_SYSSTAT b 
where  b.STAT_NAME in ('parse count (total)','parse count (hard)') and b.instance_number=&inid
and b.snap_id>=&bid and b.snap_id<=&eid group by b.snap_id
order by b.snap_id)a2
 where hp>0
)a3;
 FETCH my_cur BULK COLLECT INTO hp_data,p_data,snaptime;
 close my_cur;
    ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 p_data.extend;
 p_data(1):='0';
end if;
----------------------------------------- 
  FOR i IN snaptime.FIRST .. snaptime.LAST
LOOP
  if(i<snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i)||',');
elsif(i=snaptime.count) then
DBMS_OUTPUT.PUT_LINE (snaptime(i));
end if;
END LOOP;
------------------------------------
dbms_output.put_line('], datasets: [{');
dbms_output.put_line('label: "Hard Parse count",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('backgroundColor: window.awrColors.red1,');
dbms_output.put_line('borderColor: window.awrColors.red2,');
dbms_output.put_line('data: [ ');
------------------------------
 FOR i IN hp_data.FIRST .. hp_data.LAST
LOOP
  if(i<hp_data.count) then
DBMS_OUTPUT.PUT_LINE (hp_data(i)||',');
elsif(i=hp_data.count) then
DBMS_OUTPUT.PUT_LINE (hp_data(i));
end if;
END LOOP;
dbms_output.put_line('], fill: false, }, {');
dbms_output.put_line('label: "Parse count",');
dbms_output.put_line('lineTension :0,');
dbms_output.put_line('fill: false,');
dbms_output.put_line('backgroundColor: window.awrColors.orange1,');
dbms_output.put_line('borderColor: window.awrColors.orange2,');
dbms_output.put_line('data: [');
 FOR i IN p_data.FIRST .. p_data.LAST
LOOP
  if(i<p_data.count) then
DBMS_OUTPUT.PUT_LINE (p_data(i)||',');
elsif(i=p_data.count) then
DBMS_OUTPUT.PUT_LINE (p_data(i));
end if;
END LOOP;
dbms_output.put_line('], }] },              ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid  - SQL Parse"      ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Snap"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Counts/Sec" ');
dbms_output.put_line('} }] } } };           ');
end;
/
-----------------------parse count end----------------
---------------------------------CPU Parse BreakDown ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var cpuparse = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(recursivecpu/s_et,2) recursivecpu
     , round(prstmcpu/s_et,2) prstmcpu
     ,round(cpuuse/s_et,2) cpuuse,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ( 'recursive cpu usage','parse time cpu','CPU used by this session'))
         pivot (sum(value) for stat_name in (
'recursive cpu usage' recursivecpu,
'parse time cpu' prstmcpu,
'CPU used by this session' cpuuse
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "ServiceTime(CPU Usage)",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "CPU Parse",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "CPU Recursive",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - CPU Parse BreakDown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "CPU Parse BreakDown"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Count/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
-----------------------CPU Parse BreakDown ----------------------------------
---------------------------------SQLNet Statistic ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  phe 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var sqlnet = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(stc/s_et/1048576,2) stc
     , round(rfc/s_et/1048576,2) rfc
     ,round(stdbl/s_et/1048576,2) stdbl
	 ,round(rfdbl/s_et/1048576,2) rfdbl
	 ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
		   and  s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ('bytes sent via SQL*Net to client','bytes received via SQL*Net from client','bytes sent via SQL*Net to dblink','bytes received via SQL*Net from dblink'))
         pivot (sum(value) for stat_name in (
                'bytes sent via SQL*Net to client'     stc
               ,'bytes received via SQL*Net from client'           rfc
               ,'bytes sent via SQL*Net to dblink'          stdbl
               ,'bytes received via SQL*Net from dblink'                rfdbl
))) order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,phe,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
  phe.extend;
 phe(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "SQL*Net to dblink",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "SQL*Net from client",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "SQL*Net to client",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "SQL*Net from dblink",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phe.FIRST .. phe.LAST LOOP
    if (i < phe.count) then
      DBMS_OUTPUT.PUT_LINE(phe(i) || ',');
    elsif (i = phe.count) then
      DBMS_OUTPUT.PUT_LINE(phe(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - SQLNet Statistic"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "SQLNet Statistic"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------SQLNet Statistic----------------------------------
---------------------------------Parallel Run ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  ucom     ValueList; 
  tnxroll       ValueList; 
  uroll 	ValueList;
  execcnt 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var parallell = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(dfo/s_et,2) ucom
	 , round(ddl/s_et,2) tnxroll
	 , round(dml/s_et,2) uroll
	 , round(qr/s_et,2) execcnt,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           and s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ('DFO trees parallelized','DDL statements parallelized','DML statements parallelized','queries parallelized'))
         pivot (sum(value) for stat_name in (
'DFO trees parallelized' dfo,
'DDL statements parallelized' ddl,
'DML statements parallelized' dml,
'queries parallelized' qr
))) order by snap_time;
Fetch se_cur bulk collect
    into ucom, tnxroll,uroll,execcnt, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ucom.extend;
ucom(1):='0';
 uroll.extend;
uroll(1):='0';
 execcnt.extend;
 execcnt(1):='0';
 tnxroll.extend;
 tnxroll(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "DML statements parallelized",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN uroll.FIRST .. uroll.LAST LOOP
    if (i < uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i) || ',');
    elsif (i = uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "queries parallelized",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderDash: [5, 5],');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execcnt.FIRST .. execcnt.LAST LOOP
    if (i < execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i) || ',');
    elsif (i = execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DDL statements parallelized",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN tnxroll.FIRST .. tnxroll.LAST LOOP
    if (i < tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i) || ',');
    elsif (i = tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DFO trees parallelized",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ucom.FIRST .. ucom.LAST LOOP
    if (i < ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i) || ',');
    elsif (i = ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Parallel Execution BreakDown"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Parallel Execution BreakDown"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "#Operation Per Seconds" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Parallel Run ----------------------------------
---------------------------------Parallel Operations----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  ucom     ValueList; 
  tnxroll       ValueList; 
  uroll 	ValueList;
  execcnt 	ValueList;
  execdg2 	ValueList;
  execdg3 	ValueList;
  execdg4 	ValueList;  
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var parallelloper = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select round(dfo/s_et,2) ucom
	 , round(ndg/s_et,2) tnxroll
	 , round(dgs/s_et,2) uroll
	 , round(dg1/s_et,2) execcnt
	 , round(dg2/s_et,2) execdg2
	 , round(dg3/s_et,2) execdg3
	 , round(dg4/s_et,2) execdg4
	 ,'"'||to_char(end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,snap_id
  from ((select se.snap_id,s.instance_number,TO_CHAR(s.begin_interval_time, 'mm/dd/yyyy HH24:MI') begintime,86400*(TO_NUMBER(TO_CHAR(s.end_interval_time,'J'))
	       -TO_NUMBER(TO_CHAR(s.begin_interval_time,'J')))
	+	3600*(EXTRACT(HOUR FROM end_interval_time)-EXTRACT(HOUR FROM begin_interval_time))
	+	60*(EXTRACT(MINUTE FROM end_interval_time)-EXTRACT(MINUTE FROM begin_interval_time))
	+	EXTRACT(SECOND FROM end_interval_time)-EXTRACT(SECOND FROM begin_interval_time) s_et
  						, s.end_interval_time
             , se.stat_name
             , (se.value - nvl(sb.value,0)) value
          from dba_hist_sysstat sb
             , dba_hist_sysstat se
         	,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.instance_number=s.instance_number
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
           and s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
           and se.stat_name in
                 ('DFO trees parallelized','Parallel operations not downgraded','Parallel operations downgraded to serial','Parallel operations downgraded 1 to 25 pct','Parallel operations downgraded 25 to 50 pct','Parallel operations downgraded 50 to 75 pct','Parallel operations downgraded 75 to 99 pct'))
         pivot (sum(value) for stat_name in (
'DFO trees parallelized' dfo,
'Parallel operations not downgraded' ndg,
'Parallel operations downgraded to serial' dgs,
'Parallel operations downgraded 1 to 25 pct' dg1,
'Parallel operations downgraded 25 to 50 pct' dg2,
'Parallel operations downgraded 50 to 75 pct' dg3,
'Parallel operations downgraded 75 to 99 pct' dg4
))) order by snap_time;
Fetch se_cur bulk collect
    into ucom, tnxroll,uroll,execcnt,execdg2,execdg3,execdg4, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 ucom.extend;
ucom(1):='0';
 uroll.extend;
uroll(1):='0';
 execcnt.extend;
 execcnt(1):='0';
 tnxroll.extend;
 tnxroll(1):='0';
  execdg2.extend;
 execdg2(1):='0';
  execdg3.extend;
 execdg3(1):='0';
  execdg4.extend;
 execdg4(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations downgraded to serial",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN uroll.FIRST .. uroll.LAST LOOP
    if (i < uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i) || ',');
    elsif (i = uroll.count) then
      DBMS_OUTPUT.PUT_LINE(uroll(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations downgraded 1 to 25 pct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execcnt.FIRST .. execcnt.LAST LOOP
    if (i < execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i) || ',');
    elsif (i = execcnt.count) then
      DBMS_OUTPUT.PUT_LINE(execcnt(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations not downgraded",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderDash: [5, 5],');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN tnxroll.FIRST .. tnxroll.LAST LOOP
    if (i < tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i) || ',');
    elsif (i = tnxroll.count) then
      DBMS_OUTPUT.PUT_LINE(tnxroll(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "DFO trees parallelized",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN ucom.FIRST .. ucom.LAST LOOP
    if (i < ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i) || ',');
    elsif (i = ucom.count) then
      DBMS_OUTPUT.PUT_LINE(ucom(i));
    end if;
	END LOOP;
	  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations downgraded 25 to 50 pct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.orange1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execdg2.FIRST .. execdg2.LAST LOOP
    if (i < execdg2.count) then
      DBMS_OUTPUT.PUT_LINE(execdg2(i) || ',');
    elsif (i = execdg2.count) then
      DBMS_OUTPUT.PUT_LINE(execdg2(i));
    end if;
	END LOOP;
	  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations downgraded 50 to 75 pct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execdg3.FIRST .. execdg3.LAST LOOP
    if (i < execdg3.count) then
      DBMS_OUTPUT.PUT_LINE(execdg3(i) || ',');
    elsif (i = execdg3.count) then
      DBMS_OUTPUT.PUT_LINE(execdg3(i));
    end if;
	END LOOP;
	  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Parallel operations downgraded 75 to 99 pct",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green2,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN execdg4.FIRST .. execdg4.LAST LOOP
    if (i < execdg4.count) then
      DBMS_OUTPUT.PUT_LINE(execdg4(i) || ',');
    elsif (i = execdg4.count) then
      DBMS_OUTPUT.PUT_LINE(execdg4(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - Parallel Operations"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "Parallel Operations"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "#Operation Per Seconds" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------Parallel Operations----------------------------------
---------------------------------PGA Effectiveness ----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200);
  snap_id  ValueList;
  phr     ValueList; 
  phc       ValueList; 
  phd 	ValueList;
  phe 	ValueList;
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var pgaeff = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
select sum(e.OPTIMAL_EXECUTIONS - nvl(b.OPTIMAL_EXECUTIONS,0)) optmexec
, sum(e.ONEPASS_EXECUTIONS - nvl(b.ONEPASS_EXECUTIONS,0)) onepassexec
, sum(e.MULTIPASSES_EXECUTIONS - nvl(b.MULTIPASSES_EXECUTIONS,0)) mulpassexec
, sum(e.TOTAL_EXECUTIONS - nvl(b.TOTAL_EXECUTIONS,0))  totalexec
,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time,s.snap_id
from DBA_HIST_SQL_WORKAREA_HSTGRM b
, DBA_HIST_SQL_WORKAREA_HSTGRM e
,dba_hist_snapshot       s
, gv$instance             i
where i.instance_number = s.instance_number
and e.dbid            = b.dbid
and b.snap_id    =s.snap_id - 1
and e.snap_id         = s.snap_id
and e.instance_number=s.instance_number
and e.dbid            = b.dbid            (+)
and e.instance_number = b.instance_number (+)
and b.low_optimal_size(+)  = e.low_optimal_size
and b.high_optimal_size(+)  = e.high_optimal_size
and e.total_executions  -  nvl(b.total_executions,0)   >     0
and s.snap_id >=&bid and s.snap_id <=&eid and i.instance_number=&inid
group by e.instance_number,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"',s.snap_id
order by snap_time;
Fetch se_cur bulk collect
    into phr, phc,phd,phe,SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 phr.extend;
phr(1):='0';
 phd.extend;
phd(1):='0';
 phc.extend;
 phc(1):='0';
  phe.extend;
 phe(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Multipass Executions",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
   FOR i IN phd.FIRST .. phd.LAST LOOP
    if (i < phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i) || ',');
    elsif (i = phd.count) then
      DBMS_OUTPUT.PUT_LINE(phd(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Onepass Executions",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.purple1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phc.FIRST .. phc.LAST LOOP
    if (i < phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i) || ',');
    elsif (i = phc.count) then
      DBMS_OUTPUT.PUT_LINE(phc(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Optimal Executions",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phr.FIRST .. phr.LAST LOOP
    if (i < phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i) || ',');
    elsif (i = phr.count) then
      DBMS_OUTPUT.PUT_LINE(phr(i));
    end if;
	END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Total Executions",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN phe.FIRST .. phe.LAST LOOP
    if (i < phe.count) then
      DBMS_OUTPUT.PUT_LINE(phe(i) || ',');
    elsif (i = phe.count) then
      DBMS_OUTPUT.PUT_LINE(phe(i));
    end if;
	END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - PGA Effectiveness"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "PGA Effectiveness"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Count/Sec" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------PGA Effectiveness----------------------------------
---------------------------------OS Swap vs Memory----------------------------------
declare
  TYPE ValueList IS TABLE OF varchar2(200); 
  snap_id  ValueList;
  vmin     ValueList; 
  vmout       ValueList; 
  osmem       ValueList; 
  SNAPTIME ValueList;
  se_cur   sys_refcursor;
begin
  DBMS_OUTPUT.PUT_LINE('var osswap = { type: "line", data: { labels: [');
  OPEN SE_CUR FOR
   select round(vmin_v/1048576,1) vmin
	 ,round(vmout_v/1048576,1) vmout
     ,round(mem_b/1048576,1) mem_b
	 ,snap_time,snap_id
  from ((select se.snap_id,'"'||to_char(s.end_interval_time, 'mm-dd hh24:mi')||'"' snap_time
             , se.stat_name
             , sb.value bval
             , se.value eval
             , (se.value - nvl(sb.value,0))  value
        from dba_hist_osstat sb
           , dba_hist_osstat se
           ,dba_hist_snapshot       s
          , gv$instance             i
         where i.instance_number = s.instance_number
           and se.dbid            = sb.dbid
           and sb.snap_id    =s.snap_id - 1
           and se.snap_id         = s.snap_id
           and se.dbid            = sb.dbid            (+)
           and se.instance_number = sb.instance_number (+)
           and se.stat_id         = sb.stat_id         (+)
             AND se.instance_number = s.instance_number
  and s.snap_id >= &bid
and s.snap_id <= &eid
and i.instance_number= &inid)
        pivot (sum(value) v, max(bval) b, max(eval) e 
               for stat_name in (
			  'PHYSICAL_MEMORY_BYTES'  mem
			  ,'VM_IN_BYTES' vmin
			  ,'VM_OUT_BYTES' vmout)));
  Fetch se_cur bulk collect
    into vmin, vmout,osmem, SNAPTIME, SNAP_ID;
close se_cur;
  ---handle null list---------------------
if(snaptime.count=0) then
snaptime.extend;
snaptime(1):='"1981-03-30 20:00:00"';
 vmin.extend;
 vmin(1):='0';
 vmout.extend;
 vmout(1):='0';
 osmem.extend;
 osmem(1):='0';
end if;
-----------------------------------------  
  FOR i IN snaptime.FIRST .. snaptime.LAST LOOP
    if (i < snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i) || ',');
    elsif (i = snaptime.count) then
      DBMS_OUTPUT.PUT_LINE(snaptime(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('  ], datasets: [{');
  DBMS_OUTPUT.PUT_LINE('label: "Swap IN",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.blue2,');
  DBMS_OUTPUT.PUT_LINE('data: [ ');
  FOR i IN vmin.FIRST .. vmin.LAST LOOP
    if (i < vmin.count) then
      DBMS_OUTPUT.PUT_LINE(vmin(i) || ',');
    elsif (i = vmin.count) then
      DBMS_OUTPUT.PUT_LINE(vmin(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "Swap OUT ",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.green1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN vmout.FIRST .. vmout.LAST LOOP
    if (i < vmout.count) then
      DBMS_OUTPUT.PUT_LINE(vmout(i) || ',');
    elsif (i = vmout.count) then
      DBMS_OUTPUT.PUT_LINE(vmout(i));
    end if;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('], fill: false, }, {');
  DBMS_OUTPUT.PUT_LINE('label: "OS Memory",');
  DBMS_OUTPUT.PUT_LINE ('lineTension :0,');
  DBMS_OUTPUT.PUT_LINE('fill: false,');
  DBMS_OUTPUT.PUT_LINE('backgroundColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('borderColor: window.awrColors.red1,');
  DBMS_OUTPUT.PUT_LINE('data: [');
  FOR i IN osmem.FIRST .. osmem.LAST LOOP
    if (i < osmem.count) then
      DBMS_OUTPUT.PUT_LINE(osmem(i) || ',');
    elsif (i = osmem.count) then
      DBMS_OUTPUT.PUT_LINE(osmem(i));
    end if;
  END LOOP;
dbms_output.put_line(' ], }] },             ');
dbms_output.put_line('options: {            ');
dbms_output.put_line('responsive: true,     ');
dbms_output.put_line('title:{               ');
dbms_output.put_line('display:true,         ');
dbms_output.put_line('text:"&_dbname&inid - OS Swap vs Memory"    ');
dbms_output.put_line('},                    ');
dbms_output.put_line('tooltips: {           ');
dbms_output.put_line('mode: "index",        ');
dbms_output.put_line('intersect: false,     ');
dbms_output.put_line('},                    ');
dbms_output.put_line('hover: {              ');
dbms_output.put_line('mode: "nearest",      ');
dbms_output.put_line('intersect: true       ');
dbms_output.put_line('},                    ');
dbms_output.put_line('scales: {             ');
dbms_output.put_line('xAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString: "OS Swap vs Memory"   ');
dbms_output.put_line('}                     ');
dbms_output.put_line('}],                   ');
dbms_output.put_line('yAxes: [{             ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('scaleLabel: {         ');
dbms_output.put_line('display: true,        ');
dbms_output.put_line('labelString:  "Mb" ');
dbms_output.put_line('} }] } } };           ');
END;
/
---------------------------------OS Swap vs Memory----------------------------------
prompt window.onload = function() {
--------------------------------
prompt var ctx = document.getElementById("canvas_cpu").getContext("2d");
prompt window.myLine = new Chart(ctx, cpudata);
prompt var ctx2 = document.getElementById("canvas_dbtime").getContext("2d");
prompt window.myLine = new Chart(ctx2, dbtimedata);
prompt var ctx2_p = document.getElementById("canvas_parsetime").getContext("2d");
prompt window.myLine = new Chart(ctx2_p, parsetimedata);
prompt var ctx6 = document.getElementById("canvas_ash").getContext("2d");
prompt  window.myBar = new Chart(ctx6, {
prompt  type: "bar",
prompt  data: ashdata,
prompt  options: {
prompt  title:{
prompt  display:true,
prompt  text:"Active Session History"
prompt  },
prompt   tooltips: {
prompt  mode: "index",
prompt  intersect: false
prompt  },
prompt  responsive: true,
prompt  scales: {
prompt  xAxes: [{
prompt  stacked: true,
prompt  }],
prompt  yAxes: [{
prompt  stacked: true
prompt  }]}}});
prompt var ctx3 = document.getElementById("canvas_sql").getContext("2d");
prompt window.myLine = Chart.Line(ctx3, {
prompt     data: sqldata,
prompt  options: {
prompt      responsive: true,
prompt      hoverMode: "index",
prompt      stacked: false,
prompt      title:{
prompt          display: true,
prompt          text:"&_dbname&inid -  SQL Execution Time and Count"
prompt      },
prompt      scales: {
prompt  yAxes: [{
prompt      type: "linear", // only linear but allow scale type registration. This allows extensions to exist solely for log scale for instance
prompt      display: true,
prompt      position: "left",
prompt      id: "y-axis-1",
prompt  }, {
prompt      type: "linear", // only linear but allow scale type registration. This allows extensions to exist solely for log scale for instance
prompt      display: true,
prompt      position: "right",
prompt      id: "y-axis-2",
prompt      // grid line settings
prompt      gridLines: {
prompt          drawOnChartArea: false, // only want the grid lines for one axis to show up
prompt      }, }], }} }); 
prompt  var ctx5 = document.getElementById("canvas_logic").getContext("2d");
prompt  window.myLine = new Chart(ctx5, logicdata);
prompt var ctx7 = document.getElementById("canvas_commit").getContext("2d");
prompt window.myLine = Chart.Line(ctx7, {
prompt data: commitdata,
prompt options: {
prompt responsive: true,
prompt hoverMode: "index",
prompt stacked: false,
prompt title:{
prompt display: true,
prompt text:"&_dbname&inid - Commits and Redo size per second"
prompt },
prompt scales: {
prompt yAxes: [{
prompt type: "linear",  
prompt display: true,
prompt position: "left",
prompt id: "y-axis-1",
prompt }, {
prompt type: "linear", 
prompt display: true,
prompt position: "right",
prompt id: "y-axis-2",
prompt // grid line settings
prompt gridLines: {
prompt drawOnChartArea: false,  
prompt }, }], }} });
prompt var ctxuserio = document.getElementById("canvas_userio").getContext("2d");
prompt window.myLine = new Chart(ctxuserio, useriodata);
prompt var ctxavgio = document.getElementById("canvas_avgio").getContext("2d");
prompt window.myLine = new Chart(ctxavgio, avgiodata);
prompt var ctxbchange = document.getElementById("canvas_bchange").getContext("2d");
prompt window.myLine = new Chart(ctxbchange,bchangedata);
prompt var ctxconn = document.getElementById("canvas_conn").getContext("2d");
prompt window.myLine = new Chart(ctxconn, conndata);
prompt var ctxlogon = document.getElementById("canvas_logon").getContext("2d");
prompt window.myLine = new Chart(ctxlogon, logondata);
prompt var ctxgclost = document.getElementById("canvas_gclost").getContext("2d");
prompt window.myLine = new Chart(ctxgclost, gclostdata);
prompt var ctxgcms = document.getElementById("canvas_gcms").getContext("2d");
prompt window.myLine = new Chart(ctxgcms, gcmsdata);
prompt var ctxgcb = document.getElementById("canvas_gcb").getContext("2d");
prompt window.myLine = new Chart(ctxgcb, gcbdata);
prompt var ctxbchit = document.getElementById("canvas_bchit").getContext("2d");
prompt window.myLine = new Chart(ctxbchit, bchit);
prompt var ctxlib = document.getElementById("canvas_lib").getContext("2d");
prompt window.myLine = new Chart(ctxlib, libdata);
prompt var ctxlatch = document.getElementById("canvas_latch").getContext("2d");
prompt window.myLine = new Chart(ctxlatch, latchdata);
prompt var ctxlatchsp = document.getElementById("canvas_latchsp").getContext("2d");
prompt window.myLine = new Chart(ctxlatchsp, latchspdata);
prompt var ctxlatchrco = document.getElementById("canvas_latchrco").getContext("2d");
prompt window.myLine = new Chart(ctxlatchrco, latchrcodata);
prompt var ctxlatchcbc = document.getElementById("canvas_latchcbc").getContext("2d");
prompt window.myLine = new Chart(ctxlatchcbc, latchcbcdata);
prompt var ctxlatchlru = document.getElementById("canvas_latchlru").getContext("2d");
prompt window.myLine = new Chart(ctxlatchlru, latchlrudata);
prompt var ctxlatchgc = document.getElementById("canvas_latchgc").getContext("2d");
prompt window.myLine = new Chart(ctxlatchgc, latchgcdata);
prompt var ctxlatchdml = document.getElementById("canvas_latchdml").getContext("2d");
prompt window.myLine = new Chart(ctxlatchdml, latchdmldata);
prompt var ctxfct = document.getElementById("canvas_fct").getContext("2d");
prompt window.myLine = new Chart(ctxfct, fctdata);
prompt var ctxavact = document.getElementById("canvas_aas").getContext("2d");
prompt window.myLine = new Chart(ctxavact, avact);
prompt var ctxosstat = document.getElementById("canvas_osstat").getContext("2d");
prompt window.myLine = new Chart(ctxosstat, osstat);
prompt var ctxmemstat = document.getElementById("canvas_memstat").getContext("2d");
prompt window.myLine = new Chart(ctxmemstat, memstat);
prompt var ctxiops = document.getElementById("canvas_iops").getContext("2d");
prompt window.myLine = new Chart(ctxiops, iops);
prompt var ctxiopsbreak = document.getElementById("canvas_iopsbreakdown").getContext("2d");
prompt window.myLine = new Chart(ctxiopsbreak, iopsbreak);
prompt var ctxiothrput = document.getElementById("canvas_throughput").getContext("2d");
prompt window.myLine = new Chart(ctxiothrput, iothrougput);
prompt var ctxiothrputbr = document.getElementById("canvas_throughputtotal").getContext("2d");
prompt window.myLine = new Chart(ctxiothrputbr, iothrougputtotal);
prompt var ctxstatistic = document.getElementById("canvas_iostatistic").getContext("2d");
prompt window.myLine = new Chart(ctxstatistic, phyio);
prompt var ctxphyread = document.getElementById("canvas_phyreadbreak").getContext("2d");
prompt window.myLine = new Chart(ctxphyread, phyreadbk);
prompt var ctxphywrite = document.getElementById("canvas_phywrtbreak").getContext("2d");
prompt window.myLine = new Chart(ctxphywrite, phywrite);
prompt var ctxsga = document.getElementById("canvas_sga").getContext("2d");
prompt window.myLine = new Chart(ctxsga, sgabreak);
prompt var ctxbuffercache = document.getElementById("canvas_buffercachewait").getContext("2d");
prompt window.myLine = new Chart(ctxbuffercache , buffercache);
prompt var ctxpgastatistic = document.getElementById("canvas_pgastatictis").getContext("2d");
prompt window.myLine = new Chart(ctxpgastatistic , pgastatistic);
prompt var ctxdbratio = document.getElementById("canvas_dbtimeratio").getContext("2d");
prompt window.myLine = new Chart(ctxdbratio , waitratio);
prompt var ctxisufficient = document.getElementById("canvas_instancesuff").getContext("2d");
prompt window.myLine = new Chart(ctxisufficient , instancesufficient);
prompt var ctxdbcalls = document.getElementById("canvas_dbcalls").getContext("2d");
prompt window.myLine = new Chart(ctxdbcalls , dbcalls);
prompt var ctxsorts = document.getElementById("canvas_sort").getContext("2d");
prompt window.myLine = new Chart(ctxsorts , sorts);
prompt var ctxcurs = document.getElementById("canvas_cursor").getContext("2d");
prompt window.myLine = new Chart(ctxcurs , curinfo);
prompt var ctxparsecpu = document.getElementById("canvas_parsecpu").getContext("2d");
prompt window.myLine = new Chart(ctxparsecpu , cpuparse);
prompt var ctxsqlnet = document.getElementById("canvas_sqlnet").getContext("2d");
prompt window.myLine = new Chart(ctxsqlnet , sqlnet);
prompt var ctxpgaeff = document.getElementById("canvas_pgaeff").getContext("2d");
prompt window.myLine = new Chart(ctxpgaeff , pgaeff);
prompt var ctxosswap = document.getElementById("canvas_osswap").getContext("2d");
prompt window.myLine = new Chart(ctxosswap , osswap);
prompt var ctxundostat = document.getElementById("canvas_undostat").getContext("2d");
prompt window.myLine = new Chart(ctxundostat , undostat);
prompt var ctxparallel = document.getElementById("canvas_parallel").getContext("2d");
prompt window.myLine = new Chart(ctxparallel , parallell);
prompt var ctxparaoper = document.getElementById("canvas_paralleloper").getContext("2d");
prompt window.myLine = new Chart(ctxparaoper , parallelloper);
prompt var ctxglcur = document.getElementById("canvas_glcur").getContext("2d");
prompt window.myLine = new Chart(ctxglcur , glcur);
prompt var ctxglcr = document.getElementById("canvas_glcr").getContext("2d");
prompt window.myLine = new Chart(ctxglcr , glcr);
prompt var ctxglper = document.getElementById("canvas_glper").getContext("2d");
prompt window.myLine = new Chart(ctxglper , glper);
prompt var ctxgllp = document.getElementById("canvas_gllp").getContext("2d");
prompt window.myLine = new Chart(ctxgllp , gllp);
prompt var ctxglep= document.getElementById("canvas_glep").getContext("2d");
prompt window.myLine = new Chart(ctxglep , glep);
prompt var ctxgles= document.getElementById("canvas_gles").getContext("2d");
prompt window.myLine = new Chart(ctxgles , gles);
prompt var ctxglesper= document.getElementById("canvas_glesper").getContext("2d");
prompt window.myLine = new Chart(ctxglesper , glesper);
prompt var ctxgglcrss= document.getElementById("canvas_glcrss").getContext("2d");
prompt window.myLine = new Chart(ctxgglcrss , glcrss);
prompt var ctxgglinter= document.getElementById("canvas_glinter").getContext("2d");
prompt window.myLine = new Chart(ctxgglinter , glinter);
prompt var ctxfreemem= document.getElementById("canvas_memfree").getContext("2d");
prompt window.myLine = new Chart(ctxfreemem , memfree);
prompt var ctxwcaas= document.getElementById("canvas_wcaas").getContext("2d");
prompt window.myLine = new Chart(ctxwcaas , wcaas);
prompt var ctxwredo2= document.getElementById("canvas_redo2").getContext("2d");
prompt window.myLine = new Chart(ctxwredo2 , redo2);
prompt var ctxwredo3= document.getElementById("canvas_redo3").getContext("2d");
prompt window.myLine = new Chart(ctxwredo3 , redo3);
prompt var ctxiofthp= document.getElementById("canvas_iofthpt").getContext("2d");
prompt window.myLine = new Chart(ctxiofthp , iofthpt);
prompt var ctxiofiops= document.getElementById("canvas_iofiops").getContext("2d");
prompt window.myLine = new Chart(ctxiofiops , iofiops);
prompt var ctxchainrow= document.getElementById("canvas_chainrowcell").getContext("2d");
prompt window.myLine = new Chart(ctxchainrow , chainrowcell);
prompt var ctxfchit= document.getElementById("canvas_fchit").getContext("2d");
prompt window.myLine = new Chart(ctxfchit , fchit);
prompt var ctxiosm= document.getElementById("canvas_iosm").getContext("2d");
prompt window.myLine = new Chart(ctxiosm , iosm);
prompt var ctxosload= document.getElementById("canvas_osload").getContext("2d");
prompt window.myLine = new Chart(ctxosload , osload);
prompt var ctxioft= document.getElementById("canvas_ioftthpt").getContext("2d");
prompt window.myLine = new Chart(ctxioft , ioftthpt);
prompt var ctxioiops= document.getElementById("canvas_ioftiops").getContext("2d");
prompt window.myLine = new Chart(ctxioiops , ioftiops);
prompt var ctxcbcbrk= document.getElementById("canvas_cbcbrk").getContext("2d");
prompt window.myLine = new Chart(ctxcbcbrk , cbcbrk);
prompt var ctxrcobrk= document.getElementById("canvas_rcobrk").getContext("2d");
prompt window.myLine = new Chart(ctxrcobrk , rcobrk);
prompt var ctxspbrk= document.getElementById("canvas_spbrk").getContext("2d");
prompt window.myLine = new Chart(ctxspbrk , spbrk);
prompt var ctxcbclrubrk= document.getElementById("canvas_cbclrubrk").getContext("2d");
prompt window.myLine = new Chart(ctxcbclrubrk , cbclrubrk);
prompt var ctxgcbrk= document.getElementById("canvas_gcbrk").getContext("2d");
prompt window.myLine = new Chart(ctxgcbrk , gcbrk);
prompt var ctxdmlbrk= document.getElementById("canvas_dmlbrk").getContext("2d");
prompt window.myLine = new Chart(ctxdmlbrk , dmlbrk);
prompt var ctxdmlbrk= document.getElementById("canvas_dmlbrk").getContext("2d");
prompt window.myLine = new Chart(ctxdmlbrk , dmlbrk);
prompt var ctxtempact= document.getElementById("canvas_tempact").getContext("2d");
prompt window.myLine = new Chart(ctxtempact , tempact);
prompt var ctxtempiothpt= document.getElementById("canvas_tempiothpt").getContext("2d");
prompt window.myLine = new Chart(ctxtempiothpt , tempiothpt);
prompt var ctxwcbyaas= document.getElementById("canvas_wcbyaas").getContext("2d");
prompt window.myLine = new Chart(ctxwcbyaas , wcbyaas);
prompt var ctxlibarea= document.getElementById("canvas_libsqlarea").getContext("2d");
prompt window.myLine = new Chart(ctxlibarea , libsqlarea);
prompt var ctxlibtabpro= document.getElementById("canvas_libtabpro").getContext("2d");
prompt window.myLine = new Chart(ctxlibtabpro , libtabpro);
prompt var ctxlibareastat= document.getElementById("canvas_libsqlareastat").getContext("2d");
prompt window.myLine = new Chart(ctxlibareastat , libsqlareastat);
prompt var ctxtablescan= document.getElementById("canvas_tablescan").getContext("2d");
prompt window.myLine = new Chart(ctxtablescan , tablescan);
prompt var ctxlatchlc= document.getElementById("canvas_latchlc").getContext("2d");
prompt window.myLine = new Chart(ctxlatchlc , latchlc);
prompt var ctxlcbrk= document.getElementById("canvas_lcbrk").getContext("2d");
prompt window.myLine = new Chart(ctxlcbrk , lcbrk);
-------------------------------------
prompt var ctxe1 = document.getElementById("canvas_e1").getContext("2d");
prompt window.myLine = new Chart(ctxe1, e1data);                            
prompt var ctxe2 = document.getElementById("canvas_e2").getContext("2d");
prompt window.myLine = new Chart(ctxe2, e2data);
prompt var ctxe3 = document.getElementById("canvas_e3").getContext("2d");
prompt window.myLine = new Chart(ctxe3, e3data);
prompt var ctxe4 = document.getElementById("canvas_e4").getContext("2d");
prompt window.myLine = new Chart(ctxe4, e4data);
prompt var ctxevent = document.getElementById("canvas_event");
prompt window.myPolarArea = Chart.PolarArea(ctxevent, eventdata);
prompt var ctxparse = document.getElementById("canvas_parse").getContext("2d")
prompt window.myLine = new Chart(ctxparse, parsedata)
prompt var ctxpgahit = document.getElementById("canvas_pgahitratio").getContext("2d")
prompt window.myLine = new Chart(ctxpgahit,pgahitratio)
------------------------------------
prompt };
prompt 	</script>	
prompt <hr>
prompt </p>
prompt The License of Awr Chart
prompt <br>
prompt Permission is hereby granted by Author, free of charge, to any person abotaining a copy of this software,
prompt <br>
prompt to deal in the software without restriction, including without limitation the rights to use,copy or distribute. 
prompt <br>
prompt The copy right of Chart javascript belongs to its author Nick Downie (http://www.nickdownie.com/)  . This js is an open source project which
prompt <br>
prompt is under MIT license.
prompt <br>
prompt <H4 class='awr'>
prompt Oracle Advanced Customer Support
prompt </H4>
prompt <br>
prompt Version : 3.0
prompt <br>
prompt Date    : 2018-03
prompt </body>
prompt </html>
spool off
set termout       on
prompt report wrote to awrcrt_&_dbname._&inid._&bid._&eid..html
prompt
set heading       on
prompt Generating Segment Performance 
@awrcrt_segment/awrsegmentgen_sn.sql
@awrcrt_segment/awrsegmentgen_sec_sn.sql
prompt Generating TopSQL Performance
@awrcrt_topsql/awrtopsql_sn.sql
@awrcrt_topsql/awrtopsql_exec_sn.sql
prompt Generating ADDM Reports
@awrcrt_addm/addm_rec.sql
host zip -m awrcrt_report_&_dbname._&inid._&bid._&eid *.xls *.html
host rm ADDM_Recommendations*.html
host rm AWRSQLStat*.xls
host rm AWRSegment*.xls
host rm AWRSegment*.xls
host rm AWRSQLStat*.xls