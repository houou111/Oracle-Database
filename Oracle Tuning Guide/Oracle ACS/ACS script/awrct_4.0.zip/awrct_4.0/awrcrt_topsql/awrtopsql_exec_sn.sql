set termout off
column timecol new_value timestamp 
column spool_extension new_value suffix 
select to_char(sysdate,'DD_MON_YYYY_HH24_MI_SS') timecol,'.xls' spool_extension from sys.dual; 
column output new_value dbname 
select value || '_' output from v$parameter where name = 'db_name';

set feed off markup html on spool on 
alter session set nls_date_format='YYYY-MM-DD';
set serveroutput on
set termout off
set verify off
set echo off
set pagesize 50000
spool AWRSQLStat_Buffer_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_buffer_exec_sn.sql
spool off
spool AWRSQLStat_Cluster_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_clwait_exec_sn.sql
spool off
spool AWRSQLStat_CPU_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_cputime_exec_sn.sql
spool off
spool AWRSQLStat_Elapsed_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_elapsedtime_exec_sn.sql
spool off
spool AWRSQLStat_IOWait_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_iowaittime_exec_sn.sql
spool off
spool AWRSQLStat_Parse_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_parse_exec_sn.sql
spool off
spool AWRSQLStat_Physical_Per_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_physicalread_exec_sn.sql
spool off
set markup html off spool off
