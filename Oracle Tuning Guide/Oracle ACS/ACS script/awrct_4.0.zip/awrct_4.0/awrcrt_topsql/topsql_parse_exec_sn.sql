col inst for 999
col sql_id       format a13           heading 'SQL Id'
col sqt          format a100  trunc    heading 'SQL Text'
col prscexec         format  999,999,999,999.99  heading 'ParsePerExec'
col prsc         format  999,999,999,999  heading 'Parse'
col pct_prsc         format  999.99  heading '% Parse'
set verify off
PROMPT ==============================================================================================
PROMPT ==AWR TOP SQL BY PARSE PER EXEC 3.0 ==
PROMPT ==============================================================================================
define ustos = 1000000;
define topsql=10;
select s.instance_number inst,s.snap_id
  						, TO_CHAR(s.end_interval_time, 'mm/dd/yyyy HH24:MI')   endtime,s.sql_id
	 ,prsc  prsc
	 ,ROUND(prsc/NULLIF(execs,0)) prscexec
	 ,ratio_to_report(prsc) over (partition by s.snap_id,s.instance_number)*100 pct_prsc
	 ,st.sql_text
     from
      ( select * from (select e.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time,sql_id,e.module
           , sum(executions_delta)      execs
           , sum(e.parse_calls_delta) prsc
           ,DENSE_RANK() OVER (PARTITION BY s.snap_id,e.instance_number ORDER BY e.parse_calls_delta DESC) time_rank
        from dba_hist_sqlstat e,dba_hist_snapshot s
       where e.snap_id = s.snap_id
       and e.instance_number=s.instance_number
	   and e.parse_calls_delta > 0
       group by e.instance_number,s.snap_id,sql_id,s.begin_interval_time,s.end_interval_time,e.parse_calls_delta,e.module
       order by sum(e.parse_calls_delta) desc) where time_rank <= &&topsql) s,
    (select instance_number,snap_id,begin_interval_time,end_interval_time,tdbtim,tdbcpu,tbgtim,tbgcpu
  from ((select s.instance_number,s.snap_id,e.stat_name,s.begin_interval_time,s.end_interval_time
             , (e.value - nvl(b.value,0))  value
          from dba_hist_sys_time_model b
             , dba_hist_sys_time_model e
          ,dba_hist_snapshot       s
         where b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
           and e.dbid            = b.dbid
           and e.instance_number=s.instance_number  
           and e.instance_number = b.instance_number (+)
           and b.stat_id   (+)   = e.stat_id
           and e.stat_name in ('DB time','DB CPU','background elapsed time','background cpu time'))
       pivot (sum(value) for stat_name in 
               ('DB time'                 tdbtim
               ,'DB CPU'                  tdbcpu
               ,'background elapsed time' tbgtim
               ,'background cpu time'     tbgcpu)))) e,
(select instance_number,snap_id,begin_interval_time,end_interval_time,tgets,tdbch,trds,trdds,twrs,twrds,texecs,tiffs,ttslt,tgccrr,tgccur,tgccrs,tgccus,tucm,tur
  from ((select s.instance_number,s.snap_id,e.stat_name, s.begin_interval_time,s.end_interval_time
             , (e.value - nvl(b.value,0))  value
          from dba_hist_sysstat b
             , dba_hist_sysstat e
         ,dba_hist_snapshot       s
         where b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
           and e.dbid            = b.dbid  
           and e.instance_number=s.instance_number
           and e.instance_number = b.instance_number (+)
           and b.stat_id   (+)   = e.stat_id
           and e.stat_name in ('session logical reads', 'db block changes'
               ,'physical reads', 'physical reads direct'
               ,'physical writes', 'physical writes direct'
               ,'execute count'
               , 'index fast full scans (full)', 'table scans (long tables)'
               , 'gc cr blocks received', 'gc current blocks received'
               , 'gc cr blocks served', 'gc current blocks served'
               , 'user commits', 'user rollbacks'))
        pivot (sum(value) for stat_name in
              ('session logical reads'         tgets
              ,'db block changes'              tdbch
              ,'physical reads'                trds
              ,'physical reads direct'         trdds
              ,'physical writes'               twrs
              ,'physical writes direct'        twrds
              ,'execute count'                 texecs
              ,'index fast full scans (full)'  tiffs
              ,'table scans (long tables)'     ttslt
              ,'gc cr blocks received'         tgccrr
              ,'gc current blocks received'    tgccur
              ,'gc cr blocks served'           tgccrs
              ,'gc current blocks served'      tgccus
              ,'user commits'                  tucm
              ,'user rollbacks'                tur)))) d,
(select instance_number,snap_id,begin_interval_time,end_interval_time,tclutm,tiowtm
  from ((select s.instance_number,s.snap_id,s.begin_interval_time,s.end_interval_time, e.wait_class
              , sum(e.time_waited_micro - nvl(b.time_waited_micro,0))  twttm
           from dba_hist_system_event b
              , dba_hist_system_event e
         ,dba_hist_snapshot       s
         where b.snap_id    =s.snap_id - 1
           and e.snap_id         = s.snap_id
           and e.instance_number=s.instance_number
            and e.dbid            = b.dbid
            and e.instance_number = b.instance_number  (+)
            and e.event_id        = b.event_id         (+)
            and e.wait_class in ('Cluster', 'User I/O')
          group by s.instance_number,s.snap_id,e.wait_class,s.begin_interval_time,s.end_interval_time))
    pivot (sum(twttm) for wait_class in 
                ('Cluster'   tclutm
                ,'User I/O'  tiowtm))) f              
              ,dba_hist_sqltext st
where s.snap_id=e.snap_id 
and s.snap_id=d.snap_id
and s.snap_id=f.snap_id
and s.sql_id = st.sql_id
and s.instance_number=d.instance_number
and s.instance_number=f.instance_number
and s.instance_number=e.instance_number
and s.snap_id between &bid and &eid and s.instance_number=&inid
order by inst,endtime,prsc desc;