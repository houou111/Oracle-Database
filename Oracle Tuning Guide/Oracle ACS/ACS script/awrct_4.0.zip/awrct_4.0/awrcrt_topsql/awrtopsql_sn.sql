set termout off
column timecol new_value timestamp 
column spool_extension new_value suffix 
select to_char(sysdate,'DD_MON_YYYY_HH24_MI_SS') timecol,'.xls' spool_extension from sys.dual; 
column output new_value dbname 
select value || '_' output from v$parameter where name = 'db_name';

set feed off markup html on spool on 
alter session set nls_date_format='YYYY-MM-DD';
set serveroutput on
set termout off
set verify off
set echo off
set pagesize 50000
spool AWRSQLStat_Buffer_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_buffer_sn.sql
spool off
spool AWRSQLStat_Cluster_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_clwait_sn.sql
spool off
spool AWRSQLStat_CPU_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_cputime_sn.sql
spool off
spool AWRSQLStat_Elapsed_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_elapsedtime_sn.sql
spool off
spool AWRSQLStat_Exec_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_execs_sn.sql
spool off
spool AWRSQLStat_IOWait_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_iowaittime_sn.sql
spool off
spool AWRSQLStat_Offfload_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_offload_sn.sql
spool off
spool AWRSQLStat_Parse_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_parse_sn.sql
spool off
spool AWRSQLStat_Physical_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_physicalread_sn.sql
spool off
spool AWRSQLStat_UnOpt_&&dbname&&timestamp&&suffix 
@awrcrt_topsql/topsql_unoptread_sn.sql
spool off
set markup html off spool off
