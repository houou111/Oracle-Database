// JavaScript Document

	// Utility functions

	Element.addMethods({
	   closest: function closest (element, cssRule) {
	      var $element = $(element);
	      // Return if we don't find an element to work with.
	      if(!$element) {
	         return;
	      }
	      return $element.match(cssRule) ? $element : $element.up(cssRule);
	   }
	});
	
	function getHash(elem)
	{
		var hidx = elem.href.indexOf("#");
		return elem.href.substr(hidx + 1, elem.href.length - hidx - 1);
	}
	
	// Format fancy bordered tables

	function formatTables()
	{
		var i;
		
		$$('table.orcl3w0').each(
			function(s)
			{
				s.setStyle({ border: 'none' });
				
				// Remove top borders
				s.select('th').each( 
						function(m) 
						{ 
							m.setStyle({ border: 'none' }); 
							m.setStyle({ borderBottom: '1px solid #c0c0c0' });
						} 
				);
				
				s.select('td').each(
						function(m)
						{
							m.setStyle({ 'borderTop': 'none' });
							m.setStyle({ 'borderBottom': 'none' });
						}
				);
				
				// Add line on right of emphasized rows
				s.select('tr.rx0').each(
					function (m, index)
					{
						window.gl0 = 0;
						
						m.select('td').each(
							function (c)
							{
								c.setStyle({ padding: '0' });
								var ih = c.innerHTML;
								c.innerHTML = '<div class="orcl3w1">' + ih + '</div>';
								var ch = m.getHeight();
								
								if (!Prototype.Browser.IE) ch -= 20;
								if (ch > window.gl0) window.gl0 = ch;
							}
						);
						
						m.select('td').each(
							function (c)
							{
								c.firstDescendant().setStyle({ height: window.gl0 });
							}
						);
						
						
					}
				);
				
				s.select('tr').each(
					function (m, index)
					{
						var cn0 = m.classNames().inspect().toString();
						
						if (index > 0)
						{
							if (cn0 == window.gl1)
							{
								m.select('td').each(
									function (c)
									{
										gl2.setStyle({ 'borderBottom': '1px solid #e0e0e0' });
										c.setStyle({ 'borderTop': '1px solid #e0e0e0' });
									}
								);
							}
							else
							{
								m.select('td').each(
									function (c)
									{
										gl2.setStyle({ 'borderBottom': '1px solid #c0c0c0' });
										c.setStyle({ 'borderTop': '1px solid #c0c0c0' });
									}
								);
							}
						}
						
						window.gl1 = cn0;
						window.gl2 = m;
					}
				);
				
				s.select('tr').last().select('td').each(
					function (c)
					{
						c.setStyle({ 'borderBottom': '1px solid #c0c0c0' });
					}											 
				);
			}
		);
	}
	
	function prepareToggles()
	{
		$$('div.ch6w6').each(
			function (m)
			{
				m.hide();
				m.setStyle({ overflow: 'visible', width: 'auto', height: 'auto' });
			}
		);
		
		$$('div.ch6w8').each(
			function (m)
			{
				Effect.SlideUp(m, { duration: 0.0 }); 	
			}
		);
		
		$$('div.ch6w0').invoke('observe', 'click', function( event )
		{
			toggleRC($(this));
		});
	}
	
	function toggleRC(elem)
	{
		var tc = elem.ancestors()[0];
		var d = 0.25;
		
		$$('div.ch6').each( function(s) 
		{
			if (s == tc)
			{
				if (s.select('div.ch6w21').first().visible())
				{
					s.select('div.ch6w5').first().setStyle({ backgroundPosition: '0 -16px' });
					s.select('div.ch6w21').first().hide();
					s.select('div.ch6w6').first().show();
					Effect.SlideDown(s.select('div.ch6w8').first(), { 
						duration: d, 
						delay: 0.1,
						transition: Effect.Transitions.linear,
						queue: { position: 'end', scope: 'menuscope' + s.id, limit: 1 }
					});
				}
				else
				{
					s.select('div.ch6w5').first().setStyle({ backgroundPosition: '0 -48px' });
					Effect.SlideUp(s.select('div.ch6w8').first(), { 
						duration: d, 
						delay: 0.1,
						transition: Effect.Transitions.linear, 
						queue: { position: 'end', scope: 'menuscope' + s.id, limit: 1 }, 
						afterFinish: function() 
						{ 
							s.select('div.ch6w21').first().show();
							s.select('div.ch6w6').first().hide();
						} 
					});
				}
			}
		});
	}
	
	function prepareMarquee()
	{
		$$('div.orcl5 a').invoke('observe', 'mouseover', function(e) {
			var elem = $(this).ancestors()[0];
			if (elem.className != "liSelected")
			{
				if ($(this).select('div.number').length > 0) $(this).select('div.number').first().setStyle({ backgroundPosition: '0 -40px', color: '#ffffff' });
			}
		});
		
		$$('div.orcl5 a').invoke('observe', 'mouseout', function(e) {
			var elem = $(this).ancestors()[0];
			if (elem.className != "liSelected")
			{
				if ($(this).select('div.number').length > 0) $(this).select('div.number').first().setStyle({ backgroundPosition: '0 -90px', color: '#000000' });
			}
		});
		
		$$('div.orcl5 a').invoke('observe', 'click', function(e) {
			showMarquee($(this));
			Event.stop(e);
		});
		
		$$('div.cn1v0').each(
				function (m)
				{
					window.gl0 = 0;
					m.select("div").each(
						function (s, index)
						{
							s.setStyle({ height: "auto" });
							
							if (s.getHeight() > window.gl0)
							{
								window.gl0 = s.getHeight();
							}
							
							if (index > 0)
							{
								s.hide();	
							}
						}
					);
					
					m.setStyle({ minHeight: window.gl0 });
					if (Prototype.Browser.IE) m.setStyle({ height: window.gl0 });
				}
		);
	}
	
	function showMarquee(elem)
	{
		var id = getHash(elem);
		var elemLi = elem.ancestors()[0];
		var container = elem.closest('div.orcl1w2');
		var tgtEl = elem;
		
		if (id == "previous" || id == "next")
		{
			window.gl0 = -1;
			container.select('li').each(
				function (el, index)
				{
					if (el.className == 'liSelected')
					{
						window.gl0 = el;
					}
				}
			);
			
			if (window.gl0 != -1)
			{
				if (id == "previous")
				{
					if (window.gl0.previous(0))
					{
						tgtEl = window.gl0.previous(0).select('a').first();	
					}
				}
				else
				{
					if (window.gl0.next(0))
					{
						tgtEl = window.gl0.next(0).select('a').first();	
					}
				}
			}
		}
		
		id = getHash(tgtEl);
		if (id == "previous" || id == "next") return;
		
		container.select('.cn1 div').each( 
			function (s)
			{
				if (s.id == id)
				{
					s.appear();
				}
				else
				{
					s.hide();
				}
			}
		);
		
		container.select('li').each(
			function (s)
			{
				if (s == tgtEl.ancestors()[0])
				{
					s.addClassName('liSelected');
					if (s.select('div.number').length > 0) s.select('div.number').first().setStyle({ backgroundPosition: '0 -40px', color: '#ffffff' });
				}
				else
				{
					s.removeClassName('liSelected');
					if (s.select('div.number').length > 0) s.select('div.number').first().setStyle({ backgroundPosition: '0 -90px', color: '#000000' });
				}
				
				
			}
		);
	}
	
	var gl0;
	var gl1;
	var gl2;
	
	document.observe("dom:loaded", function() 
	{
		// Add behaviors and additionally styling bits here
		formatTables();
		prepareToggles();
		prepareMarquee();
	});

